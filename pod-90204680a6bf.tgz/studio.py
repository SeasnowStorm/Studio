#!/usr/bin/env python3
# =====================================================================
#  studio.py — serveur du Studio sur le Pod (piloté depuis l'iPhone)
#
#  - Écoute sur le port 8080 (proxy HTTPS de Runpod). Tout le trafic est
#    chiffré de bout en bout entre l'iPhone et ce serveur (ECDH P-256
#    authentifié par la clé de session, puis AES-256-GCM) : le proxy ne voit
#    que des données chiffrées.
#  - ComfyUI reste sur 127.0.0.1:8188, jamais exposé.
#  - Aucune donnée privée sur le disque : images, prompts, clés et journaux
#    restent en mémoire vive (processus + /root/prive -> /dev/shm/prive).
#    Rien n'est écrit sur la sortie standard (les journaux Runpod sont
#    conservés par Runpod) : le journal technique reste en mémoire.
# =====================================================================
import base64
import collections
import hashlib
import hmac as hmac_std
import http.server
import io
import json
import os
import random
import re
import secrets
import shutil
import signal
import socketserver
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid

from cryptography.hazmat.primitives import hashes, hmac, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

CODE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CODE)
import civitai as C  # noqa: E402

PORT = int(os.environ.get("STUDIO_PORT", "8080"))
COMFY = os.environ.get("STUDIO_COMFY", "http://127.0.0.1:8188")
TEST = os.environ.get("STUDIO_TEST") == "1"   # tests locaux : pas d'installation
if TEST and os.environ.get("STUDIO_MODELS"):
    C.MODELS = os.environ["STUDIO_MODELS"]
VERSION = "1.0"

# ---------------------------------------------------------------- journal en mémoire
_JOURNAL = collections.deque(maxlen=4000)
_local = threading.local()


def journal(texte, source="studio"):
    for ligne in str(texte).splitlines():
        if ligne.strip():
            _JOURNAL.append((time.strftime("%H:%M:%S"), source, ligne.rstrip()[:500]))


class _Sortie(io.TextIOBase):
    """Remplace stdout/stderr : rien ne sort du processus, tout va au journal en mémoire."""
    def write(self, s):
        cap = getattr(_local, "capture", None)
        if cap is not None:
            cap.append(s)
        else:
            journal(s, getattr(_local, "source", "studio"))
        return len(s)

    def flush(self):
        pass


if not TEST or os.environ.get("STUDIO_SILENCE") == "1":
    sys.stdout = sys.stderr = _Sortie()


def _hook(args):
    journal(f"ERREUR interne : {args.exc_type.__name__}: {args.exc_value}")


threading.excepthook = _hook


def capturer(fn, *a, **k):
    """Exécute fn en récupérant ce qu'elle affiche (dans ce fil uniquement)."""
    _local.capture = []
    try:
        rc = fn(*a, **k)
    finally:
        sortie, _local.capture = "".join(_local.capture), None
    return rc, sortie


# ---------------------------------------------------------------- jetons (mémoire uniquement)
_jeton_hf = threading.local()
C.token_hf = lambda: getattr(_jeton_hf, "v", None) or None
C.demander = lambda question, oui_auto=False: True   # les confirmations sont faites dans l'application

_progres = threading.local()   # fichier en cours de téléchargement pour le travail du fil courant


CURL_REPRISE = {7, 16, 18, 28, 35, 52, 55, 56, 92}   # coupures réseau : on reprend là où le fichier s'est arrêté


class Annule(C.Erreur):
    """Téléchargement arrêté à la demande : le fichier partiel est effacé, rien n'est installé."""


def _verifier_annulation(t, partiel=None):
    if t is not None and t.get("_annuler"):
        if partiel and os.path.isfile(partiel):
            try:
                os.remove(partiel)
            except OSError:
                pass
        raise Annule("Arrêté à ta demande.")


def _telecharger(url, dest, token):
    """Version silencieuse de civitai.telecharger : la progression est lue sur la taille du fichier.
    Une coupure (ex. code 92 : flux HTTP/2 interrompu par le serveur) n'oblige pas à tout recommencer :
    le téléchargement reprend à l'octet près (jusqu'à 8 essais), puis l'empreinte SHA-256 est vérifiée."""
    journal(f"téléchargement de {os.path.basename(dest).removesuffix('.part')}")
    _progres.telecharge = True
    t = getattr(_progres, "travail", None)
    if t is not None:
        t["fichier"] = dest
    cfg = f'header = "Authorization: Bearer {token}"\n' if token else ""
    try:
        for essai in range(1, 9):
            _verifier_annulation(t, dest)
            cmd = ["curl", "--http1.1", "--retry", "3", "--connect-timeout", "20", "--speed-limit", "10240",
                   "--speed-time", "120", "-sS", "-f", "-L", "-C", "-", "-K", "-", "-o", dest, url]
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                    text=True)
            if t is not None:
                t["_proc"] = proc
            try:
                _, err = proc.communicate(cfg)
            finally:
                if t is not None:
                    t.pop("_proc", None)
            r = subprocess.CompletedProcess(cmd, proc.returncode, "", err or "")
            _verifier_annulation(t, dest)
            if r.returncode == 0:
                return
            deja = os.path.getsize(dest) if os.path.exists(dest) else 0
            if r.returncode in (22, 33) and "416" in r.stderr and deja > 0:
                return   # fichier déjà complet : l'empreinte dira s'il est bon
            if r.returncode not in CURL_REPRISE or essai == 8:
                raise C.Erreur(f"Téléchargement échoué (code curl {r.returncode}) : {r.stderr.strip()[-200:]}")
            fait = os.path.getsize(dest) if os.path.exists(dest) else 0
            journal(f"coupure réseau (code curl {r.returncode}), reprise à {fait / 1024 ** 3:.2f} Go (essai {essai + 1}/8)")
            if t is not None:
                t["detail"] = f"Reprise après coupure (essai {essai + 1}/8)"
            time.sleep(min(30, 3 * essai))
    finally:
        if t is not None:
            t["fichier"] = None


C.telecharger = _telecharger
_sha256_orig = C.sha256


def _sha256(chemin):
    t = getattr(_progres, "travail", None)
    if t is not None:
        _verifier_annulation(t, chemin if chemin.endswith(".part") else None)
        t["detail"] = "Vérification de l'empreinte"
    return _sha256_orig(chemin)


C.sha256 = _sha256


def _taille_lisible(chemin):
    try:
        n = os.path.getsize(chemin)
    except OSError:
        return "?"
    return f"{n / 1024 ** 3:.2f} Go".replace(".", ",") if n >= 1024 ** 3 else f"{round(n / 1024 ** 2)} Mo"


def verifie(fonction, *a, nom=None, **k):
    """Exécute un téléchargement vérifié et écrit le résultat de la vérification d'empreinte dans le journal.
    Les fichiers y sont désignés par leur nom sur le disque (anonyme pour les modèles de Civitai)."""
    _progres.telecharge = False
    try:
        dest, _ = capturer(fonction, *a, **k)   # les messages bruts de civitai.py ne vont pas au journal
    except C.Erreur as e:
        if "empreinte" in str(e).lower():
            journal(f"Empreinte incorrecte ✗ — {nom or 'fichier'} : mis en quarantaine, non installé.")
        raise
    n = os.path.basename(dest) if isinstance(dest, str) else (nom or "fichier")
    if getattr(_progres, "telecharge", False):
        journal(f"Empreinte vérifiée ✓ — {n} ({_taille_lisible(dest) if isinstance(dest, str) else '?'})")
    else:
        journal(f"Déjà présent, empreinte vérifiée ✓ — {n}")
    return dest


# ---------------------------------------------------------------- outils
def b64e(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def b64d(s):
    s = str(s)
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def go(octets):
    return round((octets or 0) / 1024 ** 3, 2)


def _cmd(args, timeout=20):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:
        return ""


# ---------------------------------------------------------------- canal chiffré et appareils
# Trois sortes de clés authentifient l'échange de clés (ECDH) :
#  - la clé Studio (variable STUDIO_CLE du modèle Runpod, donc connue de Runpod) : elle ne sert qu'à
#    enregistrer le PREMIER appareil d'un Pod neuf, ou à demander l'accès ;
#  - une clé publique (connue de tous) : elle permet seulement de demander l'accès ;
#  - une clé par appareil, créée par le Pod, gardée en mémoire vive : seule elle donne accès au Studio.
# Un nouvel appareil n'obtient sa clé qu'après accord d'un appareil déjà autorisé, qui compare un code
# à 6 chiffres calculé sur l'échange de clés (avec engagement préalable : voir op_demande_acces).
CLE_STUDIO = b64d(os.environ.pop("STUDIO_CLE")) if os.environ.get("STUDIO_CLE") else None
CLE_PUBLIQUE = hashlib.sha256(b"studio-acces-public-v1").digest()
RUNPOD_CLE_POD = os.environ.pop("RUNPOD_API_KEY", None)   # clé limitée à ce Pod, fournie par Runpod
APPAREILS = collections.OrderedDict()   # id -> {"cle", "nom", "cree", "vu", "confirme"}
DEMANDES = {}                           # id -> demande d'accès en cours
REFUS = collections.deque(maxlen=16)    # dates des demandes refusées ou expirées
_NONCES = collections.deque(maxlen=4096)
_SESSIONS = collections.OrderedDict()
_SESSIONS_VERROU = threading.Lock()
OPS_ACCES = {"statut_acces", "enregistrer", "demande_acces", "reveler", "etat_demande"}


def _hmac(cle, *parts):
    h = hmac.HMAC(cle, hashes.SHA256())
    for p in parts:
        h.update(p)
    return h.finalize()


def _nettoyer_appareils():
    with _SESSIONS_VERROU:
        for k, a in list(APPAREILS.items()):
            if not a["confirme"] and time.time() - a["cree"] > 300:
                APPAREILS.pop(k, None)


def appareil_confirme():
    return any(a["confirme"] for a in APPAREILS.values())


def poignee(corps):
    """Établit une session : ECDH éphémère, authentifié par HMAC avec une clé connue du Pod."""
    d = json.loads(corps)
    cp, nc, m = b64d(d["cp"]), b64d(d["nc"]), b64d(d["m"])
    if len(cp) != 65 or len(nc) != 16:
        raise PermissionError("trame invalide")
    _nettoyer_appareils()
    with _SESSIONS_VERROU:
        candidats = [(a["cle"], ("appareil", k)) for k, a in APPAREILS.items()]
    candidats += ([(CLE_STUDIO, ("studio", None))] if CLE_STUDIO else []) + [(CLE_PUBLIQUE, ("public", None))]
    cle_ok = role = None
    for k, r in candidats:
        if hmac_std.compare_digest(m, _hmac(k, b"studio-h1", cp, nc)):
            cle_ok, role = k, r
            break
    if cle_ok is None or nc in _NONCES:
        raise PermissionError("authentification refusée")
    _NONCES.append(nc)
    if role[0] == "appareil":
        with _SESSIONS_VERROU:
            a = APPAREILS.get(role[1])
            if a is None:
                raise PermissionError("appareil retiré")
            if not a["confirme"]:
                a["confirme"] = True   # l'appareil a prouvé qu'il a bien reçu sa clé
                journal(f"Appareil autorisé : {a['nom']}.")
            a["vu"] = time.time()
    pub_c = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), cp)
    priv = ec.generate_private_key(ec.SECP256R1())
    sp = priv.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    sid = secrets.token_bytes(16)
    partage = priv.exchange(ec.ECDH(), pub_c)
    cle = HKDF(algorithm=hashes.SHA256(), length=32, salt=cle_ok, info=b"studio-k1" + cp + sp + nc + sid).derive(partage)
    with _SESSIONS_VERROU:
        _SESSIONS[sid] = {"aes": AESGCM(cle), "max": 0, "vus": set(), "role": role, "cp": cp, "sp": sp, "sid": sid}
        while len(_SESSIONS) > 48:
            _SESSIONS.popitem(last=False)
    return json.dumps({"sp": b64e(sp), "sid": b64e(sid), "m": b64e(_hmac(cle_ok, b"studio-h2", cp, sp, nc, sid))}).encode()


def _nouvel_appareil(nom):
    aid = secrets.token_hex(6)
    nom = re.sub(r"[^\w .-]", "", str(nom or "Appareil"))[:24].strip() or "Appareil"
    with _SESSIONS_VERROU:
        APPAREILS[aid] = {"cle": secrets.token_bytes(32), "nom": nom, "cree": time.time(), "vu": None, "confirme": False}
        return aid, APPAREILS[aid]["cle"]


def op_statut_acces(d):
    s = d["_s"]
    return {"libre": not appareil_confirme(), "role": s["role"][0], "version": VERSION}


def op_enregistrer(d):
    """Premier appareil d'un Pod neuf (prouvé par la clé Studio) : il reçoit sa propre clé."""
    s = d["_s"]
    if s["role"][0] != "studio":
        raise C.Erreur("La clé Studio de cet appareil ne correspond pas à celle du modèle Runpod.")
    if appareil_confirme():
        return {"occupe": True}
    with _SESSIONS_VERROU:   # une inscription inachevée (réponse perdue) est remplacée
        for k in [k for k, a in APPAREILS.items() if not a["confirme"]]:
            APPAREILS.pop(k)
    aid, cle = _nouvel_appareil(d.get("nom"))
    journal("Premier appareil en cours d'inscription.")
    return {"appareil": aid, "cle": b64e(cle)}


# ---- demande d'accès d'un nouvel appareil (comparaison d'un code à 6 chiffres)
def code_comparaison(cp, sp, nb, ns, sid):
    h = hashlib.sha256(b"studio-code-v1" + cp + sp + nb + ns + sid).digest()
    return f"{int.from_bytes(h[:8], 'big') % 1_000_000:06d}"


def _purger_demandes():
    for k, dm in list(DEMANDES.items()):
        if dm["etat"] in ("engage", "attente") and time.time() > dm["expire"]:
            dm["etat"] = "expire"
            REFUS.append(time.time())
        if time.time() > dm["expire"] + 120:
            DEMANDES.pop(k, None)


def op_demande_acces(d):
    """1re étape : le nouvel appareil s'engage sur un nombre secret nb (il n'envoie que son empreinte),
    le Pod répond avec son propre nombre ns. Le code dépend des deux : personne ne peut le choisir."""
    s = d["_s"]
    if not appareil_confirme():
        raise C.Erreur("Aucun appareil n'est encore autorisé sur ce Pod : utilise la clé Studio de ton modèle Runpod.")
    _purger_demandes()
    if sum(1 for t in REFUS if time.time() - t < 600) >= 3:
        raise C.Erreur("Trop de demandes refusées ou expirées : réessaie dans 10 minutes.")
    if any(dm["etat"] in ("engage", "attente") for dm in DEMANDES.values()):
        raise C.Erreur("Une autre demande d'accès est déjà en attente : réessaie dans 2 minutes.")
    eng = b64d(d.get("engagement") or "")
    if len(eng) != 32:
        raise C.Erreur("Demande invalide.")
    did = secrets.token_hex(6)
    ns = secrets.token_bytes(32)
    DEMANDES[did] = {"id": did, "sid": s["sid"], "cp": s["cp"], "sp": s["sp"], "eng": eng, "ns": ns, "code": None,
                     "nom": re.sub(r"[^\w .-]", "", str(d.get("nom") or "Appareil"))[:24].strip() or "Appareil",
                     "etat": "engage", "cree": time.time(), "expire": time.time() + 120, "remis": None}
    return {"demande": did, "ns": b64e(ns)}


def op_reveler(d):
    """2e étape : le nouvel appareil révèle nb ; le code est alors calculé et montré aux appareils autorisés."""
    s = d["_s"]
    dm = DEMANDES.get(d.get("demande"))
    if not dm or dm["sid"] != s["sid"] or dm["etat"] != "engage":
        raise C.Erreur("Demande inconnue ou expirée.")
    nb = b64d(d.get("nb") or "")
    if len(nb) != 32 or not hmac_std.compare_digest(hashlib.sha256(b"studio-eng-v1" + nb).digest(), dm["eng"]):
        dm["etat"] = "refuse"
        REFUS.append(time.time())
        raise C.Erreur("Engagement invalide : demande refusée.")
    dm["code"] = code_comparaison(dm["cp"], dm["sp"], nb, dm["ns"], dm["sid"])
    dm["etat"] = "attente"
    journal(f"Demande d'accès : {dm['nom']} (code affiché sur les appareils autorisés).")
    return {}


def op_etat_demande(d):
    s = d["_s"]
    _purger_demandes()
    dm = DEMANDES.get(d.get("demande"))
    if not dm or dm["sid"] != s["sid"]:
        return {"etat": "expire"}
    if dm["etat"] == "accepte" and dm["remis"]:
        r = {"etat": "accepte", **dm["remis"]}
        DEMANDES.pop(dm["id"], None)   # la clé n'est remise qu'une fois
        return r
    return {"etat": dm["etat"], "expire_dans": max(0, int(dm["expire"] - time.time()))}


def demandes_visibles():
    _purger_demandes()
    return [{"id": dm["id"], "nom": dm["nom"], "code": f"{dm['code'][:3]} {dm['code'][3:]}",
             "expire_dans": max(0, int(dm["expire"] - time.time()))}
            for dm in DEMANDES.values() if dm["etat"] == "attente"]


def op_approuver(d):
    dm = DEMANDES.get(d.get("demande"))
    if not dm or dm["etat"] != "attente" or time.time() > dm["expire"]:
        raise C.Erreur("Cette demande a expiré.")
    if not d.get("accepter"):
        dm["etat"] = "refuse"
        REFUS.append(time.time())
        journal(f"Demande d'accès refusée : {dm['nom']}.")
        return {}
    aid, cle = _nouvel_appareil(dm["nom"])
    dm["remis"] = {"appareil": aid, "cle": b64e(cle), "cle_studio": b64e(CLE_STUDIO) if CLE_STUDIO else None}
    dm["etat"] = "accepte"
    journal(f"Demande d'accès acceptée : {dm['nom']}.")
    return {}


def op_appareils(d):
    moi = d["_s"]["role"][1]
    with _SESSIONS_VERROU:
        return {"appareils": [{"id": k, "nom": a["nom"], "depuis": a["cree"], "moi": k == moi}
                              for k, a in APPAREILS.items() if a["confirme"]]}


def op_retirer_appareil(d):
    aid = d.get("id")
    with _SESSIONS_VERROU:
        a = APPAREILS.pop(aid, None)
        for k in [k for k, s in _SESSIONS.items() if s["role"] == ("appareil", aid)]:
            _SESSIONS.pop(k)
    if a:
        journal(f"Accès retiré : {a['nom']}.")
    return {}


def dechiffrer(corps):
    if len(corps) < 16 + 8 + 12 + 16:
        raise PermissionError("trame invalide")
    sid, ctr, iv, ct = corps[:16], corps[16:24], corps[24:36], corps[36:]
    with _SESSIONS_VERROU:
        s = _SESSIONS.get(sid)
    if not s:
        raise LookupError("session inconnue")
    n = int.from_bytes(ctr, "big")
    clair = s["aes"].decrypt(iv, ct, b"q" + sid + ctr)   # lève une exception si modifié
    with _SESSIONS_VERROU:
        if n in s["vus"] or n <= s["max"] - 1024:
            raise PermissionError("rejeu refusé")
        s["vus"].add(n)
        s["max"] = max(s["max"], n)
        if len(s["vus"]) > 2048:
            s["vus"] = {x for x in s["vus"] if x > s["max"] - 1024}
    return s, sid, ctr, json.loads(clair)


def chiffrer(s, sid, ctr, entete, binaire=b""):
    h = json.dumps(entete, ensure_ascii=False).encode()
    if not binaire:
        h += b" " * (-len(h) % 1024)   # longueur arrondie : le proxy ne devine pas la taille des textes
    clair = len(h).to_bytes(4, "big") + h + binaire
    iv = secrets.token_bytes(12)
    return iv + s["aes"].encrypt(iv, clair, b"r" + sid + ctr)


# ---------------------------------------------------------------- état général
ETAT = {"phase": "installation", "etape": 0, "etape_nom": "Démarrage", "erreur": None,
        "debut": time.time(), "comfy": False}
DOSSIER_MODELES_PRET = threading.Event()
ETAPES = {1: "Zone privée en mémoire vive", 2: "Téléchargement de ComfyUI", 3: "Environnement Python",
          4: "Outils", 5: "Détection du GPU", 6: "Vérification"}
_comfy_proc = None
_comfy_verrou = threading.Lock()


def installer():
    """Installe ComfyUI (installer_comfy.sh), puis le démarre en mode privé."""
    if TEST:
        DOSSIER_MODELES_PRET.set()
        ETAT.update(phase="pret", etape=7, etape_nom="Prêt", comfy=True)
        return
    try:
        for f in ("civitai.py", "installer_comfy.sh", "lancer_comfy.sh", "comfy_prive.py"):
            shutil.copy(os.path.join(CODE, f), os.path.join("/root", f))
        shutil.rmtree("/root/extensions", ignore_errors=True)
        shutil.copytree(os.path.join(CODE, "extensions"), "/root/extensions")
        p = subprocess.Popen(["bash", "/root/installer_comfy.sh"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding="utf-8", errors="replace", env=_env_propre(), cwd="/root")
        derniere = ""
        for ligne in p.stdout:
            journal(ligne, "installation")
            m = re.match(r"==> (\d)/6", ligne)
            if m:
                k = int(m.group(1))
                ETAT.update(etape=k, etape_nom=ETAPES.get(k, ""))
                if k >= 3:
                    DOSSIER_MODELES_PRET.set()
            if ligne.startswith("ARRÊT"):
                derniere = ligne.strip()
        if p.wait() != 0:
            fin = [t for _, src, t in list(_JOURNAL)[-4:] if src == "installation"]
            raise RuntimeError(derniere or "L'installation a échoué : " + (" / ".join(fin) or "voir le journal"))
        DOSSIER_MODELES_PRET.set()
        ETAT.update(etape=7, etape_nom="Démarrage de ComfyUI")
        demarrer_comfy()
        ETAT.update(phase="pret", etape_nom="Prêt")
    except Exception as e:
        ETAT.update(phase="erreur", erreur=str(e))
        journal(f"ERREUR : {e}")
        DOSSIER_MODELES_PRET.set()


def _env_propre():
    env = {k: v for k, v in os.environ.items()
           if not k.startswith("STUDIO_") and k not in ("HF_TOKEN", "CIVITAI_TOKEN", "RUNPOD_API_KEY")}
    env.update(HISTFILE="/dev/null", PYTHONDONTWRITEBYTECODE="1", PIP_PROGRESS_BAR="off", PIP_NO_CACHE_DIR="1", COMFY_PRIVE="1")
    return env


def demarrer_comfy():
    global _comfy_proc
    with _comfy_verrou:
        if _comfy_proc and _comfy_proc.poll() is None:
            return
        ETAT["comfy"] = False
        _comfy_proc = subprocess.Popen(["bash", "/root/lancer_comfy.sh"], stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                                       env=_env_propre(), cwd="/root", start_new_session=True)
        threading.Thread(target=_lire_comfy, args=(_comfy_proc,), daemon=True).start()
    for _ in range(600):
        try:
            comfy_get("/system_stats", timeout=3)
            ETAT["comfy"] = True
            journal("ComfyUI prêt")
            return
        except Exception:
            if _comfy_proc.poll() is not None:
                raise RuntimeError("ComfyUI s'est arrêté au démarrage (voir le journal)")
            time.sleep(1)
    raise RuntimeError("ComfyUI ne répond pas")


def _lire_comfy(p):
    for ligne in p.stdout:
        journal(ligne, "comfyui")
    if ETAT.get("comfy"):
        ETAT["comfy"] = False
        journal("ComfyUI s'est arrêté")
        if ETAT["phase"] == "pret" and not getattr(p, "_volontaire", False):
            threading.Thread(target=_relancer, daemon=True).start()


def _relancer():
    time.sleep(2)
    try:
        demarrer_comfy()
    except Exception as e:
        journal(f"Relance de ComfyUI impossible : {e}")


def arreter_comfy():
    global _comfy_proc
    with _comfy_verrou:
        p = _comfy_proc
        if p and p.poll() is None:
            p._volontaire = True
            ETAT["comfy"] = False
            try:
                os.killpg(p.pid, signal.SIGTERM)
                p.wait(timeout=30)
            except Exception:
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except Exception:
                    pass


def comfy_get(chemin, timeout=10):
    with urllib.request.urlopen(COMFY + chemin, timeout=timeout) as r:
        return json.loads(r.read() or b"null")


def comfy_post(chemin, donnees, timeout=30):
    req = urllib.request.Request(COMFY + chemin, data=json.dumps(donnees).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            corps = r.read()
            return json.loads(corps) if corps else None
    except urllib.error.HTTPError as e:
        try:
            return {"_erreur": json.loads(e.read())}
        except Exception:
            return {"_erreur": {"error": {"message": f"HTTP {e.code}"}}}


# ---------------------------------------------------------------- familles de modèles
def signature(rel):
    """Chemin + nom d'origine du fichier (gardé en mémoire : sur le disque, les fichiers ont un nom anonyme)."""
    i = INFOS.get(os.path.join(C.MODELS, rel)) or {}
    return (rel + " " + (i.get("original") or "") + " " + (i.get("nom") or "")).lower()


def _mot(mot, texte):
    return re.search(r"(^|[^a-z0-9])" + re.escape(mot) + r"([^a-z0-9]|$)", texte) is not None


def est_qwen21(texte):
    """Qwen Image 2.1 (pas les anciens Qwen-Image / Edit 2509 / 2511, dont les LoRA sont incompatibles)."""
    return re.search(r"qwen[\s_.-]*(image)?[\s_.-]*2[._-]?1(?!\d)", texte.lower()) is not None


def est_wan22(texte):
    """Wan 2.2 14B (« Wan 2.2 », « wan2.2 », « Wan Video 2.2 I2V-A14B » sur Civitai) ; pas le petit modèle TI2V 5B."""
    t = texte.lower()
    if re.search(r"ti2v|(?<![a-z0-9])5b(?![a-z0-9])", t):
        return False
    return re.search(r"wan[\s_.-]*(video[\s_.-]*)?2[._-]?2(?!\d)", t) is not None


def famille(rel):
    """rel : chemin relatif à models/ (ex. diffusion_models/krea-2/x.safetensors)."""
    s = signature(rel)
    if est_wan22(s):
        return "wan22"   # vidéo (onglet Animer), pas un modèle d'image
    if "minimax" in s or "10eros" in s or re.search(r"(^|/)h3(/|$)", s.split(" ")[0]):
        return "h3"      # MiniMax H3 (vidéo avec son, onglet Animer) ; sur Civitai, base « MiniMax H3 » ou « H3 »
    if "krea" in s:
        return "krea2"
    if "klein" in s or "flux.2" in s or "flux2" in s:
        return "flux2"
    if est_qwen21(s):
        return "qwen21"
    if "qwen" in s:
        return "qwen1"   # Qwen-Image 1.x / Edit 2509 / 2511 : non pris en charge, LoRA incompatibles avec la 2.1
    if any(x in s for x in ("pony", "illustrious", "noobai", "sdxl", "/xl", "-xl")):
        return "sdxl"
    if "sd-1" in s or "sd1" in s or "sd_1" in s:
        return "sd1"
    return None


def defauts(rel):
    f = famille(rel)
    s = n = signature(rel)
    if f == "krea2":
        if _mot("raw", n):
            return {"variante": "Raw", "steps": 28, "cfg": 4.5, "sampler": "euler", "scheduler": "simple",
                    "negatif": True, "sda": False, "clip": 0}
        return {"variante": "Turbo", "steps": 8, "cfg": 1.0, "sampler": "euler", "scheduler": "simple",
                "negatif": False, "sda": True, "clip": 0}
    if f == "flux2":
        if _mot("base", n):
            return {"variante": "Base", "steps": 20, "cfg": 4.0, "sampler": "euler", "scheduler": None,
                    "negatif": True, "sda": False, "clip": 0}
        return {"variante": "Distillée", "steps": 4, "cfg": 1.0, "sampler": "euler", "scheduler": None,
                "negatif": False, "sda": False, "clip": 0}
    if f == "qwen21":
        if "turbo" in n:   # modèle Turbo complet : 8 étapes, sigmas fixes
            return {"variante": "Turbo", "steps": 8, "cfg": 1.0, "sampler": "euler", "scheduler": "simple",
                    "negatif": True, "sda": False, "clip": 0, "turbo_integre": True}
        # chaîne officielle : euler / simple, CFG 1 (le texte « à éviter » ne sert qu'avec un CFG > 1)
        return {"variante": "Qwen Image 2.1", "steps": 30, "cfg": 1.0, "sampler": "euler", "scheduler": "simple",
                "negatif": True, "sda": False, "clip": 0}
    if f == "sdxl":
        if "pony" in s:
            return {"variante": "Pony", "steps": 25, "cfg": 6.5, "sampler": "euler_ancestral", "scheduler": "normal",
                    "negatif": True, "sda": False, "clip": 2}
        if "illustrious" in s or "noobai" in s:
            return {"variante": "Illustrious", "steps": 28, "cfg": 6.0, "sampler": "euler_ancestral",
                    "scheduler": "normal", "negatif": True, "sda": False, "clip": 2}
        return {"variante": "SDXL", "steps": 30, "cfg": 6.5, "sampler": "dpmpp_2m", "scheduler": "karras",
                "negatif": True, "sda": False, "clip": 1}
    if f == "sd1":
        return {"variante": "SD 1.5", "steps": 25, "cfg": 7.0, "sampler": "euler_ancestral", "scheduler": "normal",
                "negatif": True, "sda": False, "clip": 1, "largeur": 512, "hauteur": 768}
    return None


COMPOSANTS = {
    "krea2": {"te": ["qwen3vl_4b"], "vae": ["qwen_image_vae"], "clip_type": "krea2", "nom": "Krea 2"},
    "flux2": {"te": ["qwen_3_8b"], "vae": ["flux2"], "clip_type": "flux2", "nom": "Flux.2 Klein"},
    "qwen21": {"te": ["qwen3vl_8b"], "vae": ["qwen_image_2.1_vae"], "clip_type": "qwen_image", "nom": "Qwen Image 2.1"},
}
# Qwen Image 2.1 : (chemin sur Hugging Face, destination sous models/, SHA-256, taille)
# Empreintes relevées sur Hugging Face le 11/10/2026 ; elles doivent aussi correspondre à celles publiées.
QWEN21_DEPOT = "Comfy-Org/Qwen-Image-2.1"
# Tout vient du dépôt officiel Comfy-Org/Qwen-Image-2.1. QWEN21_DEPOTS permet de prendre un fichier ailleurs
# (dépôt, révision figée) ; vide = tout chez Comfy-Org.
QWEN21_DEPOTS = {}
QWEN21 = {
    "modele": ("diffusion_models/qwen_image_2.1_int8_convrot.safetensors",
               "diffusion_models/qwen-image-2.1/qwen_image_2.1_int8_convrot.safetensors",
               "cb74113cb03faecd79611b01fd7fd642f0aa60d6f0b95086abee214d75eaa57d", 7256783064),
    "te": ("text_encoders/qwen3vl_8b_int8_convrot.safetensors",
           "text_encoders/qwen-image-2.1/qwen3vl_8b_int8_convrot.safetensors",
           "8bfd0f6e12abf2d2d697ecc888e5e90b0d6741d6708f05799f53afa560452e8f", 9350798360),
    "vae": ("vae/qwen_image_2.1_vae_bf16.safetensors", "vae/qwen-image-2.1/qwen_image_2.1_vae_bf16.safetensors",
            "bb21f7473051e1ac368515dd3f2e15cd44d7a11748ee8823e1ddca3e4876b7c9", 675509688),
    "turbo": ("loras/qwen_image_2.1_turbo_lora_avg_rank_178_bf16.safetensors",
              "loras/qwen-image-2.1/qwen_image_2.1_turbo_lora_avg_rank_178_bf16.safetensors",
              "208dd43250e1e01467ba190572ae2e7107a7870ec1ff026bc65f791fa1e80e95", 913314512),
}
# Sigmas de la version Turbo (8 étapes) : euler / simple donne de mauvais résultats avec elle.
SIGMAS_TURBO_QWEN21 = "1.0, 0.978453, 0.95418, 0.926626, 0.89508, 0.845148, 0.704534, 0.414568, 0.0"
NOMS_OFFICIELS = {"qwen_image_2.1_int8_convrot.safetensors": "Qwen Image 2.1 (officiel, int8)",
                  "4dd965496e5b1b83cd13.safetensors": "10Eros Max beta 5 (TURBO hybrid, int8)",
                  "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors": "Wan 2.2 image→vidéo (officiel, fp8) · haut bruit",
                  "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors": "Wan 2.2 image→vidéo (officiel, fp8) · bas bruit",
                  "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors": "Wan 2.2 rapide (lightx2v 4 étapes) · haut bruit",
                  "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors": "Wan 2.2 rapide (lightx2v 4 étapes) · bas bruit"}

# Wan 2.2 image → vidéo (onglet Animer) : fichiers officiels Comfy-Org (licence Apache 2.0), modèle 14B en fp8
# (deux moitiés : « haut bruit » puis « bas bruit »), LoRA lightx2v 4 étapes (mode rapide), VAE Wan 2.1, encodeur UMT5.
# Empreintes SHA-256 relevées le 18/10/2026 sur les pages des fichiers ; réglages = modèle officiel ComfyUI
# « video_wan2_2_14B_i2v » (shift 5, euler/simple, 16 i/s, 20 étapes CFG 3,5 coupées à 10, ou 4 étapes CFG 1 coupées à 2).
WAN22 = {   # clé : (dépôt, chemin sur Hugging Face, destination sous models/, SHA-256, taille approximative)
    "haut": ("Comfy-Org/Wan_2.2_ComfyUI_Repackaged", "split_files/diffusion_models/wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
             "diffusion_models/wan-2.2/wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
             "6122e79d55e0f235698d11d657f3b196c5273c830da00b2b013c5a048d5e6a42", 14294742832),
    "bas": ("Comfy-Org/Wan_2.2_ComfyUI_Repackaged", "split_files/diffusion_models/wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
            "diffusion_models/wan-2.2/wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
            "5471a457b6ac404202a5fbe6c11595a3d5641fc766b00f38763f72303fffc21e", 14294742832),
    "rapide_haut": ("Comfy-Org/Wan_2.2_ComfyUI_Repackaged", "split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
                    "loras/wan-2.2/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
                    "d176c808d6fc461999b68e321efcb7501b20b8c3797523ed0df14f7d1deff11e", 1230000000),
    "rapide_bas": ("Comfy-Org/Wan_2.2_ComfyUI_Repackaged", "split_files/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
                   "loras/wan-2.2/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
                   "024f21de095bc8fad9809ded3e9e49a2e170dcf27075da8145ba7d60d8aab7f9", 1230000000),
    "vae": ("Comfy-Org/Wan_2.2_ComfyUI_Repackaged", "split_files/vae/wan_2.1_vae.safetensors",
            "vae/wan-2.2/wan_2.1_vae.safetensors",
            "2fc39d31359a4b0a64f55876d8ff7fa8d780956ae2cb13463b0223e15148976b", 254000000),
    "te": ("Comfy-Org/Wan_2.1_ComfyUI_repackaged", "split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
           "text_encoders/wan-2.2/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
           "c3355d30191f1f066b26d93fba017ae9809dce6c627dda5f6a66eaa651204f68", 6740000000),
}
WAN22_NEGATIF = ("色调艳丽，过曝，静态，细节模糊不清，字幕，风格，作品，画作，画面，静止，整体发灰，最差质量，低质量，JPEG压缩残留，丑陋的，残缺的，"
                 "多余的手指，画得不好的手部，画得不好的脸部，畸形的，毁容的，形态畸形的肢体，手指融合，静止不动的画面，杂乱的背景，三条腿，背景人很多，倒着走")


# MiniMax H3 image → vidéo avec son (onglet Animer) : fichiers Comfy-Org/MiniMax-H3, révision figée, ceux du modèle
# officiel ComfyUI « video_minimax_h3_i2v » (modèle élagué int8, encodeur Qwen3-VL 32B nvfp4, VAE vidéo int8 et audio,
# LoRA Turbo 8 étapes). Empreintes SHA-256 relevées le 18/10/2026 sur les pages des fichiers.
# Licence « MiniMax H3 Community License » : territoire excluant l'Union européenne, le Royaume-Uni, la Corée du Sud
# et les États-Unis (utilisation, hébergement et résultats) ; affichée avant l'installation.
H3_DEPOT, H3_REV = "Comfy-Org/MiniMax-H3", "e5eb578a89295337b8ff433a035929ce0279e0b6"
H3 = {   # clé : (chemin sur Hugging Face, destination sous models/, SHA-256, taille approximative)
    "modele": ("diffusion_models/minimax_h3_fl2va_pruned_int8_convrot.safetensors",
               "diffusion_models/minimax-h3/minimax_h3_fl2va_pruned_int8_convrot.safetensors",
               "e889202c41dafb67b10d67b97f0d8541508036a6090af23425a5c2615d03c47a", 21_000_000_000),
    "te": ("text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
           "text_encoders/minimax-h3/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
           "35a88d51044231fe332301d7a62aa81e3f2cba62febeb446e2c1e3e0ef76f2c6", 15_700_000_000),
    "vae": ("vae/minimax_h3_video_vae_int8_convrot.safetensors",
            "vae/minimax-h3/minimax_h3_video_vae_int8_convrot.safetensors",
            "52a2c8c73583c86e4f41cdcce3a6ad0ea562987bc0bf3d60a0cef5f5c8e60c0e", 2_810_000_000),
    "vae_audio": ("vae/minimax_h3_audio_vae_fp32.safetensors",
                  "vae/minimax-h3/minimax_h3_audio_vae_fp32.safetensors",
                  "8e505d95dd1561d47abd43d4238fd40d9bb1ae9e147ed0a4cba778d76ae4db48", 605_000_000),
    "turbo": ("loras/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
              "loras/minimax-h3/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
              "2339acdf19bfe123f46b971ea35d367a84adb85de43627e1eceafa5a5b2b111e", 1_960_000_000),
    # « ref2va » (modèle officiel « video_minimax_h3_r2v ») : nouvelle scène d'après des images de référence
    "ref_modele": ("diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors",
                   "diffusion_models/minimax-h3/minimax_h3_ref2va_pruned_int8_convrot.safetensors",
                   "9255f52b6677845ad238f20dfaafa94727053694127ab7f255c048f0f9365779", 21_000_000_000),
    "ref_turbo": ("loras/minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors",
                  "loras/minimax-h3/minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors",
                  "5b9ab5ade15d0775676d01a907268a69a1468dc6033b3b0d3ded5502f3ebb84c", 1_960_000_000),
}
# 10Eros Max beta 5 (TenStrip) : fusion communautaire de MiniMax H3 orientée adulte, accélération intégrée (6 à 8 étapes),
# fichier « TURBO-hybrid » int8 conseillé par son auteur ; empreinte relevée le 18/10/2026, révision figée.
# Utilisé comme l'auteur : en mode références, l'image de départ étant aussi « verrouillée » sur la 1re image.
EROS = {"depot": "TenStrip/10Eros-Max", "rev": "b0070d3c9fb8b25c4b954aeb740e2f80924040df",
        "chemin": "10Eros_Max_h3_TURBO-hybrid_beta5_int8.safetensors",
        "sha": "4dd965496e5b1b83cd13c65cbe7a535b8a4d94ae768a7646b4e336d52c4781cf", "taille": 21_000_000_000}
# sur le disque, un nom anonyme (début de l'empreinte), comme les modèles de Civitai : le nom d'origine en dit trop
EROS["rel"] = f"diffusion_models/minimax-h3/{EROS['sha'][:20]}.safetensors"
EROS_PAS = 8
H3_I2V = ("modele", "te", "vae", "vae_audio", "turbo")
H3_REF = ("ref_modele", "te", "vae", "vae_audio", "ref_turbo")
H3_MAX_REFS = 9
H3_FPS = 24


EROS_ANCIEN = "diffusion_models/minimax-h3/10Eros_Max_h3_TURBO-hybrid_beta5_int8.safetensors"


def eros_present():
    neuf = os.path.join(C.MODELS, EROS["rel"])
    ancien = os.path.join(C.MODELS, EROS_ANCIEN)
    if not os.path.isfile(neuf) and os.path.isfile(ancien):
        try:   # installé par une version précédente sous son nom d'origine : simple renommage, rien n'est retéléchargé
            os.rename(ancien, neuf)
        except OSError:
            pass
    return os.path.isfile(neuf)


def _installer_eros():
    t = getattr(_progres, "travail", None)
    if eros_present():
        return
    if t is not None:
        t["attendu"], t["detail"], t["fichier"] = EROS["taille"], "10Eros Max beta 5", None
    if shutil.disk_usage("/workspace").free < EROS["taille"] * 1.05:
        raise C.Erreur("Espace disque insuffisant sur /workspace.")
    verifie(C.installer_depuis_hf, EROS["depot"], EROS["chemin"], EROS["rel"], EROS["sha"], rev=EROS["rev"],
            nom=os.path.basename(EROS["rel"]))


def h3_present(k):
    return os.path.isfile(os.path.join(C.MODELS, H3[k][1]))


def _installer_h3(parties):
    t = getattr(_progres, "travail", None)
    for k in parties:
        chemin, rel, sha, taille = H3[k]
        if os.path.isfile(os.path.join(C.MODELS, rel)):
            continue
        if t is not None:
            t["attendu"], t["detail"], t["fichier"] = taille, f"MiniMax H3 : {os.path.basename(rel)}", None
        if shutil.disk_usage("/workspace").free < taille * 1.05:
            raise C.Erreur("Espace disque insuffisant sur /workspace.")
        verifie(C.installer_depuis_hf, H3_DEPOT, chemin, rel, sha, rev=H3_REV, nom=os.path.basename(rel))


def wan22_present(k):
    return os.path.isfile(os.path.join(C.MODELS, WAN22[k][2]))


def _installer_wan22(parties):
    t = getattr(_progres, "travail", None)
    for k in parties:
        depot, chemin, rel, sha, taille = WAN22[k]
        if t is not None:
            t["attendu"], t["detail"] = taille, f"Wan 2.2 : {os.path.basename(rel)}"
            t["fichier"] = None
        if shutil.disk_usage("/workspace").free < taille * 1.05 and not os.path.isfile(os.path.join(C.MODELS, rel)):
            raise C.Erreur("Espace disque insuffisant sur /workspace.")
        verifie(C.installer_depuis_hf, depot, chemin, rel, sha, rev="main", nom=os.path.basename(rel))


def composants_manquants(fam):
    c = COMPOSANTS.get(fam)
    if not c:
        return False
    return not (C.chercher_installe("text_encoders", c["te"]) and C.chercher_installe("vae", c["vae"]))


def _installer_qwen21(parties):
    t = getattr(_progres, "travail", None)
    for k in parties:
        chemin, rel, sha, taille = QWEN21[k]
        if t is not None:
            t["attendu"], t["detail"] = taille, f"Qwen Image 2.1 : {os.path.basename(rel)}"
            t["fichier"] = None
        if shutil.disk_usage("/workspace").free < taille * 1.05 and not os.path.isfile(os.path.join(C.MODELS, rel)):
            raise C.Erreur("Espace disque insuffisant sur /workspace.")
        depot, rev = QWEN21_DEPOTS.get(k, (QWEN21_DEPOT, "main"))
        verifie(C.installer_depuis_hf, depot, chemin, rel, sha, rev=rev, nom=os.path.basename(rel))


# LoRA de variété « SDA » pour Krea 2 Turbo (F16/krea2-turbo-sda, licence Krea 2 Community) : installé d'office avec
# Krea 2 ou un fine-tune Krea 2 (désactivable dans Créer). Fichier figé sur un commit, empreinte relevée le 18/10/2026.
SDA_KREA2 = ("F16/krea2-turbo-sda", "cd6ffc8fbbbc4b07be023524c133905eed9c0fae", "krea2_turbo_sda_v1.0_comfy.safetensors",
             "loras/krea-2/krea2_turbo_sda_v1.0_comfy.safetensors",
             "0fafed045c53c4acd6165eb55da6ec04b24785b1eeed6f1be37b2cdcb66dba2b", 469315664)


def sda_installe():
    return os.path.isfile(os.path.join(C.MODELS, SDA_KREA2[3])) or bool(C.chercher_installe("loras", ["sda"]))


def installer_sda():
    """Ne fait jamais échouer l'installation du modèle : en cas de problème, un message dans le journal."""
    if sda_installe():
        return
    depot, rev, chemin, rel, sha, taille = SDA_KREA2
    t = getattr(_progres, "travail", None)
    if t is not None:
        t["attendu"], t["detail"], t["fichier"] = taille, "LoRA de variété Krea 2 (SDA)", None
    try:
        journal("LoRA de variété Krea 2 (SDA, Hugging Face)")
        verifie(C.installer_depuis_hf, depot, chemin, rel, sha, rev=rev, nom=os.path.basename(rel))
        VERSION_MODELES[0] += 1
    except Exception as e:
        journal(f"LoRA de variété Krea 2 non installé : {e}")


def installer_composants(fam):
    t = getattr(_progres, "travail", None)
    if t is not None and composants_manquants(fam):
        t["attendu"] = None
        t["detail"] = f"Composants officiels {COMPOSANTS[fam]['nom']}"
    if fam == "krea2" and composants_manquants("krea2"):
        journal("Composants officiels Krea 2 (Hugging Face)")
        verifie(C.cmd_krea2, nom="composants Krea 2")
    if fam == "krea2":
        installer_sda()
    if fam == "flux2" and composants_manquants("flux2"):
        journal("Composants officiels Flux.2 Klein (Hugging Face)")
        verifie(C.cmd_flux2, nom="composants Flux.2 Klein")
    elif fam == "wan22":
        # fine-tune Wan 2.2 installé depuis Civitai : encodeur UMT5 et VAE officiels s'ils manquent
        # (pas les moitiés officielles ni le LoRA rapide : le fine-tune les remplace)
        manque = [k for k, mots in (("te", ["umt5_xxl"]), ("vae", ["wan_2.1_vae"]))
                  if not wan22_present(k) and not C.chercher_installe("text_encoders" if k == "te" else "vae", mots)]
        if manque:
            journal("Composants officiels Wan 2.2 (Hugging Face)")
            _installer_wan22(manque)
    elif fam == "qwen21":
        manque = [k for k in ("te", "vae", "turbo") if not os.path.isfile(os.path.join(C.MODELS, QWEN21[k][1]))]
        deja = {"te": C.chercher_installe("text_encoders", COMPOSANTS["qwen21"]["te"]),
                "vae": C.chercher_installe("vae", COMPOSANTS["qwen21"]["vae"])}
        manque = [k for k in manque if not deja.get(k)]
        if manque:
            journal("Composants officiels Qwen Image 2.1 (Hugging Face)")
            _installer_qwen21(manque)


def op_installer_officiel(d):
    """Installation en un geste d'un ensemble officiel :
    qwen21 : Qwen Image 2.1 (modèle, encodeur de texte, VAE et LoRA Turbo, ≈ 18 Go) ;
    wan22  : Wan 2.2 image → vidéo (deux moitiés fp8, LoRA rapides, VAE, encodeur UMT5, ≈ 38 Go) ;
    h3     : MiniMax H3 image → vidéo avec son (modèle int8, encodeur, deux VAE, LoRA Turbo, ≈ 42 Go) ;
    h3ref  : MiniMax H3 d'après des références (modèle ref2va, LoRA Turbo ; encodeur et VAE s'ils manquent, ≈ 23 à 42 Go) ;
    eros   : 10Eros Max beta 5 (encodeur et VAE de MiniMax H3 s'ils manquent, ≈ 21 à 40 Go)."""
    quoi = d.get("quoi") if d.get("quoi") in ("qwen21", "wan22", "h3", "h3ref", "eros") else "qwen21"
    with VERROU:
        en_cours = [t for t in TRAVAUX.values() if t["type"] == "officiel" and t.get("quoi") == quoi
                    and t["etat"] in ("attente", "encours")]
    if en_cours:
        return {"travail": en_cours[0]["id"]}
    titre = {"qwen21": "Qwen Image 2.1", "wan22": "Wan 2.2 (vidéo)", "h3": "MiniMax H3 (vidéo)",
             "h3ref": "MiniMax H3 références (vidéo)", "eros": "10Eros Max (vidéo)"}[quoi]
    t = nouveau_travail("officiel", titre, liste=bool(d.get("liste")), quoi=quoi)
    t["_hf"] = (d.get("jetons") or {}).get("hf")

    def fn(t):
        if quoi == "h3":
            _installer_h3(["te", "vae", "vae_audio", "turbo", "modele"])
            return {"liens": [{"lien": "studio:h3", "nom": "MiniMax H3 image → vidéo (≈ 42 Go)"}]}
        if quoi == "eros":
            _installer_h3(["te", "vae", "vae_audio"])
            _installer_eros()
            return {"liens": [{"lien": "studio:eros", "nom": "10Eros Max beta 5 (MiniMax H3, ≈ 21 Go)"}]}
        if quoi == "h3ref":
            _installer_h3(["te", "vae", "vae_audio", "ref_turbo", "ref_modele"])
            return {"liens": [{"lien": "studio:h3ref", "nom": "MiniMax H3 d'après des références (≈ 23 Go de plus)"}]}
        if quoi == "wan22":
            _installer_wan22(["te", "vae", "rapide_haut", "rapide_bas", "haut", "bas"])
            return {"liens": [{"lien": "studio:wan22", "nom": "Wan 2.2 image → vidéo (officiel, ≈ 38 Go)"}]}
        _installer_qwen21(["modele", "te", "vae", "turbo"])
        return {"liens": [{"lien": "studio:qwen21", "nom": "Qwen Image 2.1 (officiel, ≈ 18 Go)"}]}
    mettre_en_file(t, fn)
    return {"travail": t["id"]}


# Adaptateurs communautaires pour Krea 2 (LoRA « fonctionnels » qui ont chacun besoin de leur extension ComfyUI,
# relue et livrée dans le paquet du Pod : voir extensions/SOURCES.txt). Fichiers figés sur un commit précis,
# vérifiés par leur empreinte SHA-256 (relevée sur la page du fichier et dans le SHA256SUMS du dépôt).
#   identite : retouche par consigne qui garde la ressemblance (extension Krea2Edit)
#   anypaint : inpainting / outpainting sur masque, pixels hors masque préservés (extension Krea2 AnyPaint)
#   reid     : nouvelle image d'une personne d'après une photo de référence (extension Ostris Edit)
ADAPTATEURS = {
    "identite": {"nom": "Krea 2 Identity Edit", "version": "v1.2", "go": "1,8 Go", "signature": "identity_edit",
                 "depot": "conradlocke/krea2-identity-edit", "rev": "89e9e7a09ee2e5c9331e952063d79b1b8a703280",
                 "chemin": "krea2_identity_edit_v1_2.safetensors", "rel": "loras/krea-2/krea2_identity_edit_v1_2.safetensors",
                 "sha": "6adf9a69cc9502d286db7b69964d37da7e9cfe4b05b4d004bc275f087d3fd3cf", "taille": 1_830_000_000},
    "anypaint": {"nom": "Krea 2 AnyPaint", "version": "rank 32", "go": "0,23 Go", "signature": "anypaint",
                 "depot": "yijunwang2/krea2-anypaint", "rev": "1a9fb37a304c27523939c44fc2b770c11472451b",
                 "chemin": "krea2_anypaint_rank32.safetensors", "rel": "loras/krea-2/krea2_anypaint_rank32.safetensors",
                 "sha": "3a7d09f6b27f8ead160d340f2f59c11f4ee635c4a1ee87ffd8b1b9f9ba412f7a", "taille": 229_000_000},
    "reid": {"nom": "Krea 2 ReID", "version": "rank 32", "go": "0,23 Go", "signature": "krea2_reid",
             "depot": "yijunwang2/krea2-reid", "rev": "121fb0183944f1befeb712d92e9ca07d0e282088",
             "chemin": "krea2_reid_rank32.safetensors", "rel": "loras/krea-2/krea2_reid_rank32.safetensors",
             "sha": "a80349faee4a2d80eff9a83820cd523c74cd0bbc6039cee21fa34b084d967944", "taille": 229_000_000},
}
IDENTITE = ADAPTATEURS["identite"]


def op_installer_adaptateur(d):
    """Installation en un geste d'un adaptateur Krea 2 (et des composants officiels de Krea 2 s'ils manquent)."""
    quoi = d.get("quoi") or "identite"
    a = ADAPTATEURS.get(quoi)
    if not a:
        raise C.Erreur("Adaptateur inconnu.")
    with VERROU:
        en_cours = [t for t in TRAVAUX.values() if t["type"] == "officiel" and t.get("quoi") == quoi
                    and t["etat"] in ("attente", "encours")]
    if en_cours:
        return {"travail": en_cours[0]["id"]}
    t = nouveau_travail("officiel", a["nom"], liste=bool(d.get("liste")), quoi=quoi)
    t["_hf"] = (d.get("jetons") or {}).get("hf")

    def fn(t):
        t["attendu"], t["detail"], t["fichier"] = a["taille"], f"{a['nom']} {a['version']}", None
        if shutil.disk_usage("/workspace").free < a["taille"] * 1.05 and \
                not os.path.isfile(os.path.join(C.MODELS, a["rel"])):
            raise C.Erreur("Espace disque insuffisant sur /workspace.")
        verifie(C.installer_depuis_hf, a["depot"], a["chemin"], a["rel"], a["sha"], rev=a["rev"],
                nom=os.path.basename(a["rel"]))
        installer_composants("krea2")   # encodeur Qwen3-VL 4B et VAE officiels, s'ils manquent
        return {"liens": [{"lien": f"studio:{quoi}", "nom": f"{a['nom']} {a['version']} (≈ {a['go']})"}]}
    mettre_en_file(t, fn)
    return {"travail": t["id"]}


def op_installer_identite(d):
    return op_installer_adaptateur(dict(d, quoi="identite"))


def adaptateur_de(rel):
    """Nom de l'adaptateur Krea 2 correspondant à ce fichier LoRA, ou None."""
    s = signature(rel)
    return next((k for k, a in ADAPTATEURS.items() if a["signature"] in s), None)


# ---------------------------------------------------------------- inventaire des modèles
INFOS = {}            # chemin absolu -> {nom, mots, lien}
VERSION_MODELES = [0]


def _noms_journal():
    noms = {}
    try:
        with open(C.JOURNAL, encoding="utf-8") as f:
            for l in f:
                ch = l.rstrip("\n").split("\t")
                if len(ch) >= 5:
                    noms[ch[4]] = {"nom": ch[3], "lien": ch[2]}
    except OSError:
        pass
    return noms


_VARIANTES = {}   # (chemin, taille, date) -> variante, en mémoire vive
_MOTIFS_VARIANTE = (("nvfp4", "NVFP4"), ("mxfp4", "MXFP4"), ("fp8", "fp8"), ("e4m3", "fp8"), ("int8", "int8"),
                    ("bf16", "bf16"), ("fp16", "fp16"), ("fp32", "fp32"), ("w4a8", "w4a8"))
_TYPES_SAFETENSORS = {"F8_E4M3": "fp8", "F8_E5M2": "fp8", "BF16": "bf16", "F16": "fp16", "F32": "fp32", "I8": "int8",
                      "U8": "4 bits"}


def variante_fichier(chemin, origine=None):
    """Précision des poids : d'après le nom du fichier si elle y figure, sinon d'après le type majoritaire des
    tenseurs lu dans l'en-tête du .safetensors (seul l'en-tête est lu)."""
    nom = (origine or os.path.basename(chemin)).lower()
    for motif, lib in _MOTIFS_VARIANTE:
        if motif in nom:
            return lib
    try:
        st = os.stat(chemin)
    except OSError:
        return None
    cle = (chemin, st.st_size, st.st_mtime)
    if cle not in _VARIANTES:
        h = C.entete_safetensors(chemin) or {}
        poids = collections.Counter()
        for k, v in h.items():
            if k != "__metadata__" and isinstance(v, dict) and v.get("dtype"):
                n = 1
                for x in v.get("shape") or []:
                    n *= int(x)
                poids[v["dtype"]] += n
        dt = poids.most_common(1)[0][0] if poids else None
        _VARIANTES[cle] = _TYPES_SAFETENSORS.get(dt, dt.lower() if dt else None)
    return _VARIANTES[cle]


def sources_officielles():
    """Lien exact (dépôt et version) des fichiers installés par Studio lui-même."""
    m = {}
    for k, (chemin, rel, _, _) in QWEN21.items():
        depot, rev = QWEN21_DEPOTS.get(k, (QWEN21_DEPOT, "main"))
        m[rel] = f"https://huggingface.co/{depot}/blob/{rev}/{chemin}"
    for a in ADAPTATEURS.values():
        m[a["rel"]] = f"https://huggingface.co/{a['depot']}/blob/{a['rev']}/{a['chemin']}"
    for depot, chemin, rel, _, _ in WAN22.values():
        m[rel] = f"https://huggingface.co/{depot}/blob/main/{chemin}"
    m[SDA_KREA2[3]] = f"https://huggingface.co/{SDA_KREA2[0]}/blob/{SDA_KREA2[1]}/{SDA_KREA2[2]}"
    for chemin, rel, _, _ in H3.values():
        m[rel] = f"https://huggingface.co/{H3_DEPOT}/blob/{H3_REV}/{chemin}"
    m[EROS["rel"]] = f"https://huggingface.co/{EROS['depot']}/blob/{EROS['rev']}/{EROS['chemin']}"
    for url, rel, _ in C.KREA2:
        m[rel] = url.replace("/resolve/", "/blob/")
    for depot, chemin, rel, _ in C.FLUX2:
        m[rel] = f"https://huggingface.co/{depot}/blob/main/{chemin}"
    return m


def op_supprimer_modele(d):
    """Supprime un fichier de modèle du disque du Pod (après confirmation dans l'application). Refusé pendant une
    génération ou un téléchargement, et pour tout chemin hors du dossier des modèles."""
    rel = str(d.get("chemin") or "")
    racine = os.path.realpath(C.MODELS)
    chemin = os.path.realpath(os.path.join(racine, rel))
    if not rel or not chemin.startswith(racine + os.sep) or not chemin.endswith(".safetensors") \
            or not os.path.isfile(chemin) or os.path.islink(os.path.join(racine, rel)):
        raise C.Erreur("Fichier introuvable dans le dossier des modèles.")
    with VERROU:
        occupe = [t for t in TRAVAUX.values() if t["etat"] in ("attente", "encours")
                  and t["type"] in ("generation", "telechargement", "image", "officiel")]
    if occupe:
        raise C.Erreur("Une génération ou un téléchargement est en cours : attends qu'il soit fini pour supprimer.")
    nom = os.path.basename(chemin)
    taille_mo = os.path.getsize(chemin) // 2**20
    os.remove(chemin)
    INFOS.pop(chemin, None)
    if ETAT.get("comfy"):
        try:   # ComfyUI libère la mémoire de la carte s'il gardait ce modèle chargé
            comfy_post("/free", {"unload_models": True, "free_memory": True}, timeout=10)
        except Exception:
            pass
    journal(f"Fichier supprimé à ta demande ({taille_mo} Mo).")   # jamais le nom : il peut dire ce que contient le modèle
    VERSION_MODELES[0] += 1
    return {"supprime": nom}


def inventaire():
    noms = _noms_journal()
    principaux, loras, embeddings, autres = [], [], [], []
    for racine, _, fichiers in os.walk(C.MODELS):
        for n in sorted(fichiers):
            if not n.endswith(".safetensors"):
                continue
            chemin = os.path.join(racine, n)
            try:
                taille = os.path.getsize(chemin)
            except OSError:
                continue
            rel = os.path.relpath(chemin, C.MODELS).replace(os.sep, "/")
            dossier = rel.split("/")[0]
            info = {**noms.get(chemin, {}), **INFOS.get(chemin, {})}
            e = {"rel": rel, "nom": info.get("nom") or NOMS_OFFICIELS.get(n) or os.path.splitext(n)[0], "go": go(taille),
                 "mo": round(taille / 1024 ** 2), "mots": info.get("mots") or [], "famille": famille(rel),
                 # détails affichés sous le nom : fichier exact, variante, source (tout vient de la mémoire vive)
                 "chemin": rel, "fichier": n, "origine": info.get("original") or None,
                 "variante": variante_fichier(chemin, info.get("original")),
                 "source": info.get("lien") or sources_officielles().get(rel)}
            if dossier in ("checkpoints", "diffusion_models"):
                if taille < 100 * 1024 ** 2:
                    continue
                e["video"] = e["famille"] in ("wan22", "h3")
                e["defauts"] = None if e["video"] else defauts(rel)
                if e["famille"] in COMPOSANTS:
                    e["composants"] = not composants_manquants(e["famille"])
                principaux.append(e)
            elif dossier == "loras":
                e["rel"] = rel.split("/", 1)[1]          # chemin attendu par les nœuds LoRA
                e["sda"] = e["famille"] == "krea2" and _mot("sda", signature(rel))
                e["reference"] = e["famille"] == "krea2" and "style_reference" in signature(rel)
                e["adaptateur"] = adaptateur_de(rel) if e["famille"] == "krea2" else None
                e["identite"] = e["adaptateur"] == "identite"
                if e["adaptateur"]:
                    e["nom"] = ADAPTATEURS[e["adaptateur"]]["nom"]
                e["turbo"] = e["famille"] == "qwen21" and "turbo" in signature(rel)
                if e["turbo"]:
                    e["nom"] = "Qwen Image 2.1 Turbo (officiel)"
                loras.append(e)
            elif dossier == "embeddings":
                e["ref"] = "embedding:" + os.path.splitext(n)[0]   # nom réel du fichier (anonyme)
                embeddings.append(e)
            else:
                autres.append(e)
    turbo = any(l["turbo"] for l in loras)
    for e in principaux:   # Qwen Image 2.1 : mode rapide possible avec le LoRA Turbo officiel (ou modèle Turbo)
        d = e.get("defauts") or {}
        e["rapide"] = e["famille"] == "qwen21" and (turbo or bool(d.get("turbo_integre")))
    qwen = any(e["famille"] == "qwen21" and e.get("composants") for e in principaux)
    return {"principaux": principaux, "loras": loras, "embeddings": embeddings, "autres": autres,
            "version": VERSION_MODELES[0], "qwen21": qwen, "identite": any(l["identite"] for l in loras),
            "adaptateurs": {l["adaptateur"]: l["rel"] for l in loras if l.get("adaptateur")},
            **inventaire_video(principaux, loras)}


_MOITIE = re.compile(r"(?<![a-z])(high|low)[\s_.-]*noise(?![a-z])|(?<![a-z])(high|low|haut|bas)(?![a-z])|(?<![a-z0-9])(hn|ln)(?![a-z0-9])")
_CIVITAI_MODELE = re.compile(r"/models/(\d+)")


def _cle_paire(texte):
    """Nom d'un fichier Wan 2.2 sans le mot qui distingue ses deux moitiés (high/low noise, haut/bas bruit)."""
    t = texte.lower()
    m = _MOITIE.search(t)
    if not m:
        return t, None
    mot = m.group(1) or m.group(2) or m.group(3)
    return t[:m.start()] + "#" + t[m.end():], ("haut" if mot in ("high", "haut", "hn") else "bas")


_MOITIE_CAMEL = re.compile(r"(?<=[a-z0-9])(High|Low)(?=[A-Z0-9_.\-]|$)")


def _cote(e):
    """Moitié d'un fichier Wan 2.2 : d'après son nom d'origine, son nom de fichier, puis le nom de sa version Civitai
    (« …_snatchkissLowV11_… » compris)."""
    for t in (e.get("origine"), e["fichier"], e.get("nom")):
        if t:
            cote = _cle_paire(t)[1]
            if not cote:
                m = _MOITIE_CAMEL.search(os.path.splitext(t)[0])
                cote = m and ("haut" if m.group(1) == "High" else "bas")
            if cote:
                return cote
    return None


def _sans_moitie(nom):
    """« Mon LoRA · WAN 2.2 I2V HIGH » → « Mon LoRA · WAN 2.2 I2V » : le nom d'une paire ne cite plus une moitié."""
    n = re.sub(r"\s*·\s*(haut|bas) bruit$", "", nom)
    n = re.sub(r"(?i)[\s_.-]*(?<![a-z])(high|low)(?![a-z])([\s_.-]*noise)?|[\s_.-]*(?<![a-z])(haut|bas)[\s_.-]*bruit", "", n)
    return n.strip(" _-.·") or nom


def _paires(elements, seuls=False):
    """Regroupe les fichiers Wan 2.2 par paire haut/bas bruit ; un fichier sans moitié sert aux deux.
    Moitiés publiées comme deux versions Civitai distinctes (noms différents) : réunies si elles viennent
    du même modèle Civitai et qu'il n'y en a qu'une de chaque côté. Avec seuls=True, les moitiés restées
    sans partenaire sont rendues aussi (« seul » = leur côté), pour que l'utilisateur choisisse l'autre."""
    groupes = {}
    for e in elements:
        cle, cote = _cle_paire((e.get("origine") or e["fichier"]) + "|" + os.path.dirname(e["chemin"]))
        cote = cote or _cote(e)
        if cote and "#" not in cle:
            cle = cle + "|" + cote + "#"
        g = groupes.setdefault(cle, {"nom": e["nom"], "_e": e})
        vu = e.get("origine") or e["fichier"]       # nom affiché pour vérifier quelle moitié reçoit quel fichier
        if cote:
            g[cote], g[cote + "_fichier"] = e["rel"], vu
            g["nom"] = _sans_moitie(e["nom"])
        else:
            g["haut"] = g["bas"] = e["rel"]
            g["haut_fichier"] = g["bas_fichier"] = vu
    complets = [g for g in groupes.values() if g.get("haut") and g.get("bas")]
    restes = [g for g in groupes.values() if not (g.get("haut") and g.get("bas"))]
    par_modele = {}
    for g in restes:
        m = _CIVITAI_MODELE.search(g["_e"].get("source") or "")
        if m:
            par_modele.setdefault(m.group(1), []).append(g)
    def unir(h, b):
        complets.append({"nom": _sans_moitie(h["nom"]), "haut": h["haut"], "bas": b["bas"], "_e": h["_e"],
                         "haut_fichier": h["haut_fichier"], "bas_fichier": b["bas_fichier"]})
        restes.remove(h); restes.remove(b)
    for lot in par_modele.values():
        # plusieurs versions du même modèle (« SnatchKiss High v11 », « SnatchKiss Low v11 », « BoundBite High v10 »…) :
        # d'abord par nom de version sans la moitié, puis, s'il ne reste qu'une moitié de chaque côté, ensemble
        par_nom = {}
        for g in lot:
            par_nom.setdefault(_sans_moitie(g["nom"]).lower(), []).append(g)
        for gs in par_nom.values():
            hauts, bas = [g for g in gs if g.get("haut")], [g for g in gs if g.get("bas")]
            if len(hauts) == 1 and len(bas) == 1:
                unir(hauts[0], bas[0])
        reste = [g for g in lot if g in restes]
        hauts, bas = [g for g in reste if g.get("haut")], [g for g in reste if g.get("bas")]
        if len(hauts) == 1 and len(bas) == 1:
            unir(hauts[0], bas[0])
    sortie = [dict(g, id=g["haut"]) for g in complets]
    if seuls:
        for g in restes:
            c = "haut" if g.get("haut") else "bas"
            sortie.append(dict(g, id=g[c], seul=c, nom=g["nom"] + f" · {c} bruit seul", **{"bas" if c == "haut" else "haut": None}))
    for g in sortie:
        g.pop("_e", None)
    return sortie


DASIWA_MODELE = 1981116   # DaSiWa Wan 2.2 I2V 14B « Lightspeed » (Civitai), modèle conseillé pour Animer
_VITESSE_INTEGREE = re.compile(r"(?i)lightspeed|lightx2v|lightning|light2x|4[\s_.-]*steps?|distill")


def inventaire_video(principaux, loras):
    """Onglet Animer : paires de modèles Wan 2.2 (officiel et fine-tunes), LoRA vidéo, composants présents."""
    wan = [e for e in principaux if e["famille"] == "wan22" and e["rel"].startswith("diffusion_models/")]   # chargés par UNETLoader
    lw = [l for l in loras if l["famille"] == "wan22"]
    rapides = {os.path.basename(WAN22[k][2]): k for k in ("rapide_haut", "rapide_bas")}
    for l in lw:
        l["wan_rapide"] = os.path.basename(l["rel"]) in rapides
    te = wan22_present("te") or bool(C.chercher_installe("text_encoders", ["umt5_xxl"]))
    vae = wan22_present("vae") or bool(C.chercher_installe("vae", ["wan_2.1_vae"]))
    modeles = _paires(wan)
    infos = {e["rel"]: e for e in wan}
    for m in modeles:
        m["officiel"] = m["haut"] == WAN22["haut"][2]
        e = infos.get(m["haut"]) or {}
        texte = f'{e.get("nom", "")} {e.get("origine") or ""} {e.get("fichier", "")}'
        m["conseille"] = f"/models/{DASIWA_MODELE}" in (e.get("source") or "") or "dasiwa" in texte.lower()
        # accélération (LoRA lightx2v / Lightning) déjà fondue dans le modèle : 4 étapes, CFG 1, pas de LoRA rapide en plus
        m["vitesse_integree"] = m["conseille"] or bool(_VITESSE_INTEGREE.search(texte))
    perso = [l for l in lw if not l["wan_rapide"]]
    h3_composants = all(h3_present(k) for k in ("te", "vae", "vae_audio"))
    if h3_present("modele"):
        modeles.append({"id": H3["modele"][1], "nom": "MiniMax H3 (int8, avec son)", "h3": True, "haut": H3["modele"][1],
                        "bas": H3["modele"][1], "officiel": False, "conseille": False, "vitesse_integree": False,
                        "pret": h3_composants, "rapide": h3_present("turbo")})
    if h3_present("ref_modele"):
        modeles.append({"id": H3["ref_modele"][1], "nom": "MiniMax H3 · d'après des références (avec son)", "h3": True,
                        "ref": True, "max_refs": H3_MAX_REFS, "haut": H3["ref_modele"][1], "bas": H3["ref_modele"][1],
                        "officiel": False, "conseille": False, "vitesse_integree": False,
                        "pret": h3_composants, "rapide": h3_present("ref_turbo")})
    if eros_present():
        base = {"h3": True, "eros": True, "haut": EROS["rel"], "bas": EROS["rel"], "officiel": False, "conseille": False,
                "vitesse_integree": True, "pret": h3_composants, "rapide": False}
        modeles.append(dict(base, id=EROS["rel"], nom="10Eros Max · image de départ"))
        modeles.append(dict(base, id=EROS["rel"] + "#ref", nom="10Eros Max · d'après des références",
                            ref=True, max_refs=H3_MAX_REFS))
    turbos_h3 = {H3["turbo"][1].split("/", 1)[1], H3["ref_turbo"][1].split("/", 1)[1]}
    loras_h3 = [{"id": l["rel"], "nom": l["nom"], "fichier": l.get("origine") or l["fichier"]}
                for l in loras if l["famille"] == "h3" and l["rel"] not in turbos_h3]
    for m in modeles:
        m.setdefault("pret", te and vae)
    return {"videos": {"modeles": modeles, "loras": _paires(perso, seuls=True),
                       # fichiers que l'on peut désigner à la main comme « autre moitié » d'un LoRA resté seul
                       "fichiers_lora": [{"rel": l["rel"], "nom": l["nom"], "fichier": l.get("origine") or l["fichier"]} for l in perso],
                       "rapide": all(wan22_present(k) for k in ("rapide_haut", "rapide_bas")),
                       "composants": te and vae,
                       "officiel": all(wan22_present(k) for k in WAN22),
                       "h3": all(h3_present(k) for k in H3_I2V), "h3ref": all(h3_present(k) for k in H3_REF),
                       "eros": eros_present() and h3_composants, "loras_h3": loras_h3}}


# ---------------------------------------------------------------- travaux (analyses, téléchargements)
VERROU = threading.RLock()     # TRAVAUX et IMAGES sont lus et modifiés par plusieurs fils
TRAVAUX = collections.OrderedDict()
FILE = collections.deque()
FILE_SIGNAL = threading.Condition()
PLANS = {}


def nouveau_travail(type_, titre, **extra):
    t = {"id": uuid.uuid4().hex[:12], "type": type_, "titre": titre, "etat": "attente", "detail": "",
         "erreur": None, "resultat": None, "fichier": None, "attendu": None, "cree": time.time(), **extra}
    with VERROU:
        TRAVAUX[t["id"]] = t
        while len(TRAVAUX) > 60:
            k = next(iter(TRAVAUX))
            if TRAVAUX[k]["etat"] in ("ok", "erreur", "arrete"):
                TRAVAUX.pop(k)
            else:
                break
    return t


def resume_travail(t):
    progres = None
    if t.get("fichier"):
        try:
            fait = os.path.getsize(t["fichier"])
            progres = {"fait": go(fait), "total": go(t["attendu"]) if t.get("attendu") else None}
        except OSError:
            pass
    r = {k: t.get(k) for k in ("id", "type", "titre", "etat", "detail", "erreur", "resultat", "liste", "fin", "quoi")}
    r["arretable"] = t["type"] in TYPES_ARRETABLES and t["etat"] in ("attente", "encours") and not t.get("_annuler")
    r["progres"] = progres
    if t["type"] == "generation":
        r.update({k: t.get(k) for k in ("total", "faites", "images", "debut_image")})
    return r


def mettre_en_file(t, fonction):
    t["_fn"] = fonction
    with FILE_SIGNAL:
        FILE.append(t)
        FILE_SIGNAL.notify()


def ouvrier():
    """Exécute les téléchargements un par un, dès que le dossier des modèles existe."""
    while True:
        with FILE_SIGNAL:
            while not FILE:
                FILE_SIGNAL.wait()
            t = FILE.popleft()
        DOSSIER_MODELES_PRET.wait()
        executer_travail(t, t.pop("_fn"))


def executer_travail(t, fonction):
    with VERROU:
        if t["etat"] == "arrete":   # arrêté pendant qu'il attendait son tour
            return
        t["etat"] = "encours"
    _progres.travail = t
    _jeton_hf.v = t.pop("_hf", None)
    try:
        if not TEST:
            C.exiger_zone()
        t["resultat"] = fonction(t)
        t["etat"] = "ok"
        t["fin"] = time.time()
    except Annule:
        t.update(etat="arrete", erreur=None, detail="Arrêté", fin=time.time())
        journal("Téléchargement arrêté à ta demande (fichier partiel effacé).")
    except C.Erreur as e:
        t.update(etat="erreur", erreur=str(e))
    except Exception as e:
        t.update(etat="erreur", erreur=f"{type(e).__name__} : {e}")
        journal(f"ERREUR ({t['type']}) : {e}")
    finally:
        _progres.travail = None
        _jeton_hf.v = None
        t.pop("_civitai", None)
        VERSION_MODELES[0] += 1


def analyse_async(t, fonction):
    t["_fn"] = fonction
    threading.Thread(target=lambda: executer_travail(t, t.pop("_fn")), daemon=True).start()


def lien_civitai(plan):
    return f"https://civitai.red/models/{plan['mid']}?modelVersionId={plan['vid']}"


def resume_plan(p):
    fichiers = []
    for i, f in enumerate(p["fichiers"]):
        meta = f.get("metadata") or {}
        fichiers.append({"i": i, "nom": f.get("name"), "go": round(C.go(f.get("sizeKB")), 2),
                         "precision": meta.get("fp") or "", "variante": meta.get("size") or "",
                         "danger": f.get("virusScanResult") == "Danger" or f.get("pickleScanResult") == "Danger"})
    fam = famille("/" + C.slug(p["base"]) + "/") if p["type"] == "Checkpoint" else None
    return {"nom": p["nom"], "type": p["type"], "base": p["base"], "createur": p["createur"], "maj": p["maj"],
            "licence": p["licence"], "mots": p["mots"][:12], "fichiers": fichiers, "choix": p["choix"],
            "poids": p.get("poids"), "lien": lien_civitai(p),
            "composants": COMPOSANTS[fam]["nom"] if fam in COMPOSANTS and composants_manquants(fam) else None,
            "paire_wan": bool(_indices_paire(p)),
            "klein4b": fam == "flux2" and "4b" in C.slug(p["base"])}


def _nom_anonyme(sha):
    return sha[:20].lower() + ".safetensors"


def _indices_paire(plan):
    """Wan 2.2 : une version Civitai contient souvent ses deux moitiés (high noise et low noise) ; on prend les deux."""
    if not est_wan22(f"{plan.get('base') or ''} {plan.get('nom') or ''}"):
        return None
    cotes = {}
    for i, f in enumerate(plan["fichiers"]):
        _, cote = _cle_paire(f.get("original") or f.get("name") or "")
        if cote and cote not in cotes:
            cotes[cote] = i
    return [cotes["haut"], cotes["bas"]] if len(cotes) == 2 else None


def _executer_plan(plan, token):
    paire = _indices_paire(plan)
    if paire:
        dest = None
        for i in paire:
            plan["choix"] = i
            dest = _executer_un(plan, token)
        return dest
    return _executer_un(plan, token)


def _executer_un(plan, token):
    f = plan["fichiers"][plan["choix"]]
    original = f.get("original") or f.get("name") or ""
    sha = ((f.get("hashes") or {}).get("SHA256") or "").lower()
    if plan["type"] != "Workflows" and len(sha) == 64:
        f["original"] = original
        f["name"] = _nom_anonyme(sha)   # le disque ne voit qu'une empreinte, jamais le nom du modèle
    dest = verifie(C.executer, plan, token, nom=f.get("name"))
    plan["dest"] = dest
    INFOS[dest] = {"nom": plan["nom"], "mots": plan.get("mots") or [], "lien": lien_civitai(plan),
                   "original": original}
    if plan["type"] == "Checkpoint":
        installer_composants(famille(os.path.relpath(dest, C.MODELS)))
    return dest


def op_analyser(d):
    lien = (d.get("lien") or "").strip()
    jet = d.get("jetons") or {}
    if "huggingface.co" in lien:
        t = nouveau_travail("analyse", "Analyse du lien Hugging Face")
        t["_hf"] = jet.get("hf")
        analyse_async(t, lambda t: analyser_hf(lien))
        return {"travail": t["id"]}
    genre, mid, vid = C.analyser_lien(lien)
    tok = jet.get("civitai") or None
    t = nouveau_travail("analyse", "Analyse de l'image Civitai" if genre == "image" else "Analyse du modèle Civitai")
    if genre == "image":
        analyse_async(t, lambda t: analyser_image(mid, lien, tok))
    else:
        analyse_async(t, lambda t: analyser_modele(mid, vid, tok))
    return {"travail": t["id"]}


def analyser_modele(mid, vid, tok):
    note = None
    if vid is None:
        versions = C.api_get(f"/models/{mid}", tok).get("modelVersions") or []
        if not versions:
            raise C.Erreur("Aucune version publiée pour ce modèle.")
        vid = versions[0]["id"]
        note = "Le lien ne précise pas de version : la plus récente est proposée."
    plan = C.preparer(vid, C.profil_gpu(), tok)
    if plan["type"] == "Workflows":
        raise C.Erreur("C'est un workflow ComfyUI : le Studio construit lui-même ses réglages, inutile de le télécharger.")
    pid = uuid.uuid4().hex[:12]
    PLANS[pid] = {"genre": "modele", "plan": plan}
    return {"genre": "modele", "plan": pid, "modele": resume_plan(plan), "note": note}


def analyser_image(iid, lien, tok):
    data = C.api_get(f"/images?imageId={iid}&withMeta=true&nsfw=X", tok)
    items = data.get("items") or []
    if not items:
        raise C.Erreur("Image introuvable : privée, supprimée, ou filtrée (vérifie ta clé Civitai dans Réglages).")
    it = items[0]
    meta = it.get("meta") or {}
    if isinstance(meta.get("meta"), dict):
        meta = meta["meta"]
    ressources, types_decl = {}, {}
    for r in meta.get("civitaiResources") or []:
        if r.get("modelVersionId"):
            ressources.setdefault(int(r["modelVersionId"]), r.get("weight"))
            types_decl[int(r["modelVersionId"])] = (r.get("type") or "").lower()
    for v in it.get("modelVersionIds") or []:
        ressources.setdefault(int(v), None)
    manquants = []
    hachages = [(r.get("hash"), r.get("weight"), r.get("name"), (r.get("type") or "").lower())
                for r in meta.get("resources") or [] if r.get("hash")]
    if meta.get("Model hash"):
        hachages.append((meta["Model hash"], None, meta.get("Model"), "model"))
    for h, w, n, ty in hachages:
        try:
            v = C.api_get(f"/model-versions/by-hash/{h}", tok)
            ressources.setdefault(int(v["id"]), w)
        except C.Erreur:
            manquants.append({"nom": n or "nom inconnu", "type": ty, "poids": w,
                              "raison": "inconnue de Civitai (supprimée ou jamais publiée)"})
    plans = []
    for v, w in ressources.items():
        try:
            plans.append(C.preparer(v, C.profil_gpu(), tok, poids=w))
        except C.Erreur as e:
            manquants.append({"nom": f"version {v}", "type": types_decl.get(v, ""), "poids": w, "raison": str(e)})
    pid = uuid.uuid4().hex[:12]
    PLANS[pid] = {"genre": "image", "plans": plans, "meta": meta, "base": it.get("baseModel") or "",
                  "manquants": manquants}
    reglages = {k: meta.get(k) for k in ("prompt", "negativePrompt", "seed", "steps", "cfgScale", "sampler", "Size")}
    nb_bases = sum(1 for p in plans if p["type"] == "Checkpoint")
    return {"genre": "image", "plan": pid, "base": it.get("baseModel") or "?", "reglages": reglages,
            "ressources": [resume_plan(p) for p in plans], "manquants": manquants,
            "avertissement": (f"{nb_bases} modèles de base sont cités : un seul a servi. Garde celui affiché sur la "
                              "page de l'image.") if nb_bases > 1 else None}


DOSSIERS_HF = ["loras", "checkpoints", "diffusion_models", "text_encoders", "vae", "embeddings", "controlnet",
               "upscale_models"]
ARCHIS = ["krea-2", "flux.2-klein-9b", "qwen-image-2.1", "wan-2.2", "minimax-h3", "pony", "illustrious", "sdxl-1.0", "sd-1.5", "autre"]


def deviner_archi(texte):
    s = texte.lower()
    if est_qwen21(s):
        return "qwen-image-2.1"
    if est_wan22(s):
        return "wan-2.2"   # vidéo (onglet Animer) : fine-tunes et LoRA Wan 2.2
    if "minimax" in s or "10eros" in s or re.search(r"(?<![a-z0-9])h3(?![a-z0-9])", s):
        return "minimax-h3"   # vidéo avec son (onglet Animer) : LoRA MiniMax H3
    for mot, a in (("krea", "krea-2"), ("klein", "flux.2-klein-9b"), ("pony", "pony"), ("illustrious", "illustrious"),
                   ("noob", "illustrious"), ("sdxl", "sdxl-1.0"), ("xl", "sdxl-1.0"), ("sd15", "sd-1.5"),
                   ("sd1.5", "sd-1.5"), ("sd-1.5", "sd-1.5")):
        if mot in s:
            return a
    return "autre"


def deviner_dossier(entete):
    cles = [k for k in entete if k != "__metadata__"]
    if not cles:
        return "loras"
    if any("lora_" in k or ".lora." in k or "lora_down" in k or "lora_up" in k or k.endswith(".alpha") for k in cles):
        return "loras"
    if any(k in ("clip_l", "clip_g", "emb_params", "string_to_param") or k.startswith("string_to_param") for k in cles):
        return "embeddings"
    if any(k.startswith(("first_stage_model.", "vae.")) for k in cles):
        return "checkpoints"
    if all(k.startswith(("encoder.", "decoder.", "quant_conv", "post_quant_conv")) for k in cles):
        return "vae"
    if any(k.startswith(("model.layers.", "text_model.", "encoder.block", "model.language_model", "language_model.",
                         "model.embed_tokens", "shared.", "visual.")) for k in cles):
        return "text_encoders"
    return "diffusion_models"


def entete_distante(url, tok):
    """Lit l'en-tête d'un .safetensors distant (quelques Ko) pour en déduire le type."""
    cfg = f'header = "Authorization: Bearer {tok}"\n' if tok else ""
    def plage(a, b):
        r = subprocess.run(["curl", "-sS", "-f", "-L", "--connect-timeout", "20", "-K", "-", "-r", f"{a}-{b}", url],
                           input=cfg.encode(), capture_output=True, timeout=60)
        if r.returncode != 0:
            raise C.Erreur("lecture de l'en-tête impossible")
        return r.stdout
    n = int.from_bytes(plage(0, 7)[:8], "little")
    if n <= 0 or n > 8 * 1024 * 1024:
        raise C.Erreur("en-tête inhabituel")
    return json.loads(plage(8, 8 + n - 1)[:n])


def analyser_hf(lien):
    depot, rev, chemin = C.analyser_lien_hf(lien)
    tok = C.token_hf()
    try:
        info = C.api_get(f"https://huggingface.co/api/models/{depot}", tok)
    except C.Erreur as e:
        raise C.Erreur(f"Dépôt inaccessible ({e}). S'il est protégé : accepte ses conditions sur huggingface.co "
                       "et vérifie ton jeton Hugging Face dans Réglages.")
    parent = os.path.dirname(chemin)
    url_arbre = f"https://huggingface.co/api/models/{depot}/tree/{rev}" + (f"/{urllib.parse.quote(parent)}" if parent else "")
    entree = next((e for e in C.api_get(url_arbre, tok) if e.get("path") == chemin), None)
    if not entree:
        raise C.Erreur(f"Fichier introuvable dans le dépôt : {chemin}")
    sha = ((entree.get("lfs") or {}).get("oid") or "").lower()
    taille = (entree.get("lfs") or {}).get("size") or entree.get("size") or 0
    if len(sha) != 64:
        raise C.Erreur("Hugging Face ne publie pas d'empreinte SHA-256 pour ce fichier, vérification impossible.")
    url = f"https://huggingface.co/{depot}/resolve/{rev}/{urllib.parse.quote(chemin)}"
    try:
        dossier = deviner_dossier(entete_distante(url, tok))
    except Exception:
        dossier = "loras"
    carte = info.get("cardData") or {}
    pid = uuid.uuid4().hex[:12]
    PLANS[pid] = {"genre": "hf", "depot": depot, "rev": rev, "chemin": chemin, "sha": sha, "taille": taille}
    return {"genre": "hf", "plan": pid, "nom": f"{depot} — {os.path.basename(chemin)}", "auteur": info.get("author"),
            "licence": carte.get("license") or "?", "protege": bool(info.get("gated")), "go": go(taille),
            "sha": sha[:16], "dossier": dossier, "archi": deviner_archi(depot + " " + chemin),
            "dossiers": DOSSIERS_HF, "archis": ARCHIS,
            "lien": f"https://huggingface.co/{depot}/blob/{rev}/{chemin}"}


def installer_hf(depot, rev, chemin, sha, taille, dossier, archi, attendu=None):
    tok = C.token_hf()
    if attendu and not sha.startswith(attendu.lower()):
        raise C.Erreur("Ce fichier n'est pas celui attendu (empreinte différente). Rien n'a été téléchargé.")
    original = os.path.basename(chemin)
    nom = _nom_anonyme(sha)
    for racine, _, noms in os.walk(C.MODELS):
        if nom in noms and C.sha256(os.path.join(racine, nom)) == sha:
            dest = os.path.join(racine, nom)
            INFOS.setdefault(dest, {"nom": f"{depot.split('/')[-1]} — {os.path.splitext(original)[0]}", "mots": [],
                                    "original": original})
            journal(f"Déjà présent, empreinte vérifiée ✓ — {nom}")
            return dest
    if shutil.disk_usage("/workspace").free < taille * 1.05:
        raise C.Erreur("Espace disque insuffisant sur /workspace.")
    os.makedirs(C.TMP, exist_ok=True)
    os.makedirs(C.QUAR, exist_ok=True)
    tmp = os.path.join(C.TMP, nom + ".part")
    t = getattr(_progres, "travail", None)
    if t is not None:
        t["attendu"] = taille
        t["detail"] = "Téléchargement"
    C.telecharger(f"https://huggingface.co/{depot}/resolve/{rev}/{urllib.parse.quote(chemin)}", tmp, tok)
    if t is not None:
        t["detail"] = "Vérification de l'empreinte"
    if C.sha256(tmp) != sha:
        shutil.move(tmp, os.path.join(C.QUAR, f"{nom}.{int(time.time())}"))
        journal(f"Empreinte incorrecte ✗ — {nom} : mis en quarantaine, non installé.")
        raise C.Erreur("Empreinte incorrecte : fichier isolé en quarantaine.")
    journal(f"Empreinte vérifiée ✓ — {nom} ({_taille_lisible(tmp)})")
    entete = C.entete_safetensors(tmp)
    if entete is None:
        shutil.move(tmp, os.path.join(C.QUAR, nom))
        raise C.Erreur("Ce n'est pas un .safetensors valide : isolé en quarantaine.")
    if dossier not in DOSSIERS_HF:
        dossier = deviner_dossier(entete)
    if dossier in ("checkpoints", "diffusion_models"):
        dossier = C.dossier_checkpoint(entete)
    dest = (os.path.join(C.MODELS, dossier, nom) if dossier == "embeddings"
            else os.path.join(C.MODELS, dossier, C.slug(archi or "autre"), nom))
    if os.path.exists(dest):
        r, e = os.path.splitext(dest)
        dest = f"{r}_{sha[:8]}{e}"
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.move(tmp, dest)
    INFOS[dest] = {"nom": f"{depot.split('/')[-1]} — {os.path.splitext(original)[0]}", "mots": [], "original": original}
    with open(C.JOURNAL, "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M')}\thf\thttps://huggingface.co/{depot}/blob/{rev}/{chemin}\t"
                f"{INFOS[dest]['nom']}\t{dest}\n")
    if dossier in ("checkpoints", "diffusion_models"):
        installer_composants(famille(os.path.relpath(dest, C.MODELS)))
    return dest


def op_installer(d):
    pid = d.get("plan")
    P = PLANS.get(pid)
    if not P:
        raise C.Erreur("Analyse expirée : colle le lien à nouveau.")
    jet = d.get("jetons") or {}
    tok = jet.get("civitai") or None
    if P["genre"] == "modele":
        plan = P["plan"]
        if isinstance(d.get("fichier"), int) and 0 <= d["fichier"] < len(plan["fichiers"]):
            plan["choix"] = d["fichier"]
        f = plan["fichiers"][plan["choix"]]
        t = nouveau_travail("telechargement", plan["nom"], liste=bool(d.get("liste")))
        t["attendu"] = (f.get("sizeKB") or 0) * 1024

        def fn(t):
            t["detail"] = "Téléchargement"
            _executer_plan(plan, tok)
            return {"liens": [{"lien": lien_civitai(plan), "nom": plan["nom"]}]}
        mettre_en_file(t, fn)
        return {"travail": t["id"]}
    if P["genre"] == "hf":
        dossier, archi = d.get("dossier") or "loras", d.get("archi") or "autre"
        t = nouveau_travail("telechargement", os.path.basename(P["chemin"]), liste=bool(d.get("liste")))
        t["_hf"] = jet.get("hf")

        def fn(t):
            installer_hf(P["depot"], P["rev"], P["chemin"], P["sha"], P["taille"], dossier, archi, d.get("attendu"))
            return {"liens": [{"lien": f"https://huggingface.co/{P['depot']}/blob/{P['rev']}/{P['chemin']}",
                               "nom": f"{P['depot']} — {os.path.basename(P['chemin'])}", "dossier": dossier,
                               "archi": archi, "sha": P["sha"]}]}
        mettre_en_file(t, fn)
        return {"travail": t["id"]}
    # image : téléchargement des ressources choisies, puis réglages prêts pour l'onglet Créer
    exclus = set(d.get("exclus") or [])
    choisis = [p for i, p in enumerate(P["plans"]) if i not in exclus]
    t = nouveau_travail("image", "Ressources de l'image", liste=bool(d.get("liste")))

    def fn(t):
        liens, echecs = [], []
        for k, p in enumerate(choisis, 1):
            f = p["fichiers"][p["choix"]]
            t["detail"] = f"{k}/{len(choisis)} : {p['nom']}"
            t["attendu"] = (f.get("sizeKB") or 0) * 1024
            try:
                _executer_plan(p, tok)
                liens.append({"lien": lien_civitai(p), "nom": p["nom"]})
            except C.Erreur as e:
                echecs.append(f"{p['nom']} : {e}")
        form = formulaire_image(P["meta"], choisis, P["base"], P["manquants"])
        form["notes"] = echecs + form["notes"]
        return {"liens": liens, "formulaire": form}
    mettre_en_file(t, fn)
    return {"travail": t["id"]}


def op_installer_liste(d):
    jet = d.get("jetons") or {}
    ids = []
    for e in d.get("elements") or []:
        lien = (e.get("lien") or "").strip()
        if not lien.startswith("https://") and lien not in ("studio:joycaption", "studio:qwen21", "studio:wan22", "studio:h3", "studio:h3ref", "studio:eros") and \
                lien.removeprefix("studio:") not in ADAPTATEURS:
            continue
        if lien == "studio:joycaption":
            op_installer_outil({"jetons": jet})
            continue
        if lien in ("studio:qwen21", "studio:wan22", "studio:h3", "studio:h3ref", "studio:eros"):
            ids.append(op_installer_officiel({"jetons": jet, "quoi": lien[7:]})["travail"])
            continue
        if lien.startswith("studio:") and lien[7:] in ADAPTATEURS:
            ids.append(op_installer_adaptateur({"jetons": jet, "quoi": lien[7:]})["travail"])
            continue
        t = nouveau_travail("telechargement", e.get("nom") or lien)
        if "huggingface.co" in lien:
            t["_hf"] = jet.get("hf")

            def fn(t, lien=lien, e=e):
                depot, rev, chemin = C.analyser_lien_hf(lien)
                parent = os.path.dirname(chemin)
                arbre = C.api_get(f"https://huggingface.co/api/models/{depot}/tree/{rev}"
                                  + (f"/{urllib.parse.quote(parent)}" if parent else ""), C.token_hf())
                ent = next((x for x in arbre if x.get("path") == chemin), None)
                if not ent:
                    raise C.Erreur("fichier introuvable sur Hugging Face")
                sha = ((ent.get("lfs") or {}).get("oid") or "").lower()
                if len(sha) != 64 or (e.get("sha") and e["sha"] != sha):
                    raise C.Erreur("empreinte publiée différente de celle enregistrée dans ta liste : non téléchargé")
                taille = (ent.get("lfs") or {}).get("size") or 0
                dossier = e.get("dossier")
                if dossier not in DOSSIERS_HF:
                    try:
                        url = f"https://huggingface.co/{depot}/resolve/{rev}/{urllib.parse.quote(chemin)}"
                        dossier = deviner_dossier(entete_distante(url, C.token_hf()))
                    except Exception:
                        dossier = "loras"
                installer_hf(depot, rev, chemin, sha, taille, dossier, e.get("archi") or deviner_archi(lien))
                return None
        else:
            tok = jet.get("civitai") or None

            def fn(t, lien=lien, tok=tok):
                genre, mid, vid = C.analyser_lien(lien)
                if genre == "image":
                    raise C.Erreur("lien d'image ignoré dans la liste")
                if vid is None:
                    vid = C.api_get(f"/models/{mid}", tok)["modelVersions"][0]["id"]
                plan = C.preparer(vid, C.profil_gpu(), tok)
                t["titre"] = plan["nom"]
                t["attendu"] = (plan["fichiers"][plan["choix"]].get("sizeKB") or 0) * 1024
                t["detail"] = "Téléchargement"
                _executer_plan(plan, tok)
                return None
        mettre_en_file(t, fn)
        ids.append(t["id"])
    return {"travaux": ids}


def formulaire_image(meta, plans, base, manquants):
    """Réglages de génération reconstruits depuis une image Civitai."""
    notes = []
    rels = {id(p): os.path.relpath(p["dest"], C.MODELS).replace(os.sep, "/") for p in plans if p.get("dest")}
    principal = next((rels[id(p)] for p in plans if id(p) in rels
                      and rels[id(p)].split("/")[0] in ("checkpoints", "diffusion_models")), None)
    loras = [{"rel": rels[id(p)].split("/", 1)[1], "poids": float(p["poids"]) if p.get("poids") is not None else 0.8,
              "nom": p["nom"]}
             for p in plans if id(p) in rels and rels[id(p)].startswith("loras/")]
    for p in plans:
        if id(p) in rels and rels[id(p)].startswith("loras/") and p.get("poids") is None:
            notes.append(f"Poids inconnu pour « {p['nom']} » : 0.8.")
    if not principal:
        notes.append("Le modèle de base n'a pas été téléchargé : choisis-le dans la liste des modèles.")
    D = defauts(principal or "/" + C.slug(base) + "/") or defauts("sdxl/") or {}
    larg, haut = D.get("largeur", 1024), D.get("hauteur", 1024)
    m = re.match(r"^\s*(\d+)\s*x\s*(\d+)\s*$", str(meta.get("Size", "")))
    if m:
        larg, haut = int(m.group(1)), int(m.group(2))
    if larg % 16 or haut % 16:
        larg, haut = larg // 16 * 16, haut // 16 * 16
    sampler, sched, connu = C.sampler_comfy(meta.get("sampler") or D.get("sampler"), meta.get("scheduler"))
    if not meta.get("sampler"):
        sampler, sched = D.get("sampler", "euler"), D.get("scheduler") or "normal"
    elif not connu:
        notes.append(f"Sampler « {meta.get('sampler')} » non reconnu : {sampler} utilisé.")
    pos = re.sub(r"<lora:[^>]+>", "", str(meta.get("prompt") or "")).strip(" ,")
    neg = re.sub(r"<lora:[^>]+>", "", str(meta.get("negativePrompt") or "")).strip(" ,")
    for p in plans:
        if p["type"] != "TextualInversion" or not p.get("dest"):
            continue
        tige = os.path.splitext(os.path.basename(p["dest"]))[0]
        ref = f"embedding:{tige}"
        trouve = False
        for n in sorted({tige} | {w.strip() for w in p.get("mots") or [] if w.strip()}, key=len, reverse=True):
            motif = re.compile(r"(?<![\w:])" + re.escape(n) + r"(?![\w])", re.I)
            if motif.search(pos) or motif.search(neg):
                pos, neg = motif.sub(ref, pos), motif.sub(ref, neg)
                trouve = True
                break
        if not trouve and "neg" in (tige + p["nom"]).lower():
            neg = f"{ref}, {neg}" if neg else ref
    if any(k.lower().startswith("hires") for k in meta):
        notes.append("L'image d'origine a été agrandie (hires fix) : génération en taille de base.")
    for mq in manquants:
        notes.append(f"Introuvable : {mq['nom']}" + (f" (poids {mq['poids']})" if mq.get("poids") is not None else "")
                     + f" — {mq['raison']}")
    graine = C._nombre(meta.get("seed"), int, None)
    return {"modele": principal, "prompt": pos, "negatif": neg, "largeur": larg, "hauteur": haut,
            "steps": C._nombre(meta.get("steps"), int, D.get("steps", 25)),
            "cfg": C._nombre(meta.get("cfgScale"), float, D.get("cfg", 6.0)),
            "sampler": sampler, "scheduler": sched, "graine": graine, "loras": loras, "sda": False,
            "clip": C._nombre(meta.get("clipSkip"), int, D.get("clip", 1)), "notes": notes}


# ---------------------------------------------------------------- construction des graphes ComfyUI (format API)
# Liste complète de ComfyUI v0.39.2 (comfy/samplers.py), les plus courants en tête.
SAMPLERS = ["euler", "euler_ancestral", "er_sde", "res_multistep", "dpmpp_2m", "dpmpp_2m_sde", "dpmpp_sde", "dpmpp_3m_sde",
            "dpmpp_2s_ancestral", "uni_pc", "uni_pc_bh2", "ddim", "heun", "lms", "lcm", "deis", "ipndm", "ipndm_v",
            "gradient_estimation", "sa_solver", "sa_solver_pece", "seeds_2", "seeds_3",
            "euler_cfg_pp", "euler_ancestral_cfg_pp", "heunpp2", "exp_heun_2_x0", "exp_heun_2_x0_sde", "dpm_2", "dpm_2_ancestral",
            "dpm_fast", "dpm_adaptive", "dpmpp_2s_ancestral_cfg_pp", "dpmpp_sde_gpu", "dpmpp_2m_cfg_pp", "dpmpp_2m_sde_gpu",
            "dpmpp_2m_sde_heun", "dpmpp_2m_sde_heun_gpu", "dpmpp_3m_sde_gpu", "ddpm", "cfgpp_ud10_ab", "res_multistep_cfg_pp",
            "res_multistep_ancestral", "res_multistep_ancestral_cfg_pp", "gradient_estimation_cfg_pp"]
SCHEDULERS = ["simple", "normal", "karras", "exponential", "sgm_uniform", "beta", "ddim_uniform", "linear_quadratic", "kl_optimal"]


def _charger_qwen21(ajouter, nom, loras, p):
    """Chargeurs de Qwen Image 2.1 + LoRA choisis + LoRA Turbo officiel (mode rapide)."""
    comp = COMPOSANTS["qwen21"]
    te = C.chercher_installe("text_encoders", comp["te"])
    vae = C.chercher_installe("vae", comp["vae"])
    if not te or not vae:
        raise C.Erreur("Encodeur de texte ou VAE de Qwen Image 2.1 manquant : installe Qwen Image 2.1 depuis Modèles.")
    modele = [ajouter("UNETLoader", unet_name=nom, weight_dtype="default"), 0]
    for x in loras:
        modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=x["rel"], strength_model=float(x["poids"])), 0]
    if p.get("turbo_lora"):
        modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["turbo_lora"], strength_model=1.0), 0]
    clip = [ajouter("CLIPLoader", clip_name=te, type=comp["clip_type"], device="default"), 0]
    vae_n = [ajouter("VAELoader", vae_name=vae), 0]
    return modele, clip, vae_n


def _echantillonner_qwen21(ajouter, p, modele, pos, neg, latent, force):
    """Mode normal : KSampler. Mode rapide (Turbo) : 8 étapes sur les sigmas officiels de la version Turbo."""
    if p.get("rapide"):
        sig = [ajouter("ManualSigmas", sigmas=SIGMAS_TURBO_QWEN21), 0]
        if force < 0.999:
            sig = [ajouter("SplitSigmasDenoise", sigmas=sig, denoise=force), 1]
        return [ajouter("SamplerCustomAdvanced", noise=[ajouter("RandomNoise", noise_seed=p["graine"]), 0],
                        guider=[ajouter("CFGGuider", model=modele, positive=pos, negative=neg, cfg=p["cfg"]), 0],
                        sampler=[ajouter("KSamplerSelect", sampler_name=p["sampler"]), 0], sigmas=sig,
                        latent_image=latent), 0]
    return [ajouter("KSampler", model=modele, seed=p["graine"], steps=p["steps"], cfg=p["cfg"], sampler_name=p["sampler"],
                    scheduler=p["scheduler"], positive=pos, negative=neg, latent_image=latent, denoise=force), 0]


def construire(p):
    """Graphe ComfyUI pour une image. p : réglages validés (voir op_generer)."""
    rel = p["modele"]
    fam = famille(rel)
    dossier, nom = rel.split("/", 1)
    g = {}
    n = [0]

    def ajouter(classe, **entrees):
        n[0] += 1
        k = str(n[0])
        g[k] = {"class_type": classe, "inputs": entrees}
        return k

    loras = [x for x in p["loras"] if x.get("actif", True) and abs(float(x.get("poids", 0))) > 1e-6]
    if fam == "qwen21":
        if dossier != "diffusion_models":
            raise C.Erreur("Ce fichier Qwen Image 2.1 n'est pas un modèle de diffusion seul.")
        modele, clip, vae_n = _charger_qwen21(ajouter, nom, loras, p)
        enc = ajouter("TextEncodeQwenImage21", clip=clip, prompt=p["prompt"], negative_prompt=p.get("negatif") or "",
                      resolution=1024)
        latent = [ajouter("EmptyLatentImage", width=p["largeur"], height=p["hauteur"], batch_size=1), 0]
        sortie = _echantillonner_qwen21(ajouter, p, modele, [enc, 0], [enc, 1], latent, 1.0)
        img = [ajouter("VAEDecode", samples=sortie, vae=vae_n), 0]
        ajouter("SaveImage", images=img, filename_prefix="studio")
        return g
    if fam in COMPOSANTS:
        comp = COMPOSANTS[fam]
        te = C.chercher_installe("text_encoders", comp["te"])
        vae = C.chercher_installe("vae", comp["vae"])
        if not te or not vae:
            raise C.Erreur(f"Encodeur de texte ou VAE de {comp['nom']} manquant : réinstalle le modèle depuis Modèles.")
        if dossier == "checkpoints":
            modele = [ajouter("CheckpointLoaderSimple", ckpt_name=nom), 0]
        else:
            modele = [ajouter("UNETLoader", unet_name=nom, weight_dtype="default"), 0]
        clip = [ajouter("CLIPLoader", clip_name=te, type=comp["clip_type"], device="default"), 0]
        vae_n = [ajouter("VAELoader", vae_name=vae), 0]
        if p.get("reid"):   # Krea 2 ReID : LoRA de l'auteur en premier (force 1), puis les LoRA choisis
            modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["reid"], strength_model=1.0), 0]
        for x in loras:
            modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=x["rel"],
                              strength_model=float(x["poids"])), 0]
        if p.get("reid"):
            # câblage du workflow officiel (workflow/krea2_reid_comfyui.json) : photo réduite à 384 × 384 px au total,
            # vue par l'encodeur Qwen3-VL et ajoutée en jetons de référence (méthode index_timestep_zero, cache K/V)
            modele = [ajouter("Krea2OstrisEditModelPatch", model=modele, kv_cache=True), 0]
            ref = [ajouter("ImageScaleToTotalPixels", image=[ajouter("LoadImage", image=p["reid_image"]), 0],
                           upscale_method="area", megapixels=0.140625, resolution_steps=16), 0]
            pos = [ajouter("TextEncodeKrea2OstrisEdit", clip=clip, prompt=p["prompt"], vae=vae_n, image1=ref), 0]
            neg = [ajouter("TextEncodeKrea2OstrisEdit", clip=clip, prompt=p.get("negatif") if p["cfg"] > 1.0 else "",
                           vae=vae_n, image1=ref), 0]
            pos = [ajouter("FluxKontextMultiReferenceLatentMethod", conditioning=pos,
                           reference_latents_method="index_timestep_zero"), 0]
            neg = [ajouter("FluxKontextMultiReferenceLatentMethod", conditioning=neg,
                           reference_latents_method="index_timestep_zero"), 0]
            p = dict(p, sda_lora=None)
        else:
            pos = [ajouter("CLIPTextEncode", text=p["prompt"], clip=clip), 0]
            if p["cfg"] <= 1.0 or not p.get("negatif"):
                neg = [ajouter("ConditioningZeroOut", conditioning=pos), 0]
            else:
                neg = [ajouter("CLIPTextEncode", text=p["negatif"], clip=clip), 0]
        if fam == "flux2":
            latent = [ajouter("EmptyFlux2LatentImage", width=p["largeur"], height=p["hauteur"], batch_size=1), 0]
            bruit = [ajouter("RandomNoise", noise_seed=p["graine"]), 0]
            samp = [ajouter("KSamplerSelect", sampler_name=p["sampler"]), 0]
            sig = [ajouter("Flux2Scheduler", steps=p["steps"], width=p["largeur"], height=p["hauteur"]), 0]
            guide = [ajouter("CFGGuider", model=modele, positive=pos, negative=neg, cfg=p["cfg"]), 0]
            sortie = [ajouter("SamplerCustomAdvanced", noise=bruit, guider=guide, sampler=samp, sigmas=sig,
                              latent_image=latent), 0]
        else:
            latent = [ajouter("EmptyLatentImage", width=p["largeur"], height=p["hauteur"], batch_size=1), 0]
            commun = dict(steps=p["steps"], cfg=p["cfg"], sampler_name=p["sampler"], scheduler=p["scheduler"],
                          positive=pos, negative=neg)
            if p.get("sda_lora"):
                # Diversité SDA : le LoRA n'agit que sur les premières étapes (« gate »)
                gate = max(1, min(int(p.get("sda_gate", 2)), p["steps"] - 1))
                modele_a = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["sda_lora"],
                                    strength_model=1.0), 0]
                a = [ajouter("KSamplerAdvanced", model=modele_a, add_noise="enable", noise_seed=p["graine"],
                             latent_image=latent, start_at_step=0, end_at_step=gate,
                             return_with_leftover_noise="enable", **commun), 0]
                sortie = [ajouter("KSamplerAdvanced", model=modele, add_noise="disable", noise_seed=p["graine"],
                                  latent_image=a, start_at_step=gate, end_at_step=10000,
                                  return_with_leftover_noise="disable", **commun), 0]
            else:
                sortie = [ajouter("KSampler", model=modele, seed=p["graine"], latent_image=latent, denoise=1.0,
                                  **commun), 0]
    elif fam in ("sdxl", "sd1"):
        if dossier != "checkpoints":
            raise C.Erreur("Ce modèle SDXL / SD 1.5 n'est pas un checkpoint complet.")
        ck = ajouter("CheckpointLoaderSimple", ckpt_name=nom)
        modele, clip, vae_n = [ck, 0], [ck, 1], [ck, 2]
        if p.get("clip", 1) >= 2:
            clip = [ajouter("CLIPSetLastLayer", clip=clip, stop_at_clip_layer=-int(p["clip"])), 0]
        for x in loras:
            l = ajouter("LoraLoader", model=modele, clip=clip, lora_name=x["rel"],
                        strength_model=float(x["poids"]), strength_clip=float(x["poids"]))
            modele, clip = [l, 0], [l, 1]
        pos = [ajouter("CLIPTextEncode", text=p["prompt"], clip=clip), 0]
        neg = [ajouter("CLIPTextEncode", text=p.get("negatif") or "", clip=clip), 0]
        latent = [ajouter("EmptyLatentImage", width=p["largeur"], height=p["hauteur"], batch_size=1), 0]
        sortie = [ajouter("KSampler", model=modele, seed=p["graine"], steps=p["steps"], cfg=p["cfg"],
                          sampler_name=p["sampler"], scheduler=p["scheduler"], positive=pos, negative=neg,
                          latent_image=latent, denoise=1.0), 0]
    else:
        raise C.Erreur("Architecture de ce modèle non prise en charge (Krea 2, Flux.2 Klein, SDXL / Pony / "
                       "Illustrious, SD 1.5).")
    img = [ajouter("VAEDecode", samples=sortie, vae=vae_n), 0]
    ajouter("SaveImage", images=img, filename_prefix="studio")
    return g


# ---------------------------------------------------------------- génération
IMAGES = collections.OrderedDict()   # id -> métadonnées (fichier en mémoire vive)
VIGNETTES = {}
VERSION_IMAGES = [0]
_gen_verrou = threading.Lock()


def _entier(v, mini, maxi, defaut):
    try:
        return max(mini, min(maxi, int(v)))
    except (TypeError, ValueError):
        return defaut


def _reglages(r, inv):
    """Réglages validés communs à la génération et à la retouche."""
    modele = next((m for m in inv["principaux"] if m["rel"] == r.get("modele")), None)
    if not modele or not modele.get("defauts"):
        raise C.Erreur("Modèle introuvable ou non pris en charge : choisis un modèle installé.")
    D = modele["defauts"]
    rels_loras = {x["rel"] for x in inv["loras"]}
    speciaux = {x["rel"] for x in inv["loras"] if x.get("sda") or x.get("reference") or x.get("turbo") or x.get("adaptateur")}
    try:
        cfg = float(r.get("cfg") if r.get("cfg") is not None else D.get("cfg", 1.0))
    except (TypeError, ValueError):
        cfg = D.get("cfg", 1.0)
    p = {"modele": modele["rel"], "negatif": str(r.get("negatif") or "")[:8000],
         "largeur": _entier(r.get("largeur"), 256, 2048, 1024) // 16 * 16,
         "hauteur": _entier(r.get("hauteur"), 256, 2048, 1024) // 16 * 16,
         "steps": _entier(r.get("steps"), 1, 150, D.get("steps", 20)),
         "cfg": max(0.0, min(30.0, cfg)),
         "sampler": r.get("sampler") if r.get("sampler") in SAMPLERS else D.get("sampler", "euler"),
         "scheduler": r.get("scheduler") if r.get("scheduler") in SCHEDULERS else (D.get("scheduler") or "simple"),
         "clip": _entier(r.get("clip"), 1, 12, D.get("clip", 1)),
         "loras": [{"rel": x["rel"], "poids": max(-4.0, min(4.0, float(x.get("poids", 0.8)))),
                    "actif": bool(x.get("actif", True))}
                   for x in (r.get("loras") or [])[:12] if x.get("rel") in rels_loras and x.get("rel") not in speciaux]}
    p["negatif_actif"] = bool(D.get("negatif"))
    p["negatif"] = p["negatif"] if p["negatif_actif"] else ""
    # Qwen Image 2.1 : mode rapide (LoRA Turbo officiel, ou modèle Turbo complet)
    p["rapide"] = p["turbo_lora"] = None
    if modele["famille"] == "qwen21":
        if D.get("turbo_integre"):
            p["rapide"] = True
        elif r.get("rapide"):
            p["turbo_lora"] = next((x["rel"] for x in inv["loras"] if x.get("turbo")), None)
            p["rapide"] = bool(p["turbo_lora"])
        if p["rapide"]:
            p["steps"] = 8
    return p, modele, D


def _prompts_graines(d):
    prompts = [str(x)[:8000] for x in (d.get("prompts") or [])][:16]
    graines = [int(x) % (2 ** 53) for x in (d.get("graines") or [])][:16]
    if not prompts or len(prompts) != len(graines) or not all(x.strip() for x in prompts):
        raise C.Erreur("Prompt vide.")
    return prompts, graines


def _soumettre(graphes, titre):
    if not ETAT.get("comfy"):
        raise C.Erreur("ComfyUI n'est pas encore prêt.")
    liberer_vram_pour_comfy()
    t = nouveau_travail("generation", titre, total=len(graphes), faites=0, images=[], debut_image=None)
    t["etat"] = "encours"
    t["_attente"] = []
    for g, q in graphes:
        rep = comfy_post("/prompt", {"prompt": g, "client_id": "studio"})
        if not rep or "_erreur" in rep:
            err = (rep or {}).get("_erreur") or {}
            t.update(etat="erreur", erreur=_message_erreur(err))
            break
        t["_attente"].append((rep["prompt_id"], q))
    if t["_attente"]:
        threading.Thread(target=_suivre, args=(t,), daemon=True).start()
    return {"travail": t["id"]}


def op_generer(d):
    r = d.get("reglages") or {}
    inv = inventaire()
    p, modele, D = _reglages(r, inv)
    sda = next((x["rel"] for x in inv["loras"] if x.get("sda")), None)
    p["sda_lora"] = sda if (r.get("sda") and D.get("sda") and sda) else None
    p["sda_gate"] = _entier(r.get("sda_gate"), 1, 10, 2)
    p["reid"] = p["reid_image"] = None
    if r.get("reid"):
        if modele["famille"] != "krea2":
            raise C.Erreur("Krea 2 ReID ne fonctionne qu'avec un modèle Krea 2.")
        p["reid"] = inv.get("adaptateurs", {}).get("reid")
        if not p["reid"]:
            raise C.Erreur("Installe d'abord Krea 2 ReID (onglet Créer).")
        ref = IMPORTS.get(r.get("reid_image"))
        if not ref:
            raise C.Erreur("Photo de référence introuvable : choisis-la à nouveau.")
        p["reid_image"], p["sda_lora"] = ref["fichier"], None
    prompts, graines = _prompts_graines(d)
    graphes = [(construire(dict(p, prompt=pr, graine=gr)), dict(p, prompt=pr, graine=gr)) for pr, gr in zip(prompts, graines)]
    if d.get("apercu"):   # workflow exact, à ouvrir dans ComfyUI (rien n'est lancé)
        return {"graphe": graphes[0][0]}
    return _soumettre(graphes, f"{len(graphes)} image(s)")


def _message_erreur(err):
    e = err.get("error") or {}
    msg = e.get("message") or "Réglages refusés par ComfyUI"
    details = []
    for nid, ne in (err.get("node_errors") or {}).items():
        for x in ne.get("errors") or []:
            details.append(f"{ne.get('class_type', nid)} : {x.get('message')} {x.get('details', '')}".strip())
    return msg + (" — " + " ; ".join(details[:3]) if details else "")


def _suivre(t):
    for pid, q in t["_attente"]:
        t["debut_image"] = None
        while True:
            if t["etat"] == "arrete":
                return
            try:
                h = comfy_get(f"/history/{pid}", timeout=10).get(pid)
            except Exception:
                h = None
            if h is None:
                try:
                    file_ = comfy_get("/queue", timeout=10)
                    if t["debut_image"] is None and any(x[1] == pid for x in file_.get("queue_running", [])):
                        t["debut_image"] = time.time()
                    if not any(x[1] == pid for x in file_.get("queue_running", []) + file_.get("queue_pending", [])):
                        h = comfy_get(f"/history/{pid}", timeout=10).get(pid)
                        if h is None:
                            t.update(etat="arrete")
                            return
                except Exception:
                    pass
            if h is not None:
                break
            time.sleep(0.4)
        statut = h.get("status") or {}
        if statut.get("status_str") == "error":
            msg = "Erreur pendant la génération"
            for nom, m in statut.get("messages") or []:
                if nom == "execution_error":
                    msg = f"{m.get('node_type', '')} : {m.get('exception_message', '').strip()}"[:600]
            t["erreur"] = msg
            t["faites"] += 1
            comfy_post("/history", {"delete": [pid]})
            continue
        if q.get("video"):
            _collecter_video(t, h.get("outputs") or {}, q)
            t["faites"] += 1
            comfy_post("/history", {"delete": [pid]})
            continue
        for sortie in (h.get("outputs") or {}).values():
            for im in sortie.get("images") or []:
                if im.get("type") != "output":
                    continue
                chemin = os.path.join(C.PRIVE, "output", im.get("subfolder") or "", im["filename"])
                if not q.get("largeur"):   # workflow personnel : taille lue sur l'image produite
                    try:
                        from PIL import Image
                        with Image.open(chemin) as im_:
                            q = dict(q, largeur=im_.size[0], hauteur=im_.size[1])
                    except Exception:
                        q = dict(q, largeur=0, hauteur=0)
                iid = uuid.uuid4().hex[:16]
                with VERROU:
                    IMAGES[iid] = {"id": iid, "fichier": chemin, "cree": time.time(),
                                   "largeur": q["largeur"], "hauteur": q["hauteur"],
                                   "reglages": {k: v for k, v in q.items() if k not in ("negatif_actif",)}}
                    VERSION_IMAGES[0] += 1
                t["images"].append(iid)
        t["faites"] += 1
        comfy_post("/history", {"delete": [pid]})   # ne pas garder les prompts dans l'historique de ComfyUI
    if t["etat"] == "encours":
        t["etat"] = "erreur" if t.get("erreur") and not t["images"] else "ok"
        t["fin"] = time.time()


def _collecter_video(t, sorties, q):
    def fichier(nid):
        for im in (sorties.get(nid) or {}).get("images") or []:
            if im.get("type") == "output":
                return os.path.join(C.PRIVE, "output", im.get("subfolder") or "", im["filename"])
        return None
    mp4, affiche = fichier("video"), fichier("affiche")
    if not mp4 or not os.path.isfile(mp4):
        t["erreur"] = "La vidéo n'a pas été produite."
        return
    iid = uuid.uuid4().hex[:16]
    with VERROU:
        IMAGES[iid] = {"id": iid, "fichier": mp4, "affiche": affiche, "video": True, "cree": time.time(),
                       "largeur": q["largeur"], "hauteur": q["hauteur"],
                       "reglages": {k: v for k, v in q.items() if k not in ("source_fichier", "refs")}}
        VERSION_IMAGES[0] += 1
    t["images"].append(iid)


TYPES_ARRETABLES = ("telechargement", "image", "officiel", "outil")


def op_annuler_travail(d):
    """Arrête un téléchargement : retiré de la file s'il attend, sinon curl est interrompu et le fichier partiel
    effacé. Les fichiers déjà terminés et vérifiés d'une installation en plusieurs parties restent installés."""
    with VERROU:
        t = TRAVAUX.get(str(d.get("id") or ""))
        if not t or t["type"] not in TYPES_ARRETABLES:
            raise C.Erreur("Téléchargement introuvable.")
        if t["etat"] == "attente":
            with FILE_SIGNAL:
                if t in FILE:
                    FILE.remove(t)
            t.update(etat="arrete", detail="Arrêté", fin=time.time())
            t.pop("_fn", None)
            return {"etat": "arrete"}
        if t["etat"] != "encours":
            return {"etat": t["etat"]}
        t["_annuler"] = True
        proc = t.get("_proc")
    if proc is not None and proc.poll() is None:
        proc.terminate()
    return {"etat": "arret_demande"}


def op_arreter(d):
    comfy_post("/queue", {"clear": True})
    comfy_post("/interrupt", {})
    with VERROU:
        for t in TRAVAUX.values():
            if t["type"] == "generation" and t["etat"] == "encours":
                t["etat"] = "arrete"
    return {}


_VUS_COMFY = set()


def images_comfyui():
    """Images créées directement dans l'interface ComfyUI (tunnel SSH) : ajoutées à la galerie de Studio.
    Les images de Studio ont le préfixe « studio_ » et sont enregistrées par _suivre."""
    dossier = os.path.join(C.PRIVE, "output")
    try:
        noms = [n for n in os.listdir(dossier) if n.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
                and not n.startswith("studio_") and n not in _VUS_COMFY]
    except OSError:
        return
    for n in sorted(noms):
        chemin = os.path.join(dossier, n)
        _VUS_COMFY.add(n)
        taille = None
        try:
            from PIL import Image
            with Image.open(chemin) as im:
                taille = im.size
        except Exception:
            pass
        iid = uuid.uuid4().hex[:16]
        with VERROU:
            IMAGES[iid] = {"id": iid, "fichier": chemin, "cree": os.path.getmtime(chemin),
                           "largeur": (taille or (0, 0))[0], "hauteur": (taille or (0, 0))[1],
                           "reglages": {"prompt": "Image créée dans ComfyUI", "source": "comfyui"}}
            VERSION_IMAGES[0] += 1


def liste_images():
    with VERROU:
        tout = list(IMAGES.values())
    return [{"id": m["id"], "cree": m["cree"], "largeur": m["largeur"], "hauteur": m["hauteur"],
             "reglages": m["reglages"], "video": bool(m.get("video"))} for m in reversed(tout) if os.path.isfile(m["fichier"])]


def lire_image(iid, mini):
    m = IMAGES.get(iid)
    if not m or not os.path.isfile(m["fichier"]):
        raise C.Erreur("Image introuvable.")
    if m.get("video") and not mini:
        with open(m["fichier"], "rb") as f:
            return f.read(), "video/mp4"
    if mini:
        if iid not in VIGNETTES:
            try:
                from PIL import Image
                im = Image.open(m.get("affiche") or m["fichier"])
                im.thumbnail((480, 480))
                b = io.BytesIO()
                im.convert("RGB").save(b, "JPEG", quality=82)
                VIGNETTES[iid] = (b.getvalue(), "image/jpeg")
            except Exception:
                if m.get("video") and not m.get("affiche"):
                    raise C.Erreur("Aperçu de la vidéo introuvable.")
                with open(m.get("affiche") or m["fichier"], "rb") as f:
                    VIGNETTES[iid] = (f.read(), "image/png")
        return VIGNETTES[iid]
    with open(m["fichier"], "rb") as f:
        return f.read(), "image/png"


def op_supprimer_image(d):
    with VERROU:
        m = IMAGES.pop(d.get("id"), None)
    VIGNETTES.pop(d.get("id"), None)
    for f in ([m["fichier"], m.get("affiche")] if m else []):
        if f and os.path.realpath(f).startswith("/dev/shm/"):
            try:
                os.remove(f)
            except OSError:
                pass
    VERSION_IMAGES[0] += 1
    return {}



# ---------------------------------------------------------------- images importées (mémoire vive)
IMPORTS = {}          # id -> {"fichier": nom dans input/, "largeur", "hauteur"}
TAILLE_IMPORT_MAX = 30 * 1024 * 1024


def dossier_input():
    d = os.path.join(C.PRIVE, "input")
    os.makedirs(d, exist_ok=True)
    return d


def _dimensions(chemin):
    try:
        from PIL import Image
        with Image.open(chemin) as im:
            im.verify()
        with Image.open(chemin) as im:
            return im.size
    except ImportError:
        return None
    except Exception:
        raise C.Erreur("Fichier image illisible.")


def op_importer(d):
    """Image envoyée par l'application (déjà redimensionnée, sans métadonnées) ou copiée depuis la galerie."""
    if not TEST:
        C.exiger_zone()
    iid = uuid.uuid4().hex[:16]
    if d.get("depuis"):
        with VERROU:
            m = IMAGES.get(d["depuis"])
        source = (m.get("affiche") if m and m.get("video") else m["fichier"] if m else None)   # vidéo : sa 1re image
        if not source or not os.path.isfile(source):
            raise C.Erreur("Image de la galerie introuvable.")
        nom = f"studio_imp_{iid}.png"
        shutil.copyfile(source, os.path.join(dossier_input(), nom))
    else:
        donnees = base64.b64decode(d.get("donnees") or "", validate=False)
        if not donnees or len(donnees) > TAILLE_IMPORT_MAX:
            raise C.Erreur("Image vide ou trop grande.")
        if donnees[:8] == b"\x89PNG\r\n\x1a\n":
            ext = ".png"
        elif donnees[:3] == b"\xff\xd8\xff":
            ext = ".jpg"
        elif donnees[8:12] == b"WEBP":
            ext = ".webp"
        else:
            raise C.Erreur("Format d'image non pris en charge (PNG, JPEG ou WebP).")
        nom = f"studio_imp_{iid}{ext}"
        with open(os.path.join(dossier_input(), nom), "wb") as f:
            f.write(donnees)
    taille = _dimensions(os.path.join(dossier_input(), nom))
    if taille is None:
        taille = (_entier(d.get("largeur"), 16, 4096, 1024), _entier(d.get("hauteur"), 16, 4096, 1024))
    IMPORTS[iid] = {"fichier": nom, "largeur": taille[0], "hauteur": taille[1]}
    return {"id": iid, "largeur": taille[0], "hauteur": taille[1]}


def chemin_image(iid):
    """Fichier (en mémoire vive) d'une image importée ou de la galerie."""
    if iid in IMPORTS:
        return os.path.join(dossier_input(), IMPORTS[iid]["fichier"])
    with VERROU:
        m = IMAGES.get(iid)
    if m and m.get("video"):   # vidéo : sa première image (pour la retoucher, l'animer à nouveau ou la décrire)
        if m.get("affiche") and os.path.isfile(m["affiche"]):
            return m["affiche"]
    elif m and os.path.isfile(m["fichier"]):
        return m["fichier"]
    raise C.Erreur("Image introuvable (session effacée ?).")


# ---------------------------------------------------------------- retouche (inpainting) avec références facultatives
def _masques(ajouter, p, w, h):
    """Masque peint : agrandi puis adouci. Retourne (masque net agrandi, masque adouci) ; (None, None) sans masque."""
    if not p.get("masque_fichier"):
        return None, None
    m = [ajouter("LoadImageMask", image=p["masque_fichier"], channel="red"), 0]
    if p["extension"] > 0:
        m = [ajouter("GrowMask", mask=m, expand=p["extension"], tapered_corners=True), 0]
    net = m
    if p["flou"] > 0:
        im = [ajouter("MaskToImage", mask=m), 0]
        im = [ajouter("ImageBlur", image=im, blur_radius=p["flou"], sigma=max(0.1, min(10.0, p["flou"] / 2))), 0]
        m = [ajouter("ImageToMask", image=im, channel="red"), 0]
    return net, m


def _consigne_qwen21(p, n_refs):
    """Qwen Image 2.1 : <image1> est l'image modifiée, puis les références, puis la carte de la zone peinte."""
    texte = p["prompt"]
    if p.get("masque_fichier"):
        k = 2 + n_refs
        texte = (f"Edit <image1> only inside the area shown in white in <image{k}>; keep everything outside "
                 f"that area unchanged. {texte}")
    return texte


def _retouche_identite(ajouter, p, dossier, nom, loras, src, refs_fichiers, m, proteger):
    """Krea 2 Identity Edit (nœuds ComfyUI-Krea2Edit), câblage du workflow de l'auteur : l'image source entre à la fois
    comme jetons latents (Krea2EditModelPatch) et dans l'encodeur Qwen3-VL avec la consigne (Krea2EditGroundedEncode).
    Une 2e image facultative = la personne à placer dans la scène (ordre imposé : scène, puis personne)."""
    comp = COMPOSANTS["krea2"]
    te = C.chercher_installe("text_encoders", comp["te"])
    vae_nom = C.chercher_installe("vae", comp["vae"])
    if not te or not vae_nom:
        raise C.Erreur("Encodeur de texte ou VAE de Krea 2 manquant : réinstalle le modèle depuis Modèles.")
    if dossier == "checkpoints":
        modele = [ajouter("CheckpointLoaderSimple", ckpt_name=nom), 0]
    else:
        modele = [ajouter("UNETLoader", unet_name=nom, weight_dtype="default"), 0]
    modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["identite"], strength_model=1.0), 0]
    for x in loras:
        modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=x["rel"], strength_model=float(x["poids"])), 0]
    clip = [ajouter("CLIPLoader", clip_name=te, type=comp["clip_type"], device="default"), 0]
    vae = [ajouter("VAELoader", vae_name=vae_nom), 0]
    lat = [ajouter("EmptySD3LatentImage", width=p["largeur"], height=p["hauteur"], batch_size=1), 0]
    personne = [ajouter("LoadImage", image=refs_fichiers[0]), 0] if refs_fichiers else None
    patch = {"model": modele, "source_latent": [ajouter("VAEEncode", pixels=src, vae=vae), 0],
             "ref_boost": p["ressemblance"], "ref_boost_a": 1.0, "fit_mode": "fit", "vae": vae,
             "source_image": src, "target_latent": lat}
    encode = {"clip": clip, "image": src, "grounding_px": p["grounding"], "system_prompt": ""}
    if personne:
        patch.update(source_latent_b=[ajouter("VAEEncode", pixels=personne, vae=vae), 0], source_image_b=personne)
        encode["image_b"] = personne
    modele = [ajouter("Krea2EditModelPatch", **patch), 0]
    pos = [ajouter("Krea2EditGroundedEncode", prompt=p["prompt"], **encode), 0]
    if p["cfg"] > 1.0:   # négatif « appris » : consigne vide avec les mêmes images
        neg = [ajouter("Krea2EditGroundedEncode", prompt="", **encode), 0]
    else:
        neg = [ajouter("ConditioningZeroOut", conditioning=pos), 0]
    sortie = [ajouter("KSampler", model=modele, seed=p["graine"], steps=p["steps"], cfg=p["cfg"],
                      sampler_name=p["sampler"], scheduler=p["scheduler"], positive=pos, negative=neg,
                      latent_image=lat, denoise=1.0), 0]
    dec = [ajouter("VAEDecode", samples=sortie, vae=vae), 0]
    if proteger:
        dec = [ajouter("ImageCompositeMasked", destination=src, source=dec, x=0, y=0, resize_source=True, mask=m), 0]
    ajouter("SaveImage", images=dec, filename_prefix="studio")


def _retouche_anypaint(ajouter, p, dossier, nom, loras, src, net, m, proteger):
    """Krea 2 AnyPaint (nœuds krea2-anypaint), câblage du workflow de l'auteur : la zone peinte (et le cadre ajouté
    autour pour un agrandissement) est générée, le reste est remis à chaque étape ; une bande de 32 px autour de la
    zone est redessinée pour le raccord. Réglages de l'auteur : Turbo, 8 étapes, CFG 1, euler / simple, LoRA à 1."""
    comp = COMPOSANTS["krea2"]
    te = C.chercher_installe("text_encoders", comp["te"])
    vae_nom = C.chercher_installe("vae", comp["vae"])
    if not te or not vae_nom:
        raise C.Erreur("Encodeur de texte ou VAE de Krea 2 manquant : réinstalle le modèle depuis Modèles.")
    if dossier == "checkpoints":
        modele = [ajouter("CheckpointLoaderSimple", ckpt_name=nom), 0]
    else:
        modele = [ajouter("UNETLoader", unet_name=nom, weight_dtype="default"), 0]
    modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["anypaint"], strength_model=1.0), 0]
    for x in loras:
        modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=x["rel"], strength_model=float(x["poids"])), 0]
    modele = [ajouter("Krea2AnyPaintModelPatch", model=modele, kv_cache=True), 0]
    clip = [ajouter("CLIPLoader", clip_name=te, type=comp["clip_type"], device="default"), 0]
    vae = [ajouter("VAELoader", vae_name=vae_nom), 0]
    marges = p.get("marges") or {}
    prep_args = {"source": src, "left": marges.get("gauche", 0), "top": marges.get("haut", 0),
                 "right": marges.get("droite", 0), "bottom": marges.get("bas", 0),
                 "reference_max_edge": 384, "boundary_redraw_px": 32}
    if net is not None:
        prep_args["generated_mask"] = net
    prep = ajouter("Krea2AnyPaintPrepare", **prep_args)
    enc = ajouter("Krea2AnyPaintEncode", clip=clip, prompt=p["prompt"], vae=vae, semantic_reference=[prep, 0],
                  known_image=[prep, 1], keep_mask=[prep, 3], vlm_reference=True)
    neg = [ajouter("CLIPTextEncode", text=p.get("negatif") if p["cfg"] > 1.0 else "", clip=clip), 0]
    sortie = [ajouter("KSampler", model=modele, seed=p["graine"], steps=p["steps"], cfg=p["cfg"],
                      sampler_name=p["sampler"], scheduler=p["scheduler"], positive=[enc, 0], negative=neg,
                      latent_image=[enc, 1], denoise=1.0), 0]
    dec = [ajouter("VAEDecode", samples=sortie, vae=vae), 0]
    if proteger and m is not None and not any(marges.values()):
        dec = [ajouter("ImageCompositeMasked", destination=src, source=dec, x=0, y=0, resize_source=True, mask=m), 0]
    ajouter("SaveImage", images=dec, filename_prefix="studio")


def construire_retouche(p):
    rel = p["modele"]
    fam = famille(rel)
    dossier, nom = rel.split("/", 1)
    g, n = {}, [0]

    def ajouter(classe, **entrees):
        n[0] += 1
        k = str(n[0])
        g[k] = {"class_type": classe, "inputs": entrees}
        return k

    loras = [x for x in p["loras"] if x.get("actif", True) and abs(float(x.get("poids", 0))) > 1e-6]
    w, h = p["largeur"], p["hauteur"]
    refs_fichiers = list(p.get("references") or [])
    src = [ajouter("LoadImage", image=p["source_fichier"]), 0]
    net, m = _masques(ajouter, p, w, h)
    proteger = bool(p.get("proteger", True)) and m is not None

    if p.get("identite"):
        _retouche_identite(ajouter, p, dossier, nom, loras, src, refs_fichiers, m, proteger)
        return g
    if p.get("anypaint"):
        _retouche_anypaint(ajouter, p, dossier, nom, loras, src, net, m, proteger)
        return g

    if fam == "qwen21":
        if dossier != "diffusion_models":
            raise C.Erreur("Ce fichier Qwen Image 2.1 n'est pas un modèle de diffusion seul.")
        modele, clip, vae = _charger_qwen21(ajouter, nom, loras, p)
        w32, h32 = max(256, round(w / 32) * 32), max(256, round(h / 32) * 32)
        cible = src if (w32, h32) == (w, h) else [ajouter("ImageScale", image=src, upscale_method="lanczos",
                                                           width=w32, height=h32, crop="disabled"), 0]
        images = {"images.image_1": cible}
        for i, f in enumerate(refs_fichiers[:4]):
            images[f"images.image_{i + 2}"] = [ajouter("LoadImage", image=f), 0]
        if net is not None:   # la zone peinte est montrée au modèle comme une image en noir et blanc
            carte = [ajouter("MaskToImage", mask=net), 0]
            if (w32, h32) != (w, h):
                carte = [ajouter("ImageScale", image=carte, upscale_method="nearest-exact", width=w32, height=h32,
                                 crop="disabled"), 0]
            images[f"images.image_{len(images) + 1}"] = carte
        enc = ajouter("TextEncodeQwenImage21", clip=clip, prompt=_consigne_qwen21(p, len(refs_fichiers[:4])),
                      negative_prompt=p.get("negatif") or "", vae=vae, resolution=0, **images)
        force = max(1.0 / max(1, p["steps"]), min(1.0, p["force"]))
        latent = [enc, 2] if force >= 0.999 else [ajouter("VAEEncode", pixels=cible, vae=vae), 0]
        sortie = _echantillonner_qwen21(ajouter, p, modele, [enc, 0], [enc, 1], latent, force)
        dec = [ajouter("VAEDecode", samples=sortie, vae=vae), 0]
        rgb = [ajouter("SplitImageWithAlpha", image=dec), 0]   # le VAE de Qwen 2.1 rend aussi une couche alpha
        if proteger:
            fini = [ajouter("ImageCompositeMasked", destination=src, source=rgb, x=0, y=0, resize_source=True, mask=m), 0]
        else:
            fini = rgb
        ajouter("SaveImage", images=fini, filename_prefix="studio")
        return g

    if fam in COMPOSANTS:
        comp = COMPOSANTS[fam]
        te = C.chercher_installe("text_encoders", comp["te"])
        vae_nom = C.chercher_installe("vae", comp["vae"])
        if not te or not vae_nom:
            raise C.Erreur(f"Encodeur de texte ou VAE de {comp['nom']} manquant : réinstalle le modèle depuis Modèles.")
        if dossier == "checkpoints":
            modele = [ajouter("CheckpointLoaderSimple", ckpt_name=nom), 0]
        else:
            modele = [ajouter("UNETLoader", unet_name=nom, weight_dtype="default"), 0]
        clip = [ajouter("CLIPLoader", clip_name=te, type=comp["clip_type"], device="default"), 0]
        vae = [ajouter("VAELoader", vae_name=vae_nom), 0]
        for x in loras:
            modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=x["rel"], strength_model=float(x["poids"])), 0]
    elif fam in ("sdxl", "sd1"):
        if dossier != "checkpoints":
            raise C.Erreur("Ce modèle SDXL / SD 1.5 n'est pas un checkpoint complet.")
        ck = ajouter("CheckpointLoaderSimple", ckpt_name=nom)
        modele, clip, vae = [ck, 0], [ck, 1], [ck, 2]
        if p.get("clip", 1) >= 2:
            clip = [ajouter("CLIPSetLastLayer", clip=clip, stop_at_clip_layer=-int(p["clip"])), 0]
        for x in loras:
            l = ajouter("LoraLoader", model=modele, clip=clip, lora_name=x["rel"],
                        strength_model=float(x["poids"]), strength_clip=float(x["poids"]))
            modele, clip = [l, 0], [l, 1]
    else:
        raise C.Erreur("Architecture de ce modèle non prise en charge pour la retouche.")

    ref = [ajouter("LoadImage", image=refs_fichiers[0]), 0] if refs_fichiers else None
    if ref and fam == "krea2":
        modele = [ajouter("LoraLoaderModelOnly", model=modele, lora_name=p["reference_lora"], strength_model=1.0), 0]
        modele = [ajouter("ModelSamplingFlux", model=modele, max_shift=1.15, base_shift=0.5, width=w, height=h), 0]
    modele = [ajouter("DifferentialDiffusion", model=modele, strength=1.0), 0]
    if m is None:
        m = [ajouter("SolidMask", value=1.0, width=w, height=h), 0]
    lat_src = [ajouter("VAEEncode", pixels=src, vae=vae), 0]

    if ref and fam == "krea2":
        pos = [ajouter("TextEncodeQwenImageEditPlus", clip=clip, prompt=p["prompt"], vae=vae, image1=ref), 0]
        pos = [ajouter("FluxKontextMultiReferenceLatentMethod", conditioning=pos,
                       reference_latents_method="index_timestep_zero"), 0]
    else:
        pos = [ajouter("CLIPTextEncode", text=p["prompt"], clip=clip), 0]
    refs = []
    if fam == "flux2":
        refs.append(lat_src)                                   # l'image d'origine sert de contexte
        if ref:
            refs.append([ajouter("VAEEncode", pixels=ref, vae=vae), 0])
        for r_ in refs:
            pos = [ajouter("ReferenceLatent", conditioning=pos, latent=r_), 0]
    if p["cfg"] <= 1.0 or not p.get("negatif"):
        neg = [ajouter("ConditioningZeroOut", conditioning=pos), 0]
    else:
        neg = [ajouter("CLIPTextEncode", text=p["negatif"], clip=clip), 0]
        for r_ in refs:
            neg = [ajouter("ReferenceLatent", conditioning=neg, latent=r_), 0]
    lat = [ajouter("SetLatentNoiseMask", samples=lat_src, mask=m), 0]
    force = max(1.0 / p["steps"], min(1.0, p["force"]))
    if fam == "flux2":
        sig = [ajouter("Flux2Scheduler", steps=p["steps"], width=w, height=h), 0]
        sig = [ajouter("SplitSigmasDenoise", sigmas=sig, denoise=force), 1]
        sortie = [ajouter("SamplerCustomAdvanced", noise=[ajouter("RandomNoise", noise_seed=p["graine"]), 0],
                          guider=[ajouter("CFGGuider", model=modele, positive=pos, negative=neg, cfg=p["cfg"]), 0],
                          sampler=[ajouter("KSamplerSelect", sampler_name=p["sampler"]), 0], sigmas=sig,
                          latent_image=lat), 0]
    else:
        sortie = [ajouter("KSampler", model=modele, seed=p["graine"], steps=p["steps"], cfg=p["cfg"],
                          sampler_name=p["sampler"], scheduler=p["scheduler"], positive=pos, negative=neg,
                          latent_image=lat, denoise=force), 0]
    dec = [ajouter("VAEDecode", samples=sortie, vae=vae), 0]
    if proteger:   # seule la zone peinte change : le reste est recopié tel quel depuis l'original
        fini = [ajouter("ImageCompositeMasked", destination=src, source=dec, x=0, y=0, resize_source=False, mask=m), 0]
    else:
        fini = dec
    ajouter("SaveImage", images=fini, filename_prefix="studio")
    return g


def op_retoucher(d):
    r = d.get("reglages") or {}
    inv = inventaire()
    p, modele, D = _reglages(r, inv)
    src = IMPORTS.get(r.get("source"))
    if not src:
        raise C.Erreur("Image à retoucher introuvable : choisis-la à nouveau.")
    if src["largeur"] % 16 or src["hauteur"] % 16:
        raise C.Erreur("Dimensions de l'image non multiples de 16 : importe-la à nouveau.")
    fam = modele["famille"]
    p.update(largeur=src["largeur"], hauteur=src["hauteur"], source_fichier=src["fichier"],
             force=max(0.05, min(1.0, float(r.get("force") or 0.85))),
             extension=_entier(r.get("extension"), 0, 64, 8), flou=_entier(r.get("flou"), 0, 31, 9),
             proteger=r.get("proteger", True) is not False,
             masque_fichier=None, references=[], reference_lora=None, mode="retouche")
    if r.get("masque"):
        donnees = base64.b64decode(r["masque"])
        if donnees[:8] != b"\x89PNG\r\n\x1a\n" or len(donnees) > TAILLE_IMPORT_MAX:
            raise C.Erreur("Masque invalide.")
        nom = f"studio_masque_{uuid.uuid4().hex[:16]}.png"
        with open(os.path.join(dossier_input(), nom), "wb") as f:
            f.write(donnees)
        taille = _dimensions(os.path.join(dossier_input(), nom))
        if taille and taille != (src["largeur"], src["hauteur"]):
            raise C.Erreur("Le masque n'a pas la taille de l'image.")
        p["masque_fichier"] = nom
    ids = [x for x in (r.get("references") or ([r["reference"]] if r.get("reference") else [])) if x][:4]
    p["identite"] = p["anypaint"] = None
    if r.get("anypaint"):
        if fam != "krea2":
            raise C.Erreur("Krea 2 AnyPaint ne fonctionne qu'avec un modèle Krea 2.")
        p["anypaint"] = inv.get("adaptateurs", {}).get("anypaint")
        if not p["anypaint"]:
            raise C.Erreur("Installe d'abord Krea 2 AnyPaint (onglet Retoucher).")
        marges = r.get("marges") or {}
        p["marges"] = {k: _entier(marges.get(k), 0, 1024, 0) // 16 * 16 for k in ("gauche", "haut", "droite", "bas")}
        if (src["largeur"] + p["marges"]["gauche"] + p["marges"]["droite"]) * \
                (src["hauteur"] + p["marges"]["haut"] + p["marges"]["bas"]) > 2_400_000:
            raise C.Erreur("Image agrandie trop grande : 2,4 mégapixels au plus.")
        if not p["masque_fichier"] and not any(p["marges"].values()):
            raise C.Erreur("Peins la zone à modifier, ou agrandis le cadre (réglages fins).")
        p["force"] = 1.0
        ids = []
    elif r.get("identite"):
        if fam != "krea2":
            raise C.Erreur("Krea 2 Identity Edit ne fonctionne qu'avec un modèle Krea 2.")
        p["identite"] = next((x["rel"] for x in inv["loras"] if x.get("identite")), None)
        if not p["identite"]:
            raise C.Erreur("Installe d'abord Krea 2 Identity Edit (onglet Retoucher).")
        try:
            p["ressemblance"] = max(0.0, min(20.0, float(r.get("ressemblance", 4.0))))
        except (TypeError, ValueError):
            p["ressemblance"] = 4.0
        p["grounding"] = _entier(r.get("grounding"), 256, 1536, 768) // 64 * 64
        p["force"] = 1.0
        for x in ids[:1]:
            ref = IMPORTS.get(x)
            if not ref:
                raise C.Erreur("Image de la personne introuvable : choisis-la à nouveau.")
            p["references"].append(ref["fichier"])
        ids = []
    if ids:
        maxi = 4 if fam == "qwen21" else 1
        if fam == "krea2":
            lora = next((x["rel"] for x in inv["loras"] if x.get("reference")), None)
            if not lora:
                raise C.Erreur("Pour une référence avec Krea 2, installe d'abord le LoRA « Style Reference » (Modèles).")
            p["reference_lora"] = lora
        elif fam not in ("flux2", "qwen21"):
            raise C.Erreur("Les images de référence ne sont possibles qu'avec Qwen Image 2.1, Flux.2 Klein ou Krea 2.")
        for x in ids[:maxi]:
            ref = IMPORTS.get(x)
            if not ref:
                raise C.Erreur("Image de référence introuvable : choisis-la à nouveau.")
            p["references"].append(ref["fichier"])
    prompts, graines = _prompts_graines(d)
    graphes = []
    for pr, gr in zip(prompts, graines):
        q = dict(p, prompt=pr, graine=gr)
        graphes.append((construire_retouche(q), q))
    if d.get("apercu"):
        return {"graphe": graphes[0][0]}
    return _soumettre(graphes, f"Retouche : {len(graphes)} image(s)")


# ---------------------------------------------------------------- « Mes workflows » (workflows ComfyUI au format API)
# Un workflow exporté depuis ComfyUI (« Export (API) ») est gardé sur l'appareil ; le Pod y repère les champs utiles
# (prompt, graine, étapes, CFG, taille, images d'entrée, masque) et les remplit avant de le lancer.
# ---------------------------------------------------------------- Animer : image → vidéo avec Wan 2.2
WAN22_FPS = 16
WAN22_AIRES = {"480p": 832 * 480, "720p": 1280 * 720}


def dimensions_video(largeur, hauteur, qualite):
    """Taille de la vidéo : même forme que l'image, surface de la qualité choisie, multiples de 16."""
    aire = WAN22_AIRES.get(qualite, WAN22_AIRES["480p"])
    r = largeur / hauteur if hauteur else 1.0
    w = max(256, min(1920, int(round((aire * r) ** 0.5 / 16)) * 16))
    h = max(256, min(1920, int(round((aire / r) ** 0.5 / 16)) * 16))
    return w, h


def images_video(secondes):
    """Nombre d'images à 16 i/s : 4k + 1 (contrainte du modèle), 5 s → 81 images."""
    return 4 * max(1, int(round(secondes * WAN22_FPS / 4))) + 1


def dimensions_h3(largeur, hauteur, qualite):
    """MiniMax H3 : même forme que l'image, surface de la qualité choisie, multiples de 32."""
    aire = WAN22_AIRES.get(qualite, WAN22_AIRES["480p"])
    r = largeur / hauteur if hauteur else 1.0
    w = max(256, min(2048, int(round((aire * r) ** 0.5 / 32)) * 32))
    h = max(256, min(2048, int(round((aire / r) ** 0.5 / 32)) * 32))
    return w, h


def images_h3(secondes):
    """Nombre d'images à 24 i/s, arrondi vers le haut sur la grille 17k + 5 du modèle (5 s → 124 images)."""
    n = max(5, int(round(secondes * H3_FPS)))
    return n + (5 - n % 17) % 17


def construire_video_h3(p):
    """Graphe du modèle officiel ComfyUI « video_minimax_h3_i2v » : une passe, son généré avec l'image.
    Sortie « video » (MP4 avec la piste audio) et « affiche » (première image)."""
    g, n = {}, [0]

    def ajouter(classe, nid=None, **entrees):
        n[0] += 1
        k = nid or str(n[0])
        g[k] = {"class_type": classe, "inputs": entrees}
        return k

    sous = lambda rel: rel.split("/", 1)[1]
    ref, eros = bool(p.get("refs")), bool(p.get("eros"))
    unet = EROS["rel"] if eros else H3["ref_modele" if ref else "modele"][1]
    m = [ajouter("UNETLoader", unet_name=sous(unet), weight_dtype="default"), 0]
    if p["rapide"] and not eros:
        m = [ajouter("LoraLoaderModelOnly", model=m, lora_name=sous(H3["ref_turbo" if ref else "turbo"][1]), strength_model=1.0), 0]
    for x in p.get("loras") or []:
        m = [ajouter("LoraLoaderModelOnly", model=m, lora_name=x["fichier"], strength_model=float(x["poids"])), 0]
    clip = [ajouter("CLIPLoader", clip_name=sous(H3["te"][1]), type="minimax", device="default"), 0]
    vae = [ajouter("VAELoader", vae_name=sous(H3["vae"][1])), 0]
    vae_audio = [ajouter("VAELoader", vae_name=sous(H3["vae_audio"][1])), 0]
    positif = None
    if ref or eros:
        # références : <Picture 1>, <Picture 2>… dans le texte, dans l'ordre où elles sont branchées.
        # 10Eros avec une image de départ : elle sert de référence ET est verrouillée sur la 1re image (méthode de l'auteur).
        fichiers = p["refs"] if ref else [p["source_fichier"]]
        charges = [[ajouter("LoadImage", image=f), 0] for f in fichiers]
        images = {f"ref_images.ref_image_{i}": c for i, c in enumerate(charges)}
        i2v = ajouter("MiniMaxH3ReferenceToVideo", clip=clip, vae=vae, audio_vae=vae_audio, prompt=p["prompt"],
                      width=p["largeur"], height=p["hauteur"], length=p["images"], ref_image_size="match", **images)
        if not ref:
            positif = [ajouter("MiniMaxH3AddGuide", positive=[i2v, 0], vae=vae, latent=[i2v, 1], image=charges[0], frame_idx=0), 0]
    else:
        img = [ajouter("LoadImage", image=p["source_fichier"]), 0]
        i2v = ajouter("MiniMaxH3ImageToVideo", clip=clip, vae=vae, prompt=p["prompt"], width=p["largeur"],
                      height=p["hauteur"], length=p["images"], first_frame=img)
    guide = [ajouter("BasicGuider", model=m, conditioning=positif or [i2v, 0]), 0]
    bruit = [ajouter("RandomNoise", noise_seed=p["graine"]), 0]
    echant = [ajouter("KSamplerSelect", sampler_name="res_multistep"), 0]
    sigmas = [ajouter("BasicScheduler", model=m, scheduler="simple", steps=p["steps"], denoise=1.0), 0]
    lat = ajouter("SamplerCustomAdvanced", noise=bruit, guider=guide, sampler=echant, sigmas=sigmas, latent_image=[i2v, 1])
    dec = [ajouter("VAEDecode", samples=[lat, 0], vae=vae), 0]
    son = [ajouter("VAEDecodeAudio", samples=[lat, 0], vae=vae_audio), 0]
    vid = [ajouter("CreateVideo", images=dec, audio=son, fps=float(H3_FPS)), 0]
    ajouter("SaveVideo", nid="video", video=vid, filename_prefix="studio_video", format="mp4", **{"format.codec": "auto"})
    une = [ajouter("ImageFromBatch", image=dec, batch_index=0, length=1), 0]
    ajouter("SaveImage", nid="affiche", images=une, filename_prefix="studio_affiche")
    return g


def _animer_h3(d, r, m, src, refs=None, V=None):
    """MiniMax H3 : 20 étapes, ou 8 avec le LoRA Turbo (4 en mode références) ; pas de négatif (guidage simple),
    pas de LoRA Wan. En mode références, la forme de la vidéo suit la première référence."""
    qualite = r.get("qualite") if r.get("qualite") in WAN22_AIRES else "480p"
    try:
        secondes = max(1.0, min(15.0, float(r.get("duree") or 5)))
    except (TypeError, ValueError):
        secondes = 5.0
    rapide = bool(r.get("rapide")) and m.get("rapide")
    eros = bool(m.get("eros"))
    w, h = dimensions_h3(src["largeur"], src["hauteur"], qualite)
    dispo = {x["id"] for x in (V or inventaire()["videos"])["loras_h3"]}
    loras = []
    for x in (r.get("loras_h3") or [])[:8]:
        if x.get("id") in dispo and x.get("actif", True) is not False:
            try:
                poids = max(-4.0, min(4.0, float(x.get("poids", 1.0))))
            except (TypeError, ValueError):
                poids = 1.0
            if abs(poids) > 1e-6:
                loras.append({"fichier": x["id"], "poids": poids})
    if eros:
        pas = _entier(r.get("steps_eros"), 4, 16, EROS_PAS)   # 6 à 8 conseillées par l'auteur
    else:
        pas = (4 if refs else 8) if rapide else _entier(r.get("steps"), 4, 60, 20)
    p = {"video": True, "h3": True, "modele": m["id"], "largeur": w, "hauteur": h, "images": images_h3(secondes),
         "duree": secondes, "qualite": qualite, "fps": H3_FPS, "rapide": rapide,
         "steps": pas, "loras": loras, "eros": eros,
         "source_fichier": src["fichier"], "refs": [x["fichier"] for x in refs] if refs else None}
    prompts, graines = _prompts_graines(d)
    graphes = [(construire_video_h3(dict(p, prompt=pr, graine=gr)), dict(p, prompt=pr, graine=gr)) for pr, gr in zip(prompts, graines)]
    if d.get("apercu"):
        return {"graphe": graphes[0][0]}
    return _soumettre(graphes, f"{len(graphes)} vidéo(s)")


def construire_video(p):
    """Graphe du modèle officiel ComfyUI « video_wan2_2_14B_i2v » : deux passes (haut bruit puis bas bruit).
    Les nœuds de sortie ont des numéros fixes : « video » (MP4) et « affiche » (première image)."""
    g, n = {}, [0]

    def ajouter(classe, nid=None, **entrees):
        n[0] += 1
        k = nid or str(n[0])
        g[k] = {"class_type": classe, "inputs": entrees}
        return k

    clip = [ajouter("CLIPLoader", clip_name=p["te"], type="wan", device="default"), 0]
    vae = [ajouter("VAELoader", vae_name=p["vae"]), 0]
    pos = [ajouter("CLIPTextEncode", text=p["prompt"], clip=clip), 0]
    neg = [ajouter("CLIPTextEncode", text=p["negatif"] or WAN22_NEGATIF, clip=clip), 0]
    img = [ajouter("LoadImage", image=p["source_fichier"]), 0]
    wan = ajouter("WanImageToVideo", positive=pos, negative=neg, vae=vae, width=p["largeur"], height=p["hauteur"],
                  length=p["images"], batch_size=1, start_image=img)

    def modele(cote):
        m = [ajouter("UNETLoader", unet_name=p[cote].split("/", 1)[1], weight_dtype="default"), 0]
        if p["rapide"]:
            m = [ajouter("LoraLoaderModelOnly", model=m, lora_name=p["rapide_" + cote], strength_model=1.0), 0]
        for x in p["loras"]:
            if x.get(cote):      # moitié absente (LoRA resté seul) : appliqué d'un seul côté
                m = [ajouter("LoraLoaderModelOnly", model=m, lora_name=x[cote], strength_model=float(x["poids"])), 0]
        return [ajouter("ModelSamplingSD3", model=m, shift=5.0), 0]

    haut, bas = modele("haut"), modele("bas")
    k1 = ajouter("KSamplerAdvanced", model=haut, add_noise="enable", noise_seed=p["graine"], steps=p["steps"], cfg=p["cfg"],
                 sampler_name="euler", scheduler="simple", positive=[wan, 0], negative=[wan, 1], latent_image=[wan, 2],
                 start_at_step=0, end_at_step=p["coupure"], return_with_leftover_noise="enable")
    k2 = ajouter("KSamplerAdvanced", model=bas, add_noise="disable", noise_seed=0, steps=p["steps"], cfg=p["cfg"],
                 sampler_name="euler", scheduler="simple", positive=[wan, 0], negative=[wan, 1], latent_image=[k1, 0],
                 start_at_step=p["coupure"], end_at_step=10000, return_with_leftover_noise="disable")
    dec = [ajouter("VAEDecode", samples=[k2, 0], vae=vae), 0]
    vid = [ajouter("CreateVideo", images=dec, fps=float(WAN22_FPS)), 0]
    ajouter("SaveVideo", nid="video", video=vid, filename_prefix="studio_video", format="mp4", **{"format.codec": "auto"})
    une = [ajouter("ImageFromBatch", image=dec, batch_index=0, length=1), 0]
    ajouter("SaveImage", nid="affiche", images=une, filename_prefix="studio_affiche")
    return g


def op_animer(d):
    r = d.get("reglages") or {}
    inv = inventaire()
    V = inv["videos"]
    m = next((x for x in V["modeles"] if x["id"] == r.get("modele")), None)
    if not m:
        raise C.Erreur("Modèle vidéo introuvable : installe-en un (onglet Animer, Plus de réglages).")
    if not m.get("pret"):
        raise C.Erreur("Composants du modèle vidéo manquants (encodeur de texte ou VAE) : relance son installation.")
    if m.get("ref"):
        refs = [IMPORTS.get(x) for x in (r.get("references") or [])[:H3_MAX_REFS]]
        if not refs or not all(refs):
            raise C.Erreur("Images de référence introuvables : ajoute-les à nouveau.")
        return _animer_h3(d, r, m, refs[0], refs, V=V)
    src = IMPORTS.get(r.get("source"))
    if not src:
        raise C.Erreur("Image à animer introuvable : choisis-la à nouveau.")
    if m.get("h3"):
        return _animer_h3(d, r, m, src, V=V)
    integre = bool(m.get("vitesse_integree"))
    rapide = bool(r.get("rapide")) and V["rapide"] and not integre
    qualite = r.get("qualite") if r.get("qualite") in WAN22_AIRES else "480p"
    try:
        secondes = max(1.0, min(10.0, float(r.get("duree") or 5)))
    except (TypeError, ValueError):
        secondes = 5.0
    w, h = dimensions_video(src["largeur"], src["hauteur"], qualite)
    steps = 4 if rapide or integre else _entier(r.get("steps"), 2, 80, 20)
    try:
        cfg = 1.0 if rapide or integre else max(1.0, min(10.0, float(r.get("cfg") or 3.5)))
    except (TypeError, ValueError):
        cfg = 3.5
    loras_dispo = {x["id"]: x for x in V["loras"]}
    fichiers_wan = {f["rel"] for f in V["fichiers_lora"]}
    loras = []
    for x in (r.get("loras") or [])[:8]:
        l = loras_dispo.get(x.get("id"))
        if l and x.get("actif", True) is not False:
            try:
                poids = max(-4.0, min(4.0, float(x.get("poids", 1.0))))
            except (TypeError, ValueError):
                poids = 1.0
            haut, bas = l["haut"], l["bas"]
            if l.get("seul"):
                autre = x.get("autre") if x.get("autre") in fichiers_wan and x.get("autre") != l["id"] else None
                if l["seul"] == "haut":
                    bas = autre
                else:
                    haut = autre
            if abs(poids) > 1e-6:
                court = lambda r: (r.split("/", 1)[1] if r.startswith("loras/") else r) if r else None
                loras.append({"haut": court(haut), "bas": court(bas), "poids": poids, "nom": l["nom"], "id": l["id"]})
    te = WAN22["te"][2].split("/", 1)[1] if wan22_present("te") else C.chercher_installe("text_encoders", ["umt5_xxl"])
    vae = WAN22["vae"][2].split("/", 1)[1] if wan22_present("vae") else C.chercher_installe("vae", ["wan_2.1_vae"])
    p = {"video": True, "modele": m["id"], "haut": m["haut"], "bas": m["bas"], "te": te, "vae": vae,
         "rapide": rapide, "rapide_haut": WAN22["rapide_haut"][2].split("/", 1)[1],
         "rapide_bas": WAN22["rapide_bas"][2].split("/", 1)[1],
         "largeur": w, "hauteur": h, "images": images_video(secondes), "duree": secondes, "qualite": qualite,
         "fps": WAN22_FPS, "steps": steps, "coupure": max(1, steps // 2), "cfg": cfg,
         "negatif": str(r.get("negatif") or "")[:4000], "loras": loras, "source_fichier": src["fichier"]}
    prompts, graines = _prompts_graines(d)
    graphes = [(construire_video(dict(p, prompt=pr, graine=gr)), dict(p, prompt=pr, graine=gr)) for pr, gr in zip(prompts, graines)]
    if d.get("apercu"):
        return {"graphe": graphes[0][0]}
    return _soumettre(graphes, f"{len(graphes)} vidéo(s)")


NOEUDS_TEXTE = {"CLIPTextEncode": "text", "TextEncodeQwenImage21": "prompt", "TextEncodeQwenImageEditPlus": "prompt",
                "TextEncodeQwenImageEdit": "prompt"}
NOEUDS_LATENT = ("EmptyLatentImage", "EmptyFlux2LatentImage", "EmptySD3LatentImage", "EmptyHunyuanLatentVideo")
SORTIES_PERMISES = {"SaveImage", "PreviewImage"}
NOEUDS_INTERDITS = {"CheckpointSave", "ModelSave", "CLIPSave", "VAESave", "LoraSave", "SaveLatent", "ModelMergeSimple"}


def _lien(v):
    return isinstance(v, list) and len(v) == 2 and isinstance(v[0], (str, int)) and isinstance(v[1], int)


def _verifier_workflow(g):
    if not isinstance(g, dict) or not g or len(g) > 1500:
        raise C.Erreur("Ce fichier n'est pas un workflow ComfyUI au format API (utilise « Export (API) » dans ComfyUI).")
    for nid, n in g.items():
        if not isinstance(n, dict) or not isinstance(n.get("class_type"), str) or not isinstance(n.get("inputs"), dict):
            raise C.Erreur("Ce fichier n'est pas un workflow ComfyUI au format API (utilise « Export (API) » dans ComfyUI).")
        ct = n["class_type"]
        if ct in NOEUDS_INTERDITS or ("save" in ct.lower() and ct not in SORTIES_PERMISES):
            raise C.Erreur(f"Nœud non accepté dans Studio : {ct} (seul « Save Image » peut enregistrer un résultat).")
    if not any(n["class_type"] == "SaveImage" for n in g.values()):
        raise C.Erreur("Le workflow doit contenir un nœud « Save Image » : c'est lui qui envoie l'image dans ta galerie.")


def _texte_relie(g, lien, profondeur=0):
    """Remonte une entrée CONDITIONING jusqu'au nœud de texte qui la produit. Retourne (nœud, entrée) ou None."""
    if not _lien(lien) or profondeur > 8:
        return None
    nid, sortie = str(lien[0]), lien[1]
    n = g.get(nid)
    if not n:
        return None
    ct, ins = n["class_type"], n["inputs"]
    if ct == "TextEncodeQwenImage21":
        k = "prompt" if sortie == 0 else "negative_prompt"
        return (nid, k) if isinstance(ins.get(k), str) else None
    if ct in NOEUDS_TEXTE:
        k = NOEUDS_TEXTE[ct]
        return (nid, k) if isinstance(ins.get(k), str) else None
    for k in ("conditioning", "conditioning_to", "conditioning_1", "positive"):
        if _lien(ins.get(k)):
            r = _texte_relie(g, ins[k], profondeur + 1)
            if r:
                return r
    return None


def champs_workflow(g):
    _verifier_workflow(g)
    ch = {k: [] for k in ("prompt", "negatif", "graine", "steps", "cfg", "largeur", "hauteur", "images", "masque")}
    for nid, n in g.items():
        ct, ins = n["class_type"], n["inputs"]
        pos = neg = None
        if ct in ("KSampler", "KSamplerAdvanced"):
            pos, neg = ins.get("positive"), ins.get("negative")
        elif ct in ("CFGGuider", "DualCFGGuider", "BasicGuider"):
            pos, neg = ins.get("positive") or ins.get("conditioning") or ins.get("cond1"), ins.get("negative")
        for cle, lien in (("prompt", pos), ("negatif", neg)):
            r = _texte_relie(g, lien) if lien is not None else None
            if r and list(r) not in ch[cle] and not (cle == "negatif" and list(r) in ch["prompt"]):
                ch[cle].append(list(r))
        for k in ("seed", "noise_seed"):
            if isinstance(ins.get(k), int) and ct in ("KSampler", "KSamplerAdvanced", "RandomNoise"):
                ch["graine"].append([nid, k])
        if ct in ("KSampler", "KSamplerAdvanced", "Flux2Scheduler", "BasicScheduler") and isinstance(ins.get("steps"), int):
            ch["steps"].append([nid, "steps"])
        if ct in ("KSampler", "KSamplerAdvanced", "CFGGuider") and isinstance(ins.get("cfg"), (int, float)):
            ch["cfg"].append([nid, "cfg"])
        if ct in NOEUDS_LATENT and isinstance(ins.get("width"), int) and isinstance(ins.get("height"), int) and not ch["largeur"]:
            ch["largeur"].append([nid, "width"]); ch["hauteur"].append([nid, "height"])
        if ct == "LoadImage" and isinstance(ins.get("image"), str):
            ch["images"].append([nid, "image"])
        if ct == "LoadImageMask" and isinstance(ins.get("image"), str):
            ch["masque"].append([nid, "image"])
    if not ch["prompt"]:   # repli : premier texte trouvé
        for nid, n in g.items():
            k = NOEUDS_TEXTE.get(n["class_type"])
            if k and isinstance(n["inputs"].get(k), str):
                ch["prompt"].append([nid, k]); break
    ch["images"].sort(key=lambda x: int(x[0]) if str(x[0]).isdigit() else 0)
    # inpainting « à la ComfyUI » : le masque est la sortie MASK (n° 1) d'un Load Image (zone transparente de l'image)
    alpha = {str(v[0]) for n in g.values() for v in n["inputs"].values() if _lien(v) and v[1] == 1}
    ch["masque_alpha"] = [x for x in ch["images"] if str(x[0]) in alpha]
    if len({tuple(x) for x in ch["steps"]}) > 1 and any(g[x[0]]["class_type"] == "KSamplerAdvanced" for x in ch["steps"]):
        ch["steps"] = []   # plusieurs passes avancées : les étapes se règlent dans ComfyUI
    val = lambda l: g[l[0][0]]["inputs"][l[0][1]] if l else None
    return {"champs": ch, "type": "retoucher" if ch["images"] else "creer",
            "valeurs": {k: val(v) for k, v in ch.items() if k not in ("images", "masque", "masque_alpha")},
            "nb_images": len(ch["images"]), "masque": bool(ch["masque"] or ch["masque_alpha"])}


def op_analyser_workflow(d):
    return champs_workflow(d.get("graphe"))


def op_executer_workflow(d):
    g0 = d.get("graphe")
    info = champs_workflow(g0)
    ch, v = info["champs"], d.get("valeurs") or {}
    prompts, graines = _prompts_graines(d)
    fichiers = []
    for x in (d.get("images") or [])[:len(ch["images"])]:
        imp = IMPORTS.get(x)
        if not imp:
            raise C.Erreur("Image introuvable : choisis-la à nouveau.")
        fichiers.append(imp["fichier"])
    if len(fichiers) < len(ch["images"]):
        raise C.Erreur(f"Ce workflow attend {len(ch['images'])} image(s) d'entrée.")
    masque, avec_alpha = None, {}
    if ch["masque"] or ch["masque_alpha"]:
        if not d.get("masque"):
            raise C.Erreur("Ce workflow attend un masque : peins la zone à modifier.")
        try:
            donnees = base64.b64decode(d["masque"], validate=True)
        except (ValueError, TypeError):
            donnees = b""
        if donnees[:8] != b"\x89PNG\r\n\x1a\n" or len(donnees) > TAILLE_IMPORT_MAX:
            raise C.Erreur("Masque invalide.")
        masque = f"studio_masque_{uuid.uuid4().hex[:16]}.png"
        with open(os.path.join(dossier_input(), masque), "wb") as f:
            f.write(donnees)
        from PIL import Image, ImageOps
        with Image.open(io.BytesIO(donnees)) as m_:
            m_ = m_.convert("L")
            for (nid, _), fichier in zip(ch["images"], fichiers):
                if [nid, "image"] not in ch["masque_alpha"]:
                    continue
                with Image.open(os.path.join(dossier_input(), fichier)) as im:   # zone peinte = transparente (LoadImage : masque = 1 − alpha)
                    im = im.convert("RGBA")
                    im.putalpha(ImageOps.invert(m_.resize(im.size)))
                    nom = f"studio_wf_{uuid.uuid4().hex[:16]}.png"
                    im.save(os.path.join(dossier_input(), nom))
                avec_alpha[nid] = nom
    def nombre(cle, typ, mini, maxi):
        try:
            return max(mini, min(maxi, typ(v[cle])))
        except (KeyError, TypeError, ValueError):
            return None
    fixes = {"negatif": str(v["negatif"])[:8000] if isinstance(v.get("negatif"), str) else None,
             "steps": nombre("steps", int, 1, 150), "cfg": nombre("cfg", float, 0.0, 30.0),
             "largeur": (nombre("largeur", int, 256, 2048) or 0) // 16 * 16 or None,
             "hauteur": (nombre("hauteur", int, 256, 2048) or 0) // 16 * 16 or None}
    graphes = []
    for pr, gr in zip(prompts, graines):
        g = json.loads(json.dumps(g0))
        for cle, val in (("prompt", pr), ("graine", gr), *fixes.items()):
            if val is None:
                continue
            for nid, k in ch.get(cle, []):
                g[nid]["inputs"][k] = val
        for (nid, k), f in zip(ch["images"], fichiers):
            g[nid]["inputs"][k] = avec_alpha.get(nid, f)
        for nid, k in ch["masque"]:
            g[nid]["inputs"][k] = masque
            g[nid]["inputs"]["channel"] = "red"   # masque envoyé : blanc = zone à modifier, image opaque
        for n in g.values():
            if n["class_type"] == "SaveImage":
                n["inputs"]["filename_prefix"] = "studio"
        q = {"prompt": pr, "graine": gr, "negatif": fixes["negatif"] or "", "steps": fixes["steps"], "cfg": fixes["cfg"],
             "largeur": fixes["largeur"] or 0, "hauteur": fixes["hauteur"] or 0, "loras": [],
             "mode": "workflow", "workflow": str(d.get("nom") or "Mon workflow")[:60]}
        graphes.append((g, q))
    return _soumettre(graphes, f"Mon workflow : {len(graphes)} image(s)")


# ---------------------------------------------------------------- description d'image (JoyCaption, koboldcpp)
OUTILS = "/workspace/outils"
KOBOLD = {"url": "https://github.com/LostRuins/koboldcpp/releases/download/v1.122.1/koboldcpp-linux-x64",
          "sha": "724b81ad4d0557e6cf6b1e634c1b973e9a56c0a99b5164a9cf1ecbb8c9ad53d8",
          "fichier": "koboldcpp-1.122.1", "taille": 641836648}
JOY = [("mradermacher/llama-joycaption-beta-one-hf-llava-GGUF", "llama-joycaption-beta-one-hf-llava.Q8_0.gguf"),
       ("concedo/llama-joycaption-beta-one-hf-llava-mmproj-gguf", "llama-joycaption-beta-one-llava-mmproj-model-f16.gguf")]
CONSIGNES = {
    "description": "Write a long detailed description for this image.",
    "prompt": "Output a stable diffusion prompt that is indistinguishable from a real stable diffusion prompt.",
    "tags": "Generate only comma-separated Danbooru tags (lowercase_underscores). Strict order: `artist:`, `copyright:`, "
            "`character:`, `meta:`, then general tags. Include counts (1girl), appearance, clothing, accessories, pose, "
            "expression, actions, background. Use precise Danbooru syntax. No extra text.",
}
KOBOLD_PORT = 5001
_kobold = {"proc": None, "dernier": 0.0}
_kobold_verrou = threading.Lock()
_description_verrou = threading.Lock()


def _chemin_outil(nom):
    return os.path.join(OUTILS, "joycaption", nom)


def outil_description_installe():
    return all(os.path.isfile(_chemin_outil(f)) for _, f in JOY) and os.path.isfile(_chemin_outil(KOBOLD["fichier"]))


def _telecharger_verifie(url, dest, sha, taille, tok=None):
    if os.path.isfile(dest) and C.sha256(dest) == sha:
        journal(f"Déjà présent, empreinte vérifiée ✓ — {os.path.basename(dest)}")
        return
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    os.makedirs(C.TMP, exist_ok=True)
    if shutil.disk_usage("/workspace").free < (taille or 0) * 1.05:
        raise C.Erreur("Espace disque insuffisant sur /workspace.")
    tmp = os.path.join(C.TMP, os.path.basename(dest) + ".part")
    t = getattr(_progres, "travail", None)
    if t is not None:
        t["attendu"], t["detail"] = taille, f"Téléchargement de {os.path.basename(dest)}"
    C.telecharger(url, tmp, tok)
    if C.sha256(tmp) != sha:
        os.makedirs(C.QUAR, exist_ok=True)
        shutil.move(tmp, os.path.join(C.QUAR, os.path.basename(dest) + f".{int(time.time())}"))
        journal(f"Empreinte incorrecte ✗ — {os.path.basename(dest)} : mis en quarantaine, non installé.")
        raise C.Erreur(f"{os.path.basename(dest)} : empreinte incorrecte, fichier isolé en quarantaine.")
    journal(f"Empreinte vérifiée ✓ — {os.path.basename(dest)} ({_taille_lisible(tmp)})")
    shutil.move(tmp, dest)


def installer_outil_description(t=None):
    tok = C.token_hf()
    for depot, fichier in JOY:
        arbre = C.api_get(f"https://huggingface.co/api/models/{depot}/tree/main", tok)
        e = next((x for x in arbre if x.get("path") == fichier), None)
        if not e:
            raise C.Erreur(f"{fichier} introuvable sur Hugging Face ({depot}).")
        sha = ((e.get("lfs") or {}).get("oid") or "").lower()
        if len(sha) != 64:
            raise C.Erreur(f"{fichier} : pas d'empreinte SHA-256 publiée, téléchargement refusé.")
        _telecharger_verifie(f"https://huggingface.co/{depot}/resolve/main/{urllib.parse.quote(fichier)}",
                             _chemin_outil(fichier), sha, (e.get("lfs") or {}).get("size") or e.get("size"), tok)
    _telecharger_verifie(KOBOLD["url"], _chemin_outil(KOBOLD["fichier"]), KOBOLD["sha"], KOBOLD["taille"])
    os.chmod(_chemin_outil(KOBOLD["fichier"]), 0o755)
    return {"liens": [{"lien": "studio:joycaption", "nom": "Outil de description d'image (JoyCaption Beta One Q8)"}]}


def op_installer_outil(d):
    with VERROU:
        en_cours = [t for t in TRAVAUX.values() if t["type"] == "outil" and t["etat"] in ("attente", "encours")]
    if en_cours:
        return {"travail": en_cours[0]["id"]}
    t = nouveau_travail("outil", "Outil de description d'image", liste=bool(d.get("liste")))
    t["_hf"] = (d.get("jetons") or {}).get("hf")
    mettre_en_file(t, installer_outil_description)
    return {"travail": t["id"]}


def _kobold_pret(timeout=2):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{KOBOLD_PORT}/api/v1/model", timeout=timeout) as r:
            return json.loads(r.read()).get("result") not in (None, "inactive")
    except Exception:
        return False


def _limite_core():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (1, 1))   # 1 octet : aucun fichier core, même redirigé
    except Exception:
        pass


def kobold_demarrer():
    with _kobold_verrou:
        p = _kobold["proc"]
        if p and p.poll() is None:
            return
        try:
            comfy_post("/free", {"unload_models": True, "free_memory": True}, timeout=10)   # libère la mémoire GPU
        except Exception:
            pass
        # /dev/shm interdit l'exécution de programmes : koboldcpp (programme public) se décompresse donc sur le
        # disque, dans un dossier à part ; son répertoire de travail et HOME restent en mémoire vive.
        # (Vérifié dans le code de koboldcpp 1.122.1 : sans --savedatafile, il n'écrit aucun fichier.)
        tmp = os.path.join(C.PRIVE, "tmp", "kcpp")
        os.makedirs(tmp, exist_ok=True)
        extraction = os.path.join(OUTILS, "kcpp-tmp")
        shutil.rmtree(extraction, ignore_errors=True)
        os.makedirs(extraction, exist_ok=True)
        env = _env_propre()
        env.update(TMPDIR=extraction, HOME=tmp)
        cmd = [_chemin_outil(KOBOLD["fichier"]), "--model", _chemin_outil(JOY[0][1]), "--mmproj", _chemin_outil(JOY[1][1]),
               "--usecuda", "--gpulayers", "999", "--contextsize", "4096", "--host", "127.0.0.1",
               "--port", str(KOBOLD_PORT), "--quiet", "--skiplauncher"]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                             errors="replace", env=env, cwd=tmp, start_new_session=True, preexec_fn=_limite_core)
        _kobold["proc"] = p
        threading.Thread(target=lambda: [journal(l, "description") for l in p.stdout], daemon=True).start()
    for _ in range(400):
        if _kobold_pret():
            _kobold["dernier"] = time.time()
            return
        if p.poll() is not None:
            raise C.Erreur("L'outil de description s'est arrêté au démarrage (voir le journal).")
        time.sleep(1)
    raise C.Erreur("L'outil de description ne répond pas.")


def kobold_arreter():
    with _kobold_verrou:
        p = _kobold["proc"]
        _kobold["proc"] = None
    if p and p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGTERM)
            p.wait(timeout=20)
        except Exception:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except Exception:
                pass
        journal("Outil de description arrêté (mémoire GPU libérée).")


def surveiller_prix():
    while not RUNPOD_INFOS["prix"]:
        time.sleep(60)
        try:
            lire_prix()
        except Exception:
            pass


def surveiller_kobold():
    while True:
        time.sleep(30)
        p = _kobold["proc"]
        if p and p.poll() is None and not _description_verrou.locked() and time.time() - _kobold["dernier"] > 240:
            kobold_arreter()


def liberer_vram_pour_comfy():
    """Sur une carte de moins de 40 Go, l'outil de description cède la place à la génération."""
    p = _kobold["proc"]
    if p and p.poll() is None and C.profil_gpu() != "6000" and not _description_verrou.locked():
        kobold_arreter()


def _image_pour_description(chemin):
    try:
        from PIL import Image
        with Image.open(chemin) as im:
            im = im.convert("RGB")
            im.thumbnail((1024, 1024))
            b = io.BytesIO()
            im.save(b, "JPEG", quality=92)
            return "image/jpeg", b.getvalue()
    except ImportError:
        with open(chemin, "rb") as f:
            donnees = f.read()
        return ("image/png" if donnees[:4] == b"\x89PNG" else "image/jpeg"), donnees


def decrire(chemin, mode):
    with _description_verrou:
        t = getattr(_progres, "travail", None)
        if t is not None:
            t["detail"] = "Chargement de l'outil (environ une minute la première fois)"
        kobold_demarrer()
        if t is not None:
            t["detail"] = "Description en cours"
        type_, donnees = _image_pour_description(chemin)
        corps = {"model": "joycaption", "max_tokens": 700, "temperature": 0.6, "top_p": 0.9, "stream": False,
                 "messages": [{"role": "system", "content": "You are a helpful image captioner."},
                              {"role": "user", "content": [
                                  {"type": "text", "text": CONSIGNES.get(mode, CONSIGNES["description"])},
                                  {"type": "image_url", "image_url": {
                                      "url": f"data:{type_};base64," + base64.b64encode(donnees).decode()}}]}]}
        req = urllib.request.Request(f"http://127.0.0.1:{KOBOLD_PORT}/v1/chat/completions",
                                     data=json.dumps(corps).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=300) as r:
                rep = json.loads(r.read())
        finally:
            _kobold["dernier"] = time.time()
        texte = ((rep.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        texte = texte.strip()
        if not texte:
            raise C.Erreur("L'outil n'a rien renvoyé.")
        return texte


def op_decrire(d):
    if not outil_description_installe() and not TEST:
        raise C.Erreur("Installe d'abord l'outil de description.")
    chemin = chemin_image(d.get("image"))
    mode = d.get("mode") if d.get("mode") in CONSIGNES else "description"
    t = nouveau_travail("description", "Description de l'image")
    analyse_async(t, lambda t: {"texte": decrire(chemin, mode), "mode": mode})
    return {"travail": t["id"]}


# ---------------------------------------------------------------- zone privée, audit, état
def op_effacer(d):
    """Efface la zone privée (images, journal des modèles...) et vide la mémoire de ComfyUI."""
    try:
        comfy_post("/queue", {"clear": True}, timeout=5)
        comfy_post("/interrupt", {}, timeout=5)
        comfy_post("/history", {"clear": True}, timeout=5)
    except Exception:
        pass
    arreter_comfy()
    kobold_arreter()
    marque = os.path.join(C.ZONE_RAM, ".debut_session")
    try:
        debut = os.stat(marque).st_mtime
    except OSError:
        debut = None
    rc, sortie = capturer(C.cmd_effacer, True)
    if debut is not None:
        try:
            os.utime(marque, (debut, debut))
        except OSError:
            pass
    with VERROU:
        IMAGES.clear()
        VIGNETTES.clear()
        VERSION_IMAGES[0] += 1
    PLANS.clear()
    IMPORTS.clear()
    with VERROU:
        for t in list(TRAVAUX.values()):
            if t["etat"] in ("ok", "erreur", "arrete"):
                TRAVAUX.pop(t["id"], None)
    _JOURNAL.clear()
    journal("Zone privée effacée.")
    if not d.get("fin") and not TEST:
        threading.Thread(target=_relancer, daemon=True).start()
    return {"message": sortie.strip().splitlines()[-1] if sortie.strip() else "Zone effacée."}


def op_audit(d):
    t = nouveau_travail("audit", "Contrôle du disque")

    def fn(t):
        rc, sortie = capturer(C.cmd_audit)
        lignes = [l.replace("Envoie-moi la liste", "Envoie la liste à Claude") for l in sortie.splitlines()
                  if not re.fullmatch(r"\s*[=\-]{3,}\s*", l) and "CONTRÔLE DU DISQUE" not in l]
        return {"texte": "\n".join(lignes).strip(), "propre": rc == 0}
    analyse_async(t, fn)
    return {"travail": t["id"]}


def _paquet_pod():
    """Nom du paquet chargé au démarrage (paquet.txt, à côté de studio.py) ; None s'il est absent."""
    try:
        with open(os.path.join(CODE, "paquet.txt"), encoding="utf-8") as f:
            return (f.read().split() or [None])[0]
    except OSError:
        return None


PAQUET_POD = _paquet_pod()


def etat_pod():
    images_comfyui()
    e = {"phase": ETAT["phase"], "etape": ETAT["etape"], "etape_nom": ETAT["etape_nom"], "erreur": ETAT["erreur"],
         "comfy": ETAT["comfy"], "version": VERSION, "images": VERSION_IMAGES[0], "modeles": VERSION_MODELES[0],
         "paquet": PAQUET_POD}
    gpu = _cmd(["nvidia-smi", "--query-gpu=name,memory.used,memory.total", "--format=csv,noheader,nounits"], 5)
    if gpu:
        parts = [x.strip() for x in gpu.splitlines()[0].split(",")]
        if len(parts) == 3:
            e["gpu"] = {"nom": parts[0], "vram_utilisee": round(int(parts[1]) / 1024, 1),
                        "vram": round(int(parts[2]) / 1024, 1)}
    try:
        u = shutil.disk_usage("/workspace")
        e["disque_libre"] = go(u.free)
    except OSError:
        pass
    try:
        u = shutil.disk_usage("/dev/shm")
        e["ram_libre"] = go(u.free)
    except OSError:
        pass
    try:   # âge du conteneur = temps facturé approximatif (démarrage du processus 1)
        with open("/proc/uptime") as f:
            hote = float(f.read().split()[0])
        with open("/proc/1/stat") as f:
            debut = int(f.read().rsplit(")", 1)[1].split()[19]) / os.sysconf("SC_CLK_TCK")
        e["allume_depuis"] = max(0, int(hote - debut))
    except Exception:
        pass
    e["zone"] = C.zone_active() if not TEST else True
    p = _kobold["proc"]
    e["outil_description"] = {"installe": outil_description_installe() or TEST,
                              "charge": bool(p and p.poll() is None)}
    swap, txt = C.etat_swap()
    e["swap"] = {"risque": swap, "texte": txt}
    with VERROU:
        tous = list(TRAVAUX.values())
    e["travaux"] = [resume_travail(t) for t in tous]
    e["demandes"] = demandes_visibles()
    e["prix_heure"] = RUNPOD_INFOS.get("prix")
    e["terminable"] = bool(RUNPOD_CLE_POD and POD_ID)
    e["terminaison"] = dict(TERMINAISON)
    return e


# ---------------------------------------------------------------- le Pod se pilote lui-même (clé limitée à ce Pod)
# Runpod place dans chaque Pod une clé (RUNPOD_API_KEY) prévue pour ce Pod seulement : elle sert ici à connaître
# le tarif horaire et à terminer le Pod depuis l'application, sans que ta clé Runpod soit stockée nulle part.
# Ses droits exacts ne sont pas documentés : en cas de refus, l'application renvoie vers la page Runpod du Pod.
POD_ID = os.environ.get("RUNPOD_POD_ID") or None
RUNPOD_INFOS = {"prix": None, "essai": 0.0}
TERMINAISON = {"etat": None, "erreur": None}


def _appel_runpod(methode, url, corps=None, timeout=20):
    req = urllib.request.Request(url, method=methode, data=json.dumps(corps).encode() if corps is not None else None,
                                 headers={"Authorization": f"Bearer {RUNPOD_CLE_POD}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            texte = r.read().decode("utf-8", "replace")
            return r.status, texte
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")[:300]
    except Exception as e:
        return 0, type(e).__name__


def lire_prix():
    """Tarif horaire réel du Pod, lu une fois (puis toutes les 10 minutes en cas d'échec)."""
    if not RUNPOD_CLE_POD or not POD_ID or RUNPOD_INFOS["prix"] or time.time() - RUNPOD_INFOS["essai"] < 600:
        return
    RUNPOD_INFOS["essai"] = time.time()
    code, texte = _appel_runpod("GET", f"https://rest.runpod.io/v1/pods/{POD_ID}")
    try:
        j = json.loads(texte) if code == 200 else {}
        prix = j.get("adjustedCostPerHr") or j.get("costPerHr")
        if not prix:
            code, texte = _appel_runpod("POST", "https://api.runpod.io/graphql",
                                        {"query": "query { pod(input: {podId: \"%s\"}) { costPerHr } }" % POD_ID})
            prix = (((json.loads(texte) if code == 200 else {}).get("data") or {}).get("pod") or {}).get("costPerHr")
        if prix:
            RUNPOD_INFOS["prix"] = float(prix)
            journal(f"Tarif du Pod lu chez Runpod : {float(prix):.3f} $/h.")
        else:
            journal(f"Tarif du Pod non lisible avec la clé du Pod (réponse {code}).")
    except Exception:
        journal("Tarif du Pod non lisible avec la clé du Pod.")


def _terminer():
    time.sleep(1.5)   # laisse partir la réponse à l'application
    journal("Terminaison du Pod demandée à Runpod.")
    code, texte = _appel_runpod("DELETE", f"https://rest.runpod.io/v1/pods/{POD_ID}")
    if 200 <= code < 300:
        TERMINAISON.update(etat="ok")
        return
    code2, texte2 = _appel_runpod("POST", "https://api.runpod.io/graphql",
                                  {"query": "mutation { podTerminate(input: {podId: \"%s\"}) }" % POD_ID})
    if code2 == 200 and '"errors"' not in texte2:
        TERMINAISON.update(etat="ok")
        return
    TERMINAISON.update(etat="refuse", erreur=f"Runpod a refusé la terminaison avec la clé du Pod ({code} / {code2}).")
    journal(TERMINAISON["erreur"])


def op_terminer_pod(d):
    if not RUNPOD_CLE_POD or not POD_ID:
        raise C.Erreur("Ce Pod ne peut pas se terminer lui-même : termine-le sur Runpod.")
    if TERMINAISON["etat"] == "encours":
        return {}
    TERMINAISON.update(etat="encours", erreur=None)
    threading.Thread(target=_terminer, daemon=True).start()
    return {}


# ---------------------------------------------------------------- ComfyUI par tunnel SSH (ordinateur)
# Le serveur SSH ne sert qu'à un tunnel vers ComfyUI (127.0.0.1:8188) : pas de terminal, pas d'autre redirection,
# connexion par clé uniquement (la clé publique vient de ton compte Runpod, variable PUBLIC_KEY). Sa configuration,
# sa clé d'hôte et son journal restent en mémoire vive. Il n'est lancé que si tu l'actives dans l'application.
SSH_DIR = "/dev/shm/studio-ssh"
_ssh = {"proc": None, "empreinte": None, "cle_hote": None}
_ssh_verrou = threading.Lock()


def _ssh_binaires():
    return (os.environ.get("STUDIO_SSHD") or shutil.which("sshd") or "/usr/sbin/sshd",
            os.environ.get("STUDIO_SSH_KEYGEN") or shutil.which("ssh-keygen") or "/usr/bin/ssh-keygen")


def ssh_actif():
    p = _ssh["proc"]
    return bool(p and p.poll() is None)


def _travail_ssh():
    with VERROU:
        ts = [t for t in TRAVAUX.values() if t["type"] == "ssh"]
    return resume_travail(ts[-1]) if ts else None


def op_ssh_etat(d=None):
    sshd, _ = _ssh_binaires()
    return {"actif": ssh_actif(), "ip": os.environ.get("RUNPOD_PUBLIC_IP"), "port": os.environ.get("RUNPOD_TCP_PORT_22"),
            "cle_publique": bool((os.environ.get("PUBLIC_KEY") or "").strip()), "pod": POD_ID,
            "installe": os.path.exists(sshd), "empreinte": _ssh["empreinte"] if ssh_actif() else None,
            "installation": _travail_ssh(),
            "comfy": ETAT["comfy"]}


def _ssh_demarrer():
    sshd, keygen = _ssh_binaires()
    if not os.path.exists(sshd):
        journal("Installation du serveur SSH (paquet public openssh-server)…", "ssh")
        r = subprocess.run(["bash", "-c", "export DEBIAN_FRONTEND=noninteractive; (apt-get install -y -qq --no-install-recommends "
                            "openssh-server || (apt-get update -qq && apt-get install -y -qq --no-install-recommends "
                            "openssh-server)) && rm -f /etc/ssh/ssh_host_*"],
                           capture_output=True, text=True, env=_env_propre(), timeout=600)
        if r.returncode != 0 or not os.path.exists(sshd):
            raise C.Erreur("Installation du serveur SSH impossible : " + (r.stderr.strip()[-300:] or "erreur inconnue"))
    with _ssh_verrou:
        if ssh_actif():
            return
        shutil.rmtree(SSH_DIR, ignore_errors=True)
        os.makedirs(SSH_DIR, mode=0o700)
        cle = os.path.join(SSH_DIR, "hote_ed25519")
        r = subprocess.run([keygen, "-q", "-t", "ed25519", "-N", "", "-C", "studio", "-f", cle], capture_output=True, text=True)
        if r.returncode != 0:
            raise C.Erreur("Création de la clé d'hôte SSH impossible.")
        with open(os.path.join(SSH_DIR, "authorized_keys"), "w") as f:
            f.write("\n".join(l.strip() for l in (os.environ.get("PUBLIC_KEY") or "").splitlines() if l.strip()) + "\n")
        os.chmod(os.path.join(SSH_DIR, "authorized_keys"), 0o600)
        port = os.environ.get("STUDIO_SSH_PORT", "22")
        conf = f"""Port {port}
HostKey {cle}
PidFile {SSH_DIR}/sshd.pid
AuthorizedKeysFile {SSH_DIR}/authorized_keys
StrictModes no
PermitRootLogin prohibit-password
AllowUsers root
PubkeyAuthentication yes
AuthenticationMethods publickey
PasswordAuthentication no
KbdInteractiveAuthentication no
MaxAuthTries 3
LoginGraceTime 20
AllowTcpForwarding local
PermitOpen 127.0.0.1:8188 localhost:8188
GatewayPorts no
PermitTunnel no
X11Forwarding no
AllowAgentForwarding no
AllowStreamLocalForwarding no
PermitTTY no
ForceCommand /bin/false
PermitUserRC no
PermitUserEnvironment no
PrintMotd no
PrintLastLog no
ClientAliveInterval 30
ClientAliveCountMax 4
LogLevel INFO
"""
        if os.environ.get("STUDIO_TEST") != "1":
            conf += "UsePAM no\n"
        with open(os.path.join(SSH_DIR, "sshd_config"), "w") as f:
            f.write(conf)
        os.makedirs("/run/sshd", exist_ok=True)
        empreinte = _cmd([keygen, "-l", "-E", "sha256", "-f", cle + ".pub"], 10).split()
        _ssh["empreinte"] = empreinte[1] if len(empreinte) > 1 else None
        p = subprocess.Popen([sshd, "-D", "-e", "-f", os.path.join(SSH_DIR, "sshd_config")], stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=_env_propre(),
                             start_new_session=True)
        _ssh["proc"] = p
        threading.Thread(target=lambda: [journal(l, "ssh") for l in p.stdout], daemon=True).start()
    time.sleep(0.8)
    if not ssh_actif():
        raise C.Erreur("Le serveur SSH n'a pas démarré (voir le journal).")
    journal("Serveur SSH actif : tunnel vers ComfyUI uniquement, connexion par clé.", "ssh")


def op_ssh_activer(d):
    if not (os.environ.get("PUBLIC_KEY") or "").strip():
        raise C.Erreur("Aucune clé SSH publique sur ce Pod : ajoute la tienne dans Runpod (Settings → SSH Public Keys), "
                       "puis déploie un nouveau Pod.")
    if not os.environ.get("RUNPOD_TCP_PORT_22") and os.environ.get("STUDIO_TEST") != "1":
        raise C.Erreur("Le port 22 n'est pas exposé : ajoute 22 dans « Expose TCP Ports » de ton modèle Runpod, puis "
                       "déploie un nouveau Pod.")
    if ssh_actif():
        return op_ssh_etat()
    with VERROU:
        if any(t["type"] == "ssh" and t["etat"] in ("attente", "encours") for t in TRAVAUX.values()):
            return op_ssh_etat()
    t = nouveau_travail("ssh", "Serveur SSH pour ComfyUI")
    analyse_async(t, lambda t: _ssh_demarrer())
    return op_ssh_etat()


def op_ssh_desactiver(d):
    with _ssh_verrou:
        p = _ssh["proc"]
        _ssh["proc"] = None
    if p and p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGTERM)
            p.wait(timeout=10)
        except Exception:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except Exception:
                pass
    shutil.rmtree(SSH_DIR, ignore_errors=True)
    journal("Serveur SSH arrêté.", "ssh")
    return op_ssh_etat()


# ---------------------------------------------------------------- informations sur le Pod (aucune donnée privée)
_INFOS_FIXES = {}


def _lire(chemin):
    try:
        with open(chemin) as f:
            return f.read().strip()
    except OSError:
        return ""


def _versions():
    if not _INFOS_FIXES:
        py = "/root/venv-comfy/bin/python"
        if os.path.exists(py):
            v = _cmd([py, "-c", "import sys,torch;print(sys.version.split()[0]);print(torch.__version__);"
                      "print(torch.version.cuda or '?')"], 60).splitlines()
            if len(v) == 3:
                _INFOS_FIXES.update(python=v[0], torch=v[1], cuda=v[2])
        _INFOS_FIXES["comfyui"] = _cmd(["git", "-C", "/workspace/ComfyUI", "describe", "--tags", "--always"], 10) or "?"
        _INFOS_FIXES["paquet"] = (_lire(os.path.join(CODE, "paquet.txt")).split() or ["?"])[0]
        _INFOS_FIXES["cpu"] = next((l.split(":", 1)[1].strip() for l in _lire("/proc/cpuinfo").splitlines()
                                    if l.startswith("model name")), "?")
    return _INFOS_FIXES


def _go(o):
    return f"{o / 1024 ** 3:.1f} Go".replace(".", ",")


def op_infos(d):
    e = etat_pod()
    v = _versions()
    L = []

    def ligne(lib, val):
        L.append(f"  {lib:<21}{val}")

    q = _cmd(["nvidia-smi", "--query-gpu=name,memory.used,memory.total,temperature.gpu,power.draw,power.limit,"
              "driver_version,utilization.gpu", "--format=csv,noheader,nounits"], 5)
    L.append("CARTE GRAPHIQUE")
    if q:
        n, mu, mt, temp, pw, pl, drv, util = ([x.strip() for x in q.splitlines()[0].split(",")] + ["?"] * 8)[:8]
        ligne("Modèle", n)
        ligne("Mémoire vidéo", f"{int(mu) / 1024:.1f} / {int(mt) / 1024:.1f} Go".replace(".", ",")
              if mu.isdigit() and mt.isdigit() else f"{mu} / {mt} Mo")
        ligne("Utilisation", f"{util} %")
        ligne("Température", f"{temp} °C")
        ligne("Consommation", f"{pw} / {pl} W")
        ligne("Pilote NVIDIA", drv)
    else:
        L.append("  non détectée")
    L.append("MACHINE")
    ligne("Processeur", f"{v.get('cpu', '?')} · {os.cpu_count()} cœurs visibles")
    mem_max, mem_cur = _lire("/sys/fs/cgroup/memory.max"), _lire("/sys/fs/cgroup/memory.current")
    if mem_cur.isdigit():
        ligne("Mémoire vive", f"{_go(int(mem_cur))} utilisés" + (f" / {_go(int(mem_max))}" if mem_max.isdigit() else ""))
    ligne("Mémoire d'échange", e["swap"]["texte"])
    if e.get("allume_depuis") is not None:
        ligne("Allumé depuis", f"{e['allume_depuis'] // 3600} h {e['allume_depuis'] % 3600 // 60:02d} min")
    if os.environ.get("RUNPOD_DC_ID"):
        ligne("Centre de données", os.environ["RUNPOD_DC_ID"])
    if e.get("prix_heure"):
        ligne("Tarif", f"{e['prix_heure']:.3f} $/h (lu chez Runpod)".replace(".", ","))
    L.append("STOCKAGE")
    for nom, ch in (("Disque du conteneur", "/"), ("Volume /workspace", "/workspace"), ("Zone privée (RAM)", "/dev/shm")):
        try:
            u = shutil.disk_usage(ch)
            ligne(nom, f"{_go(u.used)} utilisés / {_go(u.total)} ({_go(u.free)} libres)")
        except OSError:
            pass
    L.append("LOGICIELS")
    ligne("Studio", f"{VERSION} · paquet {v.get('paquet', '?')}")
    ligne("ComfyUI", v.get("comfyui", "?"))
    ligne("Python", v.get("python", "?"))
    ligne("PyTorch / CUDA", f"{v.get('torch', '?')} / {v.get('cuda', '?')}")
    ext = [n for n, d in (("Krea2Edit 1.2.5", "comfyui-krea2edit"), ("Ostris Edit 1.0.1", "comfyui-krea2-ostris-edit"),
                          ("AnyPaint 0.1.0", "krea2-anypaint"))
           if os.path.isfile(f"/workspace/ComfyUI/custom_nodes/{d}/__init__.py")]
    ligne("Extensions", ", ".join(ext) or "aucune")
    L.append("ÉTAT")
    inv = inventaire()
    o = e["outil_description"]
    ligne("Installation", e["etape_nom"] + (f" — {e['erreur']}" if e.get("erreur") else ""))
    ligne("ComfyUI", "prêt" if e["comfy"] else "pas prêt")
    ligne("Outil de description", "chargé" if o["charge"] else "installé" if o["installe"] else "non installé")
    ligne("Tâches en cours", str(sum(1 for t in e["travaux"] if t["etat"] in ("attente", "encours"))))
    ligne("Modèles installés", f"{len(inv['principaux'])} modèle(s), {len(inv['loras'])} LoRA, "
                               f"{len(inv['embeddings'])} embedding(s), {len(inv['autres'])} composant(s)")
    ligne("Images en mémoire", str(len(IMAGES)))
    L.append("CONFIDENTIALITÉ")
    dumpable = None
    try:
        import ctypes
        dumpable = ctypes.CDLL(None).prctl(3, 0, 0, 0, 0)   # PR_GET_DUMPABLE
    except Exception:
        pass
    with _SESSIONS_VERROU:
        nb_app = sum(1 for a in APPAREILS.values() if a["confirme"])
    ligne("Zone privée", "active, en mémoire vive" if e["zone"] else "NON ACTIVE")
    ligne("Mémoire d'échange", ("RISQUE : " if e["swap"]["risque"] else "aucun risque · ") + e["swap"]["texte"])
    ligne("Fichiers « core »", "bloqués" if dumpable == 0 else "non vérifié" if dumpable is None else "possibles")
    ligne("Appareils autorisés", f"{nb_app} · la clé Studio seule ne donne pas accès")
    ligne("Demandes refusées", f"{sum(1 for t in REFUS if time.time() - t < 3600)} dans la dernière heure")
    ligne("Accès SSH", "actif (tunnel vers ComfyUI seulement)" if ssh_actif() else "arrêté")
    ligne("Journal", "en mémoire vive uniquement")
    return {"texte": "\n".join(L)}


# ---------------------------------------------------------------- serveur HTTP
OPS = {
    "etat": lambda d: etat_pod(),
    "modeles": lambda d: {**inventaire(), "samplers": SAMPLERS, "schedulers": SCHEDULERS},
    "analyser": op_analyser,
    "installer": op_installer,
    "installer_liste": op_installer_liste,
    "generer": op_generer,
    "arreter": op_arreter,
    "annuler_travail": op_annuler_travail,
    "supprimer_modele": op_supprimer_modele,
    "images": lambda d: {"images": liste_images(), "version": VERSION_IMAGES[0]},
    "supprimer_image": op_supprimer_image,
    "effacer": op_effacer,
    "audit": op_audit,
    "infos": op_infos,
    "importer": op_importer,
    "animer": op_animer,
    "retoucher": op_retoucher,
    "installer_outil": op_installer_outil,
    "decrire": op_decrire,
    "journal": lambda d: {"lignes": [f"{h} [{s}] {t}" for h, s, t in list(_JOURNAL)[-400:]]},
    "installer_officiel": op_installer_officiel,
    "installer_identite": op_installer_identite,
    "installer_adaptateur": op_installer_adaptateur,
    "terminer_pod": op_terminer_pod,
    "ssh_etat": op_ssh_etat,
    "analyser_workflow": op_analyser_workflow,
    "executer_workflow": op_executer_workflow,
    "ssh_activer": op_ssh_activer,
    "ssh_desactiver": op_ssh_desactiver,
    "appareils": op_appareils,
    "retirer_appareil": op_retirer_appareil,
    "approuver": op_approuver,
    # accès (seules opérations permises à un appareil pas encore autorisé)
    "statut_acces": op_statut_acces,
    "enregistrer": op_enregistrer,
    "demande_acces": op_demande_acces,
    "reveler": op_reveler,
    "etat_demande": op_etat_demande,
}


class Gestionnaire(http.server.BaseHTTPRequestHandler):
    server_version = "studio"
    sys_version = ""
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):   # aucun journal d'accès
        pass

    def _envoyer(self, code, corps, type_="application/octet-stream"):
        self.send_response(code)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Type", type_)
        self.send_header("Content-Length", str(len(corps)))
        self.end_headers()
        self.wfile.write(corps)

    def do_OPTIONS(self):
        self._envoyer(204, b"")

    def do_GET(self):
        self._envoyer(200, b"studio", "text/plain")

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > 48 * 1024 * 1024:
            self.close_connection = True
            return self._envoyer(400, b"requete", "text/plain")
        corps = self.rfile.read(n)
        if self.path == "/h":
            try:
                return self._envoyer(200, poignee(corps), "text/plain")
            except Exception:
                time.sleep(0.5)
                return self._envoyer(403, b"refuse", "text/plain")
        if self.path != "/x":
            return self._envoyer(404, b"", "text/plain")
        try:
            s, sid, ctr, req = dechiffrer(corps)
        except LookupError:
            return self._envoyer(401, b"session", "text/plain")
        except Exception:
            return self._envoyer(403, b"refuse", "text/plain")
        op = req.get("op")
        appareil = s["role"][0] == "appareil"
        if appareil == (op in OPS_ACCES) and not (appareil and op == "statut_acces"):
            # un appareil non autorisé n'a accès qu'aux opérations de demande d'accès (et inversement)
            return self._envoyer(200, chiffrer(s, sid, ctr, {"ok": False, "erreur": "Accès refusé : appareil non autorisé.",
                                                             "code": "non_autorise"}))
        try:
            if op == "image":
                donnees, type_img = lire_image(req.get("id"), bool(req.get("mini")))
                rep = chiffrer(s, sid, ctr, {"ok": True, "type": type_img}, donnees)
            elif op in OPS:
                req["_s"] = s
                rep = chiffrer(s, sid, ctr, {"ok": True, **(OPS[op](req) or {})})
            else:
                rep = chiffrer(s, sid, ctr, {"ok": False, "erreur": "opération inconnue"})
        except C.Erreur as e:
            rep = chiffrer(s, sid, ctr, {"ok": False, "erreur": str(e)})
        except Exception as e:
            journal(f"ERREUR {op} : {type(e).__name__}: {e}")
            rep = chiffrer(s, sid, ctr, {"ok": False, "erreur": f"Erreur interne ({type(e).__name__}) : {e}"})
        self._envoyer(200, rep)


class Serveur(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def sans_core():
    try:
        import ctypes
        ctypes.CDLL(None, use_errno=True).prctl(4, 0, 0, 0, 0)   # PR_SET_DUMPABLE = 0
    except Exception:
        journal("Protection contre les fichiers core indisponible.")


def main():
    sans_core()
    os.environ["TMPDIR"] = "/dev/shm"
    if CLE_STUDIO is None or len(CLE_STUDIO) < 16:
        journal("Clé Studio absente : aucun premier appareil ne pourra s'inscrire (vérifie STUDIO_CLE).")
    threading.Thread(target=ouvrier, daemon=True).start()
    threading.Thread(target=surveiller_prix, daemon=True).start()
    threading.Thread(target=surveiller_kobold, daemon=True).start()
    threading.Thread(target=installer, daemon=True).start()
    Serveur(("0.0.0.0", PORT), Gestionnaire).serve_forever()


if __name__ == "__main__":
    main()
