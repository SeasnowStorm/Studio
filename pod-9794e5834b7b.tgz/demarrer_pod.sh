#!/usr/bin/env bash
# =====================================================================
#  demarrer_pod.sh — lancé automatiquement à la création du Pod par l'application
#  (commande de démarrage du Pod). N'affiche rien de privé : la sortie
#  standard d'un Pod est conservée dans les journaux de Runpod.
# =====================================================================
export PYTHONDONTWRITEBYTECODE=1 HISTFILE=/dev/null PIP_DISABLE_PIP_VERSION_CHECK=1 PIP_NO_CACHE_DIR=1
ulimit -c 0
cd "$(dirname "$0")"
echo "Studio : démarrage"
if ! python3 -c "import cryptography" >/dev/null 2>&1; then
  python3 -m pip install -q --break-system-packages cryptography >/dev/null 2>&1 \
    || python3 -m pip install -q cryptography >/dev/null 2>&1
fi
if ! python3 -c "import cryptography" >/dev/null 2>&1; then
  echo "Studio : module de chiffrement indisponible, arrêt (rien d'autre n'est lancé)"
  exec sleep infinity
fi
echo "Studio : en attente de la connexion chiffrée de l'application"
python3 studio.py >/dev/null 2>&1
echo "Studio : le serveur s'est arrêté"
exec sleep infinity
