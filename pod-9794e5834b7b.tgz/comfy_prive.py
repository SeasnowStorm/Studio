#!/usr/bin/env python3
# Lance ComfyUI (main.py du dossier courant) sans fichier « core » possible : même si la machine
# hôte envoie les plantages à un programme, ce processus n'est pas « dumpable ».
import ctypes
import os
import runpy
import sys

try:
    ctypes.CDLL(None, use_errno=True).prctl(4, 0, 0, 0, 0)   # PR_SET_DUMPABLE = 0
except Exception:
    pass


class _AttentionCudnn:
    """Blackwell de centre de données : met l'attention cuDNN en tête de la liste de priorité de ComfyUI
    (comfy.ops.SDPA_BACKEND_PRIORITY), juste après le chargement de ce module. Les autres restent en repli
    automatique si cuDNN ne prend pas une forme donnée en charge. Le calcul reste exact."""
    def find_spec(self, name, path=None, target=None):
        if name != "comfy.ops":
            return None
        sys.meta_path.remove(self)
        import importlib.util
        spec = importlib.util.find_spec(name)
        if spec is None or spec.loader is None:
            return spec
        executer = spec.loader.exec_module

        def exec_module(module):
            executer(module)
            try:
                from torch.nn.attention import SDPBackend
                prio = getattr(module, "SDPA_BACKEND_PRIORITY", None)
                if isinstance(prio, list) and SDPBackend.CUDNN_ATTENTION in prio:
                    prio.remove(SDPBackend.CUDNN_ATTENTION)
                    prio.insert(0, SDPBackend.CUDNN_ATTENTION)
                    print("Studio : attention cuDNN en priorité (Blackwell)", flush=True)
            except Exception as e:
                print(f"Studio : priorité d'attention inchangée ({type(e).__name__})", flush=True)
        spec.loader.exec_module = exec_module
        return spec


if os.environ.get("STUDIO_ATTENTION_CUDNN") == "1":
    sys.meta_path.insert(0, _AttentionCudnn())
sys.path.insert(0, os.getcwd())
sys.argv[0] = os.path.join(os.getcwd(), "main.py")
runpy.run_path(sys.argv[0], run_name="__main__")
