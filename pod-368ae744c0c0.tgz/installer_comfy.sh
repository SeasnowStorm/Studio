#!/usr/bin/env bash
# =====================================================================
#  installer_comfy.sh (v4) — zone privée en mémoire vive + ComfyUI + outil « civitai »
#  À lancer au début de chaque session :  bash /root/installer_comfy.sh
#
#  Toutes les données privées (images, entrées, workflows, clés, journal,
#  historique du terminal, fichiers temporaires de ComfyUI) vont dans
#  /root/prive, qui est un LIEN vers /dev/shm/prive : de la mémoire vive,
#  jamais écrite sur le disque. Le script s'ARRÊTE si cette garantie ne
#  peut pas être assurée (pas de tmpfs, zone trop petite, swap possible).
#  Ne supprime aucun fichier contenant des données. Aucun secret.
# =====================================================================
set -euo pipefail

COMFY_VERSION="v0.39.2"
ZONE=/dev/shm/prive

echo "==> 1/6 Zone privée en mémoire vive"
if [ "$(stat -f -c %T /dev/shm 2>/dev/null)" != "tmpfs" ]; then
  echo "ARRÊT : /dev/shm n'est pas une zone en mémoire vive (tmpfs). Rien n'a été installé."; exit 1
fi
LIBRE_MO=$(df -Pm /dev/shm | awk 'NR==2{print $4}')
if [ "${LIBRE_MO:-0}" -lt 1024 ]; then
  echo "ARRÊT : zone en mémoire vive trop petite (${LIBRE_MO} Mo libres, 1024 Mo minimum)."; exit 1
fi
NB_SWAP=$(awk 'NR>1 && NF' /proc/swaps | wc -l)
SWAP_MAX=$(cat /sys/fs/cgroup/memory.swap.max 2>/dev/null || echo "?")
if [ "$NB_SWAP" -gt 0 ] && [ "$SWAP_MAX" != "0" ]; then
  echo "ARRÊT : la machine a une mémoire d'échange (swap) et le Pod peut l'utiliser (limite : $SWAP_MAX)."
  echo "        La mémoire vive pourrait alors être écrite sur un disque. Change de Pod ou de région."; exit 1
fi
if [ -L /root/prive ]; then
  [ "$(readlink -f /root/prive)" = "$ZONE" ] || { echo "ARRÊT : /root/prive pointe vers $(readlink -f /root/prive)"; exit 1; }
elif [ -d /root/prive ]; then
  if [ -n "$(find /root/prive -type f -print -quit)" ]; then
    echo "ARRÊT : /root/prive contient déjà des fichiers SUR LE DISQUE (ancienne version)."
    echo "        Récupère-les puis termine ce Pod ; rien n'a été modifié."; exit 1
  fi
  find /root/prive -depth -type d -empty -delete   # anciens dossiers VIDES uniquement
fi
mkdir -p "$ZONE"/{input,output,temp,tmp,.secrets,user/default/workflows}
chmod 700 "$ZONE" "$ZONE/.secrets"
[ -L /root/prive ] || ln -s "$ZONE" /root/prive
[ -f "$ZONE/.debut_session" ] || touch "$ZONE/.debut_session"
# Jeton Hugging Face : l'emplacement standard devient un lien vers la mémoire vive
mkdir -p /root/.cache/huggingface
if [ -f /root/.cache/huggingface/token ] && [ ! -L /root/.cache/huggingface/token ]; then
  mv /root/.cache/huggingface/token "$ZONE/.secrets/hf_token"
  echo "   (jeton HF trouvé sur le disque : déplacé en mémoire vive)"
fi
ln -sfn "$ZONE/.secrets/hf_token" /root/.cache/huggingface/token
for ancien in /root/.civitai_token:.secrets/civitai_token /root/civitai_journal.txt:.civitai_journal.txt \
              /root/.bash_history:.bash_history /root/mes_modeles_civitai.txt:mes_modeles_civitai.txt; do
  src=${ancien%%:*}; dst=$ZONE/${ancien#*:}
  if [ -f "$src" ] && [ ! -L "$src" ]; then mv "$src" "$dst"; echo "   ($src déplacé en mémoire vive)"; fi
done
# Historique des terminaux en mémoire vive, pas de fichier « core » en cas de plantage
if ! grep -q 'comfy-zone-ram' /root/.bashrc 2>/dev/null; then
  printf '\n# comfy-zone-ram\nexport HISTFILE=/root/prive/.bash_history\nulimit -c 0\n' >> /root/.bashrc
fi
echo "   /root/prive -> $ZONE (mémoire vive, ${LIBRE_MO} Mo libres)"

echo "==> 2/6 ComfyUI ${COMFY_VERSION}"
cd /workspace
if [ ! -d ComfyUI ]; then
  git clone https://github.com/Comfy-Org/ComfyUI.git
fi
cd /workspace/ComfyUI
git fetch --tags --quiet
git -c advice.detachedHead=false checkout "${COMFY_VERSION}"

echo "==> 3/6 Environnement Python (PyTorch verrouillé)"
if [ ! -d /root/venv-comfy ]; then
  python3 -m venv --system-site-packages /root/venv-comfy
fi
# shellcheck disable=SC1091
source /root/venv-comfy/bin/activate
pip freeze | grep -iE '^(torch|torchvision|torchaudio)==' > /root/torch-verrou.txt
pip install --quiet -r /workspace/ComfyUI/requirements.txt -c /root/torch-verrou.txt
python -c "import torch; print('PyTorch :', torch.__version__, '| GPU OK :', torch.cuda.is_available())"

echo "==> 4/6 Commande « civitai »"
install -m 755 /root/civitai.py /usr/local/bin/civitai
M=/workspace/ComfyUI/models
mkdir -p "$M/checkpoints" "$M/diffusion_models" "$M/text_encoders" "$M/vae" "$M/loras" \
         "$M/controlnet" "$M/embeddings" "$M/upscale_models"

echo "==> 5/6 GPU détecté"
VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -n1)
NOM=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)
if [ "${VRAM:-0}" -ge 40000 ]; then PROFIL=6000; else PROFIL=4090; fi
echo "   ${NOM} (${VRAM} MiB) -> profil ${PROFIL}"

echo "==> 6/6 Vérification"
[ "$(readlink -f /root/prive)" = "$ZONE" ] && [ "$(stat -f -c %T /root/prive/)" = "tmpfs" ] \
  && echo "   Zone privée : ACTIVE (mémoire vive)" || { echo "ARRÊT : zone privée non active."; exit 1; }

echo ""
echo "Installation terminée."
echo "  - Clé Civitai pour la session : civitai login"
echo "  - Contrôler le disque         : civitai audit"
