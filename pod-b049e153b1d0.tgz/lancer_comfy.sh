#!/usr/bin/env bash
# =====================================================================
#  lancer_comfy.sh (v2) — Démarre ComfyUI en mode privé
#  À lancer dans la fenêtre connectée avec le tunnel SSH (-L 8188:...)
#  Puis ouvrir http://localhost:8188 dans le navigateur Windows.
#  Toutes les écritures privées de ComfyUI vont dans /root/prive (mémoire vive).
#  Arrêt : Ctrl + C
# =====================================================================
set -euo pipefail

if [ "$(readlink -f /root/prive)" != "/dev/shm/prive" ] || [ "$(stat -f -c %T /root/prive/)" != "tmpfs" ]; then
  echo "ARRÊT : la zone privée en mémoire vive n'est pas active. Lance d'abord installer_comfy.sh."; exit 1
fi
ulimit -c 0                          # pas de fichier « core » sur le disque en cas de plantage
export TMPDIR=/root/prive/tmp        # fichiers temporaires Python en mémoire vive
export HISTFILE=/root/prive/.bash_history

# shellcheck disable=SC1091
source /root/venv-comfy/bin/activate
cd /workspace/ComfyUI

EXTRA=()
# Base de données interne de ComfyUI (si cette version en a une) : en mémoire vive, pas sur /workspace
if python main.py --help 2>/dev/null | grep -q -- '--database-url'; then
  EXTRA+=(--database-url "sqlite:////root/prive/user/comfyui.db")
fi

# Mode Studio (application iPhone) : pas de fichier « core », pas de prompt dans les PNG enregistrés
LANCEUR=(python main.py)
if [ "${COMFY_PRIVE:-}" = "1" ] && [ -f /root/comfy_prive.py ]; then
  LANCEUR=(python /root/comfy_prive.py)
  EXTRA+=(--disable-metadata)
fi

exec "${LANCEUR[@]}" \
  --listen 127.0.0.1 --port 8188 \
  --output-directory /root/prive/output \
  --input-directory  /root/prive/input \
  --temp-directory   /root/prive/temp \
  --user-directory   /root/prive/user \
  --offline \
  "${EXTRA[@]}"
