#!/usr/bin/env python3
# Lance ComfyUI (main.py du dossier courant) sans fichier « core » possible : même si la machine
# hôte envoie les plantages à un programme, ce processus n'est pas « dumpable ».
import ctypes
import os
import runpy
import sys

try:
    ctypes.CDLL(None, use_errno=True).prctl(4, 0, 0, 0, 0)   # PR_SET_DUMPABLE = 0
except Exception:
    pass
sys.path.insert(0, os.getcwd())
sys.argv[0] = os.path.join(os.getcwd(), "main.py")
runpy.run_path(sys.argv[0], run_name="__main__")
