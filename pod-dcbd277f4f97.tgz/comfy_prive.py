#!/usr/bin/env python3
# Lance ComfyUI (main.py du dossier courant) sans fichier « core » possible : même si la machine
# hôte envoie les plantages à un programme, ce processus n'est pas « dumpable ».
import ctypes
import os
import runpy
import sys

try:
    ctypes.CDLL(None, use_errno=True).prctl(4, 0, 0, 0, 0)   # PR_SET_DUMPABLE = 0
except Exception:
    pass


class _AttentionCudnn:
    """Blackwell de centre de données : met l'attention cuDNN en tête de la liste de priorité de ComfyUI
    (comfy.ops.SDPA_BACKEND_PRIORITY), juste après le chargement de ce module. Les autres restent en repli
    automatique si cuDNN ne prend pas une forme donnée en charge. Le calcul reste exact."""
    def find_spec(self, name, path=None, target=None):
        if name != "comfy.ops":
            return None
        sys.meta_path.remove(self)
        import importlib.util
        spec = importlib.util.find_spec(name)
        if spec is None or spec.loader is None:
            return spec
        executer = spec.loader.exec_module

        def exec_module(module):
            executer(module)
            try:
                from torch.nn.attention import SDPBackend
                prio = getattr(module, "SDPA_BACKEND_PRIORITY", None)
                if isinstance(prio, list) and SDPBackend.CUDNN_ATTENTION in prio:
                    prio.remove(SDPBackend.CUDNN_ATTENTION)
                    prio.insert(0, SDPBackend.CUDNN_ATTENTION)
                    print("Studio : attention cuDNN en priorité (Blackwell)", flush=True)
            except Exception as e:
                print(f"Studio : priorité d'attention inchangée ({type(e).__name__})", flush=True)
        spec.loader.exec_module = exec_module
        return spec


class _SonSansSaturation:
    """Son de MiniMax H3 / 10Eros : le décodage audio de ComfyUI (comfy_extras.nodes_audio.vae_decode_audio) ne
    réduit le volume que d'après l'écart type. Les sons brefs et forts (chocs, bruits mouillés) peuvent alors dépasser
    la pleine échelle et saturer (son « déformé ») dans le MP4. Ici, seulement si la crête dépasse -1 dBFS, toute la
    piste est baissée du même facteur : rien n'est modifié sinon, aucune distorsion ajoutée."""
    def find_spec(self, name, path=None, target=None):
        if name != "comfy_extras.nodes_audio":
            return None
        sys.meta_path.remove(self)
        import importlib.util
        spec = importlib.util.find_spec(name)
        if spec is None or spec.loader is None:
            return spec
        executer = spec.loader.exec_module

        def exec_module(module):
            executer(module)
            origine = getattr(module, "vae_decode_audio", None)
            if not callable(origine):
                print("Studio : limiteur de son non installé", flush=True)
                return

            def vae_decode_audio(*a, **k):
                sortie = origine(*a, **k)
                try:
                    w = sortie["waveform"]
                    crete = w.abs().amax(dim=tuple(range(1, w.dim())), keepdim=True)
                    plafond = 0.891   # -1 dBFS : marge pour l'encodage AAC
                    sortie["waveform"] = w * (plafond / crete.clamp(min=plafond))
                except Exception as e:
                    print(f"Studio : limiteur de son ignoré ({type(e).__name__})", flush=True)
                return sortie
            module.vae_decode_audio = vae_decode_audio
        spec.loader.exec_module = exec_module
        return spec


sys.meta_path.insert(0, _SonSansSaturation())
if os.environ.get("STUDIO_ATTENTION_CUDNN") == "1":
    sys.meta_path.insert(0, _AttentionCudnn())
sys.path.insert(0, os.getcwd())
sys.argv[0] = os.path.join(os.getcwd(), "main.py")
runpy.run_path(sys.argv[0], run_name="__main__")
