#!/usr/bin/env python3
# =====================================================================
#  civitai — téléchargement vérifié de ressources Civitai pour ComfyUI
#  (installé sur le Pod par installer_comfy.sh dans /usr/local/bin/civitai)
#
#  civitai login                 enregistre la clé API pour la session
#  civitai logout                efface la clé API du Pod
#  civitai <lien>                télécharge un modèle / LoRA / VAE ...
#  civitai image <lien image>    télécharge tout ce qu'utilise une image
#  civitai liste <fichier>       télécharge tous les liens d'un fichier
#  civitai journal               affiche les liens téléchargés ce jour
#  civitai krea2-composants      encodeur + VAE officiels de Krea 2 (Hugging Face)
#
#  Options : --profil 4090|6000 (sinon détecté via la VRAM), -y (pas de question)
#
#  Sécurité : uniquement des fichiers .safetensors ; empreinte SHA-256
#  vérifiée avant mise en place ; fichier douteux -> /workspace/quarantaine ;
#  refus des ressources représentant une personne réelle (poi) ou marquées
#  « minor ». La clé API n'est jamais affichée ni passée en argument.
#  Aucun fichier n'est supprimé.
# =====================================================================
import datetime
import getpass
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import urllib.parse

API = "https://civitai.com/api/v1"
MODELS = "/workspace/ComfyUI/models"
TMP = "/workspace/.telechargements"
QUAR = "/workspace/quarantaine"
# Toutes les données privées vivent dans /root/prive, lien vers /dev/shm/prive (mémoire vive uniquement).
PRIVE = "/root/prive"
ZONE_RAM = "/dev/shm/prive"
SECRETS = PRIVE + "/.secrets"
TOKEN_FILE = SECRETS + "/civitai_token"
JOURNAL = PRIVE + "/.civitai_journal.txt"
PRIVE_INPUT = PRIVE + "/input"
WORKFLOWS = PRIVE + "/user/default/workflows"
SOUS_DOSSIERS = ("input", "output", "temp", "tmp", ".secrets", "user/default/workflows")
DOMAINES = ("civitai.com", "civitai.red", "civitai.green")

# Type Civitai -> dossier ComfyUI (les Checkpoint sont décidés après lecture du fichier)
TYPE_DOSSIER = {
    "LORA": "loras", "LoCon": "loras", "DoRA": "loras",
    "TextualInversion": "embeddings", "VAE": "vae",
    "Controlnet": "controlnet", "Upscaler": "upscale_models",
    "Checkpoint": None, "Workflows": "workflows",
}
# Taille maximale préférée d'un fichier selon le profil GPU (Go)
LIMITE_GO = {"4090": 14, "6000": 60}
# Types de fichiers Civitai acceptés (« Diffusion Model » = modèle de diffusion seul, ex. Krea 2 ;
#  « Negative » / « Positive » = fichiers d'embedding)
TYPES_FICHIER = ("Model", "Pruned Model", "Diffusion Model", "Negative", "Positive")  # Negative/Positive : embeddings
QUALITE_FP = {"bf16": 3, "fp16": 3, "fp32": 2.5, "fp8": 2, "nf4": 1, "fp4": 1}

KREA2 = [
    ("https://huggingface.co/Comfy-Org/Krea-2/resolve/main/text_encoders/qwen3vl_4b_bf16.safetensors",
     "text_encoders/krea2/qwen3vl_4b_bf16.safetensors",
     "36f3ff447ef59201722e8f9ce6020c9819fdcfba6aa2608c4e09b1c0ce114e34"),
    ("https://huggingface.co/Comfy-Org/Krea-2/resolve/main/vae/qwen_image_vae.safetensors",
     "vae/krea2/qwen_image_vae.safetensors",
     "a70580f0213e67967ee9c95f05bb400e8fb08307e017a924bf3441223e023d1f"),
]


AIDE = """Usage :
  civitai login                  enregistre ta clé API Civitai pour la session (ne s'affiche pas)
  civitai logout                 efface la clé API du Pod
  civitai hf-login               enregistre ton jeton Hugging Face pour la session (dépôts protégés)
  civitai hf-logout              efface le jeton Hugging Face du Pod
  civitai <lien>                 télécharge la ressource d'une page Civitai (modèle, LoRA, VAE...)
  civitai image <lien image>     télécharge tout ce qu'utilise une image + ses paramètres
  civitai liste <fichier>        télécharge tous les liens contenus dans un fichier
  civitai journal                liste ce qui a été téléchargé pendant la session
  civitai krea2-composants       encodeur de texte + VAE officiels de Krea 2 (Hugging Face)
  civitai flux2-composants       encodeur de texte + VAE officiels de Flux.2 Klein 9B (Hugging Face)
  civitai hf <lien fichier>      télécharge un fichier .safetensors depuis Hugging Face
  civitai effacer                efface tout le contenu de la zone privée en mémoire vive
  civitai audit                  liste les fichiers écrits sur le DISQUE depuis le début de la session
  civitai etat                   affiche l'état du Pod : GPU, mémoire, disque, ComfyUI, modèles installés
Options : --profil 4090|6000 (sinon détecté automatiquement), -y (ne pas poser de question)"""


class Erreur(Exception):
    pass


# ---------------------------------------------------------------- outils
def lire_token():
    t = os.environ.get("CIVITAI_TOKEN", "").strip()
    if not t and os.path.isfile(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            t = f.read().strip()
    return t or None


def _curl(args, token, capture=True):
    """Appelle curl ; la clé passe par stdin (-K -), jamais en argument visible."""
    cfg = f'header = "Authorization: Bearer {token}"\n' if token else ""
    cmd = ["curl", "--retry", "3", "--connect-timeout", "20", "-K", "-"] + args
    return subprocess.run(cmd, input=cfg, text=True, capture_output=capture)


def api_get(chemin, token=None):
    url = chemin if chemin.startswith("http") else API + chemin
    r = _curl(["-sS", "-L", "-w", "\n%{http_code}", url], token)
    if r.returncode != 0:
        raise Erreur(f"Connexion impossible à Civitai : {r.stderr.strip()}")
    corps, _, code = r.stdout.rpartition("\n")
    code = int(code or 0)
    if code == 404:
        raise Erreur("Introuvable (404) : ressource supprimée, privée ou lien incorrect.")
    if code in (401, 403):
        raise Erreur(f"Accès refusé ({code}) : lance « civitai login », ou ressource en accès anticipé.")
    if code != 200:
        raise Erreur(f"Réponse inattendue de Civitai (HTTP {code}).")
    try:
        return json.loads(corps)
    except json.JSONDecodeError:
        raise Erreur("Réponse illisible de Civitai.")


def telecharger(url, dest, token):
    print(f"   -> téléchargement de {os.path.basename(dest)}")
    r = _curl(["-S", "-f", "-L", "-#", "-o", dest, url], token, capture=False)
    if r.returncode != 0:
        raise Erreur(f"Téléchargement échoué (code curl {r.returncode}).")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for bloc in iter(lambda: f.read(16 * 1024 * 1024), b""):
            h.update(bloc)
    return h.hexdigest()


def entete_safetensors(path):
    """Lit l'en-tête JSON d'un .safetensors ; None si le fichier n'en est pas un."""
    try:
        with open(path, "rb") as f:
            n = struct.unpack("<Q", f.read(8))[0]
            if n <= 0 or n > 200_000_000:
                return None
            h = json.loads(f.read(n))
        return h if isinstance(h, dict) else None
    except Exception:
        return None


def dossier_checkpoint(entete):
    """Fichier complet (avec VAE) -> checkpoints ; modèle de diffusion seul -> diffusion_models."""
    cles = entete.keys()
    if any(k.startswith(("first_stage_model.", "vae.")) for k in cles):
        return "checkpoints"
    return "diffusion_models"


def slug(texte):
    s = re.sub(r"[^a-z0-9.]+", "-", (texte or "autre").lower()).strip("-")
    return s or "autre"


def nom_sur(nom):
    nom = os.path.basename(nom or "fichier")
    return re.sub(r"[^A-Za-z0-9._-]+", "_", nom)


def go(kb):
    return (kb or 0) / 1024 / 1024


_CC = []


def capacite_gpu():
    """(majeur, mineur) de la carte, ex. (10, 3) pour une B300 ; None si inconnue. STUDIO_GPU_CC=10.3 pour les tests."""
    if not _CC:
        v = os.environ.get("STUDIO_GPU_CC")
        try:
            if not v:
                v = subprocess.run(["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"],
                                   capture_output=True, text=True, timeout=10).stdout.split()[0]
            a, b = v.strip().split(".")
            _CC.append((int(a), int(b)))
        except Exception:
            _CC.append(None)
    return _CC[0]


_VRAM = []


def vram_mo():
    """Mémoire de la carte en Mio (0 si inconnue). STUDIO_GPU_VRAM pour les tests."""
    if not _VRAM:
        v = os.environ.get("STUDIO_GPU_VRAM")
        try:
            if not v:
                v = subprocess.run(["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                                   capture_output=True, text=True, timeout=10).stdout.split()[0]
            _VRAM.append(int(float(v)))
        except Exception:
            _VRAM.append(0)
    return _VRAM[0]


def grande_carte():
    """80 Go ou plus (RTX PRO 6000 96 Go, H100, H200…) hors B300 : place pour les versions les plus fidèles qui restent
    rapides sur la carte (int8 convrot plutôt que 4 bits)."""
    return vram_mo() >= 80000 and not int8_lent()


def int8_lent():
    """B300 / GB300 (Blackwell Ultra, sm_103) : ~0,15 POPS en INT8 contre 4,5 PFLOPS en FP8 et 14 en FP4.
    Sur ces cartes, les formats int8 (int8 convrot, w4a8…) sont à éviter : bf16, fp8 ou nvfp4 à la place."""
    return capacite_gpu() == (10, 3)


_MOTS_LENTS = re.compile(r"int8|convrot|w4a8|w6a8|w8a8|(?<![a-z0-9])int4(?![a-z0-9])|svdq")


def format_lent(nom="", fp="", entete=None):
    """Format qui calcule en int8 (int8, int8 convrot, w4a8, w6a8…) : d'après le nom, la précision annoncée par Civitai,
    ou le type majoritaire des tenseurs de l'en-tête .safetensors."""
    if _MOTS_LENTS.search((nom or "").lower()) or (fp or "").lower() in ("int8", "int4"):
        return True
    if entete:
        poids = {}
        for k, v in entete.items():
            if k != "__metadata__" and isinstance(v, dict) and v.get("dtype"):
                n = 1
                for x in v.get("shape") or []:
                    n *= int(x)
                poids[v["dtype"]] = poids.get(v["dtype"], 0) + n
        if poids and max(poids, key=poids.get) == "I8":
            return True
    return False


def interdit_ici(nom="", fp="", entete=None):
    """Sur une B300, Studio n'installe ni n'utilise de format int8 : il y serait ~30 fois plus lent."""
    return int8_lent() and format_lent(nom, fp, entete)


def profil_gpu(force=None):
    if force:
        return force
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True).stdout.split()
        return "6000" if int(out[0]) >= 40000 else "4090"
    except Exception:
        return "4090"


def demander(question, oui_auto=False):
    if oui_auto:
        return True
    try:
        rep = input(f"{question} [o/N] ").strip().lower()
    except EOFError:
        return False
    return rep in ("o", "oui", "y", "yes")


def analyser_lien(lien):
    p = urllib.parse.urlparse(lien.strip())
    hote = p.netloc.lower()
    if hote.startswith("www."):
        hote = hote[4:]
    if p.scheme != "https" or hote not in DOMAINES:
        raise Erreur("Lien refusé : seuls les liens https://civitai.red (ou .com) sont acceptés.")
    q = urllib.parse.parse_qs(p.query)
    m = re.match(r"^/models/(\d+)", p.path)
    if m:
        vid = q.get("modelVersionId", [None])[0]
        return ("modele", int(m.group(1)), int(vid) if vid and vid.isdigit() else None)
    m = re.match(r"^/api/download/models/(\d+)", p.path)
    if m:
        return ("version", None, int(m.group(1)))
    m = re.match(r"^/images/(\d+)", p.path)
    if m:
        return ("image", int(m.group(1)), None)
    raise Erreur("Lien non reconnu : copie l'adresse d'une page de modèle ou d'image Civitai.")


def journaliser(vid, mid, nom, dest):
    with open(JOURNAL, "a") as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M}\t{vid}\t"
                f"https://civitai.red/models/{mid}?modelVersionId={vid}\t{nom}\t{dest}\n")


# ------------------------------------------------------- préparation
def preparer(vid, profil, token, poids=None):
    """Interroge Civitai et retourne un plan de téléchargement (sans rien télécharger)."""
    v = api_get(f"/model-versions/{vid}", token)
    mid = v.get("modelId")
    modele = api_get(f"/models/{mid}", token) if mid else {}
    m = v.get("model") or {}
    nom = f"{m.get('name') or modele.get('name', '?')} — {v.get('name', '')}"
    type_c = m.get("type") or modele.get("type") or "?"

    if m.get("poi") or modele.get("poi"):
        raise Erreur(f"{nom} : refusé (ressource représentant une personne réelle).")
    if modele.get("minor"):
        raise Erreur(f"{nom} : refusé (ressource marquée « minor »).")
    if m.get("mode") in ("Archived", "TakenDown"):
        raise Erreur(f"{nom} : ressource archivée ou retirée, aucun fichier disponible.")
    if v.get("usageControl") not in (None, "Download"):
        raise Erreur(f"{nom} : téléchargement non autorisé par le créateur ({v.get('usageControl')}).")
    if type_c not in TYPE_DOSSIER:
        raise Erreur(f"{nom} : type « {type_c} » non pris en charge.")

    fichiers = []
    for f in v.get("files") or []:
        meta = f.get("metadata") or {}
        fmt = (meta.get("format") or "").lower()
        n = (f.get("name") or "").lower()
        if type_c == "Workflows":
            ok = n.endswith(".json")
        else:
            ok = f.get("type") in TYPES_FICHIER and (fmt == "safetensor" or n.endswith(".safetensors"))
        if ok and not (type_c != "Workflows" and interdit_ici(f.get("name"), meta.get("fp"))):
            fichiers.append(f)
    if not fichiers and int8_lent() and any(interdit_ici(f.get("name"), (f.get("metadata") or {}).get("fp"))
                                             for f in v.get("files") or []):
        raise Erreur(f"{nom} : cette version n'existe qu'en int8 (ou w4a8), un format environ 30 fois plus lent sur ta B300. "
                     "Studio ne l'installe pas : prends une version bf16, fp8 ou nvfp4 de ce modèle.")
    if not fichiers:
        tous = v.get("files") or []
        if not tous:
            raise Erreur(f"{nom} : Civitai ne propose aucun fichier téléchargeable pour cette version "
                         f"(disponibilité : {v.get('availability', '?')}, usage : {v.get('usageControl', '?')}). "
                         "Ressource probablement réservée à la génération sur le site.")
        detail = "; ".join(f"{f.get('name')} (type {f.get('type')}, format {(f.get('metadata') or {}).get('format')})"
                           for f in tous)
        raise Erreur(f"{nom} : aucun fichier .safetensors accepté. Fichiers proposés : {detail}")

    limite = LIMITE_GO.get(profil, 14)

    def score(f):
        meta = f.get("metadata") or {}
        q = QUALITE_FP.get((meta.get("fp") or "").lower(), 2.5)
        if "int8" in (f.get("name") or "").lower() or (meta.get("fp") or "").lower() == "int8":
            q = 0.2 if int8_lent() else 1.5  # int8 : très lent sur B300, prise en charge incertaine ailleurs
        tient = go(f.get("sizeKB")) <= limite
        taille = go(f.get("sizeKB"))
        # à qualité égale : le plus léger sur 4090, le plus complet sur 6000
        departage = taille if profil == "6000" else -taille
        return (tient, q if tient else -taille, departage, bool(f.get("primary")))

    choix = max(range(len(fichiers)), key=lambda i: score(fichiers[i]))
    return {"vid": vid, "mid": mid, "nom": nom, "type": type_c, "base": v.get("baseModel") or "?",
            "mots": v.get("trainedWords") or [], "fichiers": fichiers, "choix": choix,
            "licence": licence(modele), "createur": (modele.get("creator") or {}).get("username", "?"),
            "maj": (v.get("updatedAt") or v.get("publishedAt") or "")[:10], "poids": poids}


def licence(modele):
    com = modele.get("allowCommercialUse")
    if isinstance(com, list):
        com = ", ".join(com) if com else "aucun"
    return (f"usage commercial : {com or '?'} | dérivés : {modele.get('allowDerivatives', '?')} | "
            f"crédit requis : {'non' if modele.get('allowNoCredit') else 'oui'}")


def afficher(plan, interactif=True):
    print(f"\n== {plan['nom']}")
    print(f"   type : {plan['type']} | architecture : {plan['base']} | créateur : {plan['createur']} | mis à jour : {plan['maj']}")
    print(f"   {plan['licence']}")
    if plan["mots"]:
        print(f"   mots-clés du créateur : {', '.join(plan['mots'][:8])}")
    if plan["poids"] is not None:
        print(f"   poids utilisé dans l'image : {plan['poids']}")
    for i, f in enumerate(plan["fichiers"]):
        meta = f.get("metadata") or {}
        scans = f"virus:{f.get('virusScanResult', '?')} pickle:{f.get('pickleScanResult', '?')}"
        marque = "->" if i == plan["choix"] else "  "
        print(f"   {marque} [{i + 1}] {f.get('name')} | {go(f.get('sizeKB')):.2f} Go | "
              f"{meta.get('fp', '?')} {meta.get('size', '')} | {scans}")
    if interactif and len(plan["fichiers"]) > 1:
        try:
            rep = input(f"   Fichier à télécharger [Entrée = {plan['choix'] + 1}] : ").strip()
        except EOFError:
            rep = ""
        if rep.isdigit() and 1 <= int(rep) <= len(plan["fichiers"]):
            plan["choix"] = int(rep) - 1


# ------------------------------------------------------- exécution
def executer(plan, token):
    f = plan["fichiers"][plan["choix"]]
    if f.get("virusScanResult") == "Danger" or f.get("pickleScanResult") == "Danger":
        raise Erreur(f"{plan['nom']} : fichier signalé dangereux par Civitai, refusé.")
    sha_attendu = ((f.get("hashes") or {}).get("SHA256") or "").lower()
    if len(sha_attendu) != 64:
        raise Erreur(f"{plan['nom']} : Civitai ne publie pas d'empreinte SHA-256, vérification impossible.")

    nom = nom_sur(f.get("name"))
    os.makedirs(TMP, exist_ok=True)
    os.makedirs(QUAR, exist_ok=True)

    # déjà présent ?
    for racine, _, noms in os.walk(MODELS):
        if nom in noms:
            existant = os.path.join(racine, nom)
            if sha256(existant) == sha_attendu:
                print(f"   [déjà présent, vérifié] {os.path.relpath(existant, MODELS)}")
                journaliser(plan["vid"], plan["mid"], plan["nom"], existant)
                return existant

    besoin = (f.get("sizeKB") or 0) * 1024 * 1.05
    if shutil.disk_usage("/workspace").free < besoin:
        raise Erreur(f"{plan['nom']} : espace disque insuffisant sur /workspace.")

    url = f.get("downloadUrl") or ""
    if not f.get("primary") and "?" not in url:
        meta = f.get("metadata") or {}
        params = {"type": f.get("type"), "format": meta.get("format"), "size": meta.get("size"), "fp": meta.get("fp")}
        url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v})
    tmp = os.path.join(TMP, nom + ".part")
    telecharger(url, tmp, token)

    print("   -> vérification de l'empreinte SHA-256 ...")
    if sha256(tmp) != sha_attendu:
        q = os.path.join(QUAR, f"{nom}.{datetime.datetime.now():%Y%m%d-%H%M%S}")
        shutil.move(tmp, q)
        raise Erreur(f"{plan['nom']} : empreinte incorrecte, fichier isolé dans {q}")

    if plan["type"] == "Workflows":
        try:
            with open(tmp) as fh:
                json.load(fh)
        except Exception:
            shutil.move(tmp, os.path.join(QUAR, nom))
            raise Erreur(f"{plan['nom']} : workflow illisible, isolé en quarantaine.")
        os.makedirs(WORKFLOWS, exist_ok=True)
        dest = os.path.join(WORKFLOWS, nom)
    else:
        entete = entete_safetensors(tmp)
        if entete is None:
            q = os.path.join(QUAR, nom)
            shutil.move(tmp, q)
            raise Erreur(f"{plan['nom']} : ce n'est pas un .safetensors valide, isolé dans {q}")
        dossier = TYPE_DOSSIER[plan["type"]] or dossier_checkpoint(entete)
        if plan["type"] == "TextualInversion":
            dest = os.path.join(MODELS, dossier, nom)  # racine : s'écrit « embedding:nom » dans un prompt
        else:
            dest = os.path.join(MODELS, dossier, slug(plan["base"]), nom)
        if os.path.exists(dest):
            racine, ext = os.path.splitext(dest)
            dest = f"{racine}_v{plan['vid']}{ext}"
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.move(tmp, dest)
    journaliser(plan["vid"], plan["mid"], plan["nom"], dest)
    print(f"   [OK] {dest}")
    return dest


def traiter_plans(plans, token, oui_auto):
    if not plans:
        print("Rien à télécharger.")
        return 1
    total = sum(go(p["fichiers"][p["choix"]].get("sizeKB")) for p in plans)
    print(f"\nTotal : {len(plans)} fichier(s), {total:.2f} Go.")
    if not demander("Lancer le téléchargement ?", oui_auto):
        print("Annulé, rien n'a été téléchargé.")
        return 1
    erreurs = 0
    for p in plans:
        try:
            p["dest"] = executer(p, token)
        except Erreur as e:
            erreurs += 1
            print(f"   [ÉCHEC] {e}")
    print("\nTerminé." + (f" {erreurs} échec(s)." if erreurs else "") +
          " Dans ComfyUI, appuie sur R pour voir les nouveaux fichiers.")
    return 1 if erreurs else 0


# ------------------------------------------------------- commandes
def cmd_lien(lien, profil, token, oui_auto):
    genre, mid, vid = analyser_lien(lien)
    if genre == "image":
        return cmd_image(lien, profil, token, oui_auto)
    if vid is None:
        modele = api_get(f"/models/{mid}", token)
        versions = modele.get("modelVersions") or []
        if not versions:
            raise Erreur("Aucune version publiée pour ce modèle.")
        vid = versions[0]["id"]
        print(f"(Aucune version précisée dans le lien : dernière version utilisée, n° {vid})")
    plan = preparer(vid, profil, token)
    afficher(plan, interactif=not oui_auto)
    return traiter_plans([plan], token, oui_auto)


def cmd_image(lien, profil, token, oui_auto):
    genre, iid, _ = analyser_lien(lien)
    if genre != "image":
        raise Erreur("Ce lien n'est pas une page d'image Civitai (…/images/123456).")
    data = api_get(f"/images?imageId={iid}&withMeta=true&nsfw=X", token)
    items = data.get("items") or []
    if not items:
        raise Erreur("Image introuvable : privée, supprimée, filtrée (lance « civitai login »), "
                     "ou contenu filtré selon la région du Pod.")
    it = items[0]
    meta = it.get("meta") or {}
    if isinstance(meta.get("meta"), dict):
        meta = meta["meta"]

    ressources = {}  # vid -> poids
    types_decl = {}  # vid -> type déclaré dans l'image (lora, checkpoint, embed...)
    for r in meta.get("civitaiResources") or []:
        if r.get("modelVersionId"):
            ressources.setdefault(int(r["modelVersionId"]), r.get("weight"))
            types_decl[int(r["modelVersionId"])] = (r.get("type") or "").lower()
    for v in it.get("modelVersionIds") or []:
        ressources.setdefault(int(v), None)
    manquants = []  # dict : nom, empreinte, poids, type, raison
    hachages = [(r.get("hash"), r.get("weight"), r.get("name"), (r.get("type") or "").lower())
                for r in meta.get("resources") or [] if r.get("hash")]
    if meta.get("Model hash"):
        hachages.append((meta["Model hash"], None, meta.get("Model"), "model"))
    for h, w, n, t in hachages:
        try:
            v = api_get(f"/model-versions/by-hash/{h}", token)
            ressources.setdefault(int(v["id"]), w)
        except Erreur:
            print(f"   (empreinte {h} inconnue de Civitai, ressource ignorée)")
            manquants.append({"nom": n or "nom inconnu", "empreinte": h, "poids": w, "type": t,
                              "raison": "inconnue de Civitai (supprimée ou jamais publiée)"})

    os.makedirs(PRIVE_INPUT, exist_ok=True)
    recap = os.path.join(PRIVE_INPUT, f"civitai_image_{iid}.txt")
    with open(recap, "w") as f:
        f.write(f"Image Civitai {iid} — {lien}\nArchitecture : {it.get('baseModel', '?')}\n\n")
        for k in ("prompt", "negativePrompt", "seed", "steps", "cfgScale", "sampler", "scheduler", "Size",
                  "clipSkip", "denoise", "Hires upscale", "Hires upscaler"):
            if k in meta:
                f.write(f"{k} : {meta[k]}\n")
        f.write("\nRessources (modelVersionId : poids) :\n")
        for v, w in ressources.items():
            f.write(f"  https://civitai.red/api/download/models/{v} : {w}\n")
    print(f"Paramètres de génération enregistrés dans {recap}")
    print(f"Architecture : {it.get('baseModel', '?')} | taille : {meta.get('Size', '?')} | "
          f"seed : {meta.get('seed', '?')} | steps : {meta.get('steps', '?')} | CFG : {meta.get('cfgScale', '?')} | "
          f"sampler : {meta.get('sampler', '?')}")

    # image d'origine (peut contenir le workflow ComfyUI)
    url = it.get("url") or ""
    if url:
        orig = re.sub(r"/width=\d+/", "/original=true/", url)
        dest = os.path.join(PRIVE_INPUT, f"civitai_image_{iid}")
        try:
            telecharger(orig, dest, token)
            with open(dest, "rb") as fh:
                debut = fh.read(4 * 1024 * 1024)
            ext = ".png" if debut.startswith(b"\x89PNG") else ".jpg" if debut.startswith(b"\xff\xd8") \
                else ".webp" if debut[8:12] == b"WEBP" else ".bin"
            os.replace(dest, dest + ext)
            if ext == ".png" and b"workflow" in debut:
                print(f"Workflow ComfyUI intégré : OUI -> glisse {dest + ext} dans ComfyUI "
                      "(onglet du navigateur : depuis tes fichiers, ou via le dossier input).")
            else:
                print("Workflow ComfyUI intégré : non (on reconstruira avec les paramètres ci-dessus).")
        except Erreur as e:
            print(f"   (image d'origine non récupérée : {e})")

    if not ressources:
        print("Aucune ressource Civitai référencée par cette image.")
        return 1
    plans = []
    for v, w in ressources.items():
        try:
            p = preparer(v, profil, token, poids=w)
            afficher(p, interactif=not oui_auto)
            plans.append(p)
        except Erreur as e:
            print(f"   [IGNORÉ] version {v} : {e}")
            manquants.append({"nom": f"modelVersionId {v}", "empreinte": None, "poids": w,
                              "type": types_decl.get(v, ""), "raison": str(e)})
    if manquants:
        with open(recap, "a") as f:
            f.write("\nRessources NON récupérées sur Civitai (à chercher ailleurs, ex. Hugging Face) :\n")
            for m in manquants:
                f.write(f"  {m['nom']}" + (f" — type {m['type']}" if m["type"] else "")
                        + (f" — empreinte {m['empreinte']}" if m["empreinte"] else "")
                        + (f" — poids {m['poids']}" if m["poids"] is not None else "") + f" : {m['raison']}\n")
        print(f"\n{len(manquants)} ressource(s) introuvable(s) sur Civitai : détail dans {recap}. "
              "Pour les récupérer sur Hugging Face : bouton « Télécharger depuis Hugging Face », "
              "en indiquant l'empreinte attendue quand l'outil la demande.")
    choisis = choisir_ressources(plans, oui_auto)
    rc = traiter_plans(choisis, token, oui_auto)
    base = it.get("baseModel") or next((p["base"] for p in choisis if p["type"] == "Checkpoint"), "?")
    if not any(p.get("dest") for p in choisis):
        return rc
    if est_flux2_klein(base):
        wf, notes = generer_workflow_flux2(meta, choisis, base, manquants)
    elif est_krea2(base):
        wf, notes = generer_workflow_krea2(meta, choisis, base, manquants)
    elif est_sdxl(base):
        wf, notes = generer_workflow(meta, choisis, base, manquants)
    else:
        print(f"\nWorkflow automatique : non disponible pour l'architecture « {base} » "
              "(SD 1.5 / SDXL / Pony / Illustrious / Flux.2 Klein / Krea 2). Utilise ton workflow de base.")
        return rc
    os.makedirs(WORKFLOWS, exist_ok=True)
    for chemin in (os.path.join(PRIVE_INPUT, f"civitai_image_{iid}_workflow.json"),
                   os.path.join(WORKFLOWS, f"civitai_{iid}.json")):
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump(wf, f, ensure_ascii=False, indent=1)
    print(f"\nWorkflow ComfyUI créé : « civitai_{iid} » — dans ComfyUI, ouvre le panneau Workflows (barre latérale), "
          "ou glisse le fichier .json récupéré sur ton PC.")
    for n in notes:
        print(f"   - {n}")
    return rc


def choisir_ressources(plans, oui_auto):
    """Récapitule les ressources d'une image et permet d'en exclure avant téléchargement."""
    if not plans:
        return plans
    print("\nRessources trouvées pour cette image :")
    for i, p in enumerate(plans, 1):
        f = p["fichiers"][p["choix"]]
        print(f"   {i}. [{p['type']}] {p['nom']} | {p['base']} | {go(f.get('sizeKB')):.2f} Go"
              + (f" | poids {p['poids']}" if p["poids"] is not None else ""))
    bases = [p for p in plans if p["type"] == "Checkpoint"]
    if len(bases) > 1:
        print(f"\n   Attention : {len(bases)} modèles de base sont référencés par cette image. "
              "Un seul est réellement utilisé pour générer ; garde celui affiché sur la page de l'image.")
    if oui_auto:
        return plans
    try:
        rep = input("Numéros à exclure, séparés par des espaces [Entrée = aucun] : ").strip()
    except EOFError:
        rep = ""
    exclus = {int(x) for x in rep.split() if x.isdigit()}
    garde = [p for i, p in enumerate(plans, 1) if i not in exclus]
    if exclus:
        print(f"   {len(plans) - len(garde)} ressource(s) exclue(s).")
    return garde


def cmd_liste(fichier, profil, token, oui_auto):
    # Une ligne = un lien, éventuellement suivi d'un commentaire (« # nom du modèle »).
    # Seul le premier mot de la ligne est utilisé ; les lignes commençant par # sont ignorées.
    with open(fichier, encoding="utf-8-sig") as f:
        liens = [l.split()[0] for l in f if l.strip().startswith("https://")]
    plans = []
    for lien in liens:
        try:
            genre, mid, vid = analyser_lien(lien)
            if genre == "image":
                print(f"   (lien d'image ignoré dans une liste : {lien})")
                continue
            if vid is None:
                vid = api_get(f"/models/{mid}", token)["modelVersions"][0]["id"]
            p = preparer(vid, profil, token)
            afficher(p, interactif=False)
            plans.append(p)
        except Erreur as e:
            print(f"   [IGNORÉ] {lien} : {e}")
    return traiter_plans(plans, token, oui_auto)


FLUX2 = [  # (dépôt, chemin, destination sous models/, empreinte connue ou None = lue sur Hugging Face)
    ("Comfy-Org/flux2-klein-9B", "split_files/text_encoders/qwen_3_8b_fp8mixed.safetensors",
     "text_encoders/flux2/qwen_3_8b_fp8mixed.safetensors",
     "abad16806e0cbabc54e0325d6565847443fe396d5f0be38bb3cd3fe75a1201d6"),
    ("Comfy-Org/flux2-dev", "split_files/vae/flux2-vae.safetensors", "vae/flux2/flux2-vae.safetensors", None),
]


def installer_depuis_hf(depot, chemin, rel, sha_connu=None, rev="main"):
    """Télécharge un fichier Hugging Face en vérifiant l'empreinte SHA-256 publiée (et connue, si fournie)."""
    dest = os.path.join(MODELS, rel)
    parent = os.path.dirname(chemin)
    arbre = api_get(f"https://huggingface.co/api/models/{depot}/tree/{rev}" + (f"/{urllib.parse.quote(parent)}" if parent else ""), token_hf())
    entree = next((e for e in arbre if e.get("path") == chemin), None)
    if not entree:
        raise Erreur(f"{chemin} introuvable dans {depot}.")
    sha = ((entree.get("lfs") or {}).get("oid") or "").lower()
    if len(sha) != 64 or (sha_connu and sha != sha_connu):
        raise Erreur(f"{rel} : empreinte publiée inattendue ({sha[:16]}…), téléchargement annulé.")
    if os.path.isfile(dest) and sha256(dest) == sha:
        print(f"   [déjà présent, vérifié] {rel}")
        return dest
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    os.makedirs(TMP, exist_ok=True)
    tmp = os.path.join(TMP, os.path.basename(rel) + ".part")
    telecharger(f"https://huggingface.co/{depot}/resolve/{rev}/{urllib.parse.quote(chemin)}", tmp, token_hf())
    if sha256(tmp) != sha:
        os.makedirs(QUAR, exist_ok=True)
        shutil.move(tmp, os.path.join(QUAR, os.path.basename(rel)))
        raise Erreur(f"{rel} : empreinte incorrecte, isolé en quarantaine.")
    shutil.move(tmp, dest)
    print(f"   [OK] {rel}")
    return dest


def cmd_flux2():
    print("Composants officiels de Flux.2 Klein 9B (dépôts Comfy-Org sur Hugging Face, pas Civitai) :")
    for depot, chemin, rel, sha in FLUX2:
        installer_depuis_hf(depot, chemin, rel, sha)
    print("Licence : Flux.2 Klein 9B est sous licence FLUX Non-Commercial (usage personnel uniquement).")
    return 0


def cmd_krea2():
    print("Composants officiels de Krea 2 (dépôt Comfy-Org sur Hugging Face, pas Civitai) :")
    for url, rel, sha in KREA2:
        dest = os.path.join(MODELS, rel)
        if os.path.isfile(dest) and sha256(dest) == sha:
            print(f"   [déjà présent, vérifié] {rel}")
            continue
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        os.makedirs(TMP, exist_ok=True)
        tmp = os.path.join(TMP, os.path.basename(rel) + ".part")
        telecharger(url, tmp, None)
        if sha256(tmp) != sha:
            os.makedirs(QUAR, exist_ok=True)
            shutil.move(tmp, os.path.join(QUAR, os.path.basename(rel)))
            raise Erreur(f"{rel} : empreinte incorrecte, isolé en quarantaine.")
        shutil.move(tmp, dest)
        print(f"   [OK] {rel}")
    return 0


# ------------------------------------------------------- workflow automatique (SD 1.5 / SDXL / Pony / Illustrious)
ARCHI_SDXL = ("pony", "sdxl", "illustrious", "noobai", "sd-1")
SAMPLERS = {"euler a": "euler_ancestral", "euler": "euler", "heun": "heun", "lms": "lms", "ddim": "ddim",
            "dpm2": "dpm_2", "dpm2 a": "dpm_2_ancestral", "dpm++ 2s a": "dpmpp_2s_ancestral",
            "dpm++ 2m": "dpmpp_2m", "dpm++ sde": "dpmpp_sde", "dpm++ 2m sde": "dpmpp_2m_sde",
            "dpm++ 3m sde": "dpmpp_3m_sde", "unipc": "uni_pc", "lcm": "lcm"}


def est_sdxl(base):
    b = slug(base)
    return any(b.startswith(x) or x in b for x in ARCHI_SDXL)


def sampler_comfy(nom, sched=None):
    n = (nom or "").lower().strip()
    sch = "normal"
    for suffixe, val in ((" karras", "karras"), (" exponential", "exponential"), (" sgm uniform", "sgm_uniform")):
        if n.endswith(suffixe):
            n, sch = n[:-len(suffixe)].strip(), val
    if sched:
        sch = {"karras": "karras", "exponential": "exponential", "sgm uniform": "sgm_uniform",
               "simple": "simple", "normal": "normal"}.get(str(sched).lower(), sch)
    if n in SAMPLERS:
        return SAMPLERS[n], sch, True
    return "euler_ancestral", sch, False


def _nombre(v, typ, defaut):
    try:
        return typ(v)
    except (TypeError, ValueError):
        return defaut


TYPES_LORA = ("lora", "locon", "lycoris", "dora")


def est_lora_manquante(m):
    t = (m.get("type") or "").lower()
    return t in TYPES_LORA or (not t and m.get("poids") is not None)


def generer_workflow(meta, plans, base, manquants=()):
    """Construit un workflow ComfyUI (nœuds natifs) à partir des paramètres d'une image Civitai."""
    notes = []
    def rel(p, dossier):
        return os.path.relpath(p["dest"], os.path.join(MODELS, dossier)).replace(os.sep, "/")
    ckpts = [p for p in plans if p.get("dest") and f"{os.sep}checkpoints{os.sep}" in p["dest"]]
    loras = [p for p in plans if p.get("dest") and f"{os.sep}loras{os.sep}" in p["dest"]]
    if ckpts:
        ckpt = rel(ckpts[0], "checkpoints")
    else:
        ckpt = "A_CHOISIR.safetensors"
        notes.append("Checkpoint non téléchargé : sélectionne-le dans « Load Checkpoint ».")

    larg, haut = 1024, 1024
    m = re.match(r"^\s*(\d+)\s*x\s*(\d+)\s*$", str(meta.get("Size", "")))
    if m:
        larg, haut = int(m.group(1)), int(m.group(2))
    clip = _nombre(meta.get("clipSkip"), int, 2 if "pony" in slug(base) else 1)
    steps = _nombre(meta.get("steps"), int, 25)
    cfg = _nombre(meta.get("cfgScale"), float, 7.0)
    seed = _nombre(meta.get("seed"), int, None)
    sampler, sched, connu = sampler_comfy(meta.get("sampler"), meta.get("scheduler"))
    if not connu:
        notes.append(f"Sampler « {meta.get('sampler')} » non reconnu : euler_ancestral utilisé.")
    pos = re.sub(r"<lora:[^>]+>", "", str(meta.get("prompt", ""))).strip(" ,")
    neg = re.sub(r"<lora:[^>]+>", "", str(meta.get("negativePrompt", ""))).strip(" ,")
    if any(k.lower().startswith("hires") for k in meta):
        notes.append("L'image d'origine utilisait un « hires fix » (agrandissement) : non reproduit, image en taille de base.")
    for p in plans:
        if p["type"] != "TextualInversion" or not p.get("dest"):
            continue
        tige = os.path.splitext(os.path.basename(p["dest"]))[0]
        ref = f"embedding:{tige}"
        noms = {tige} | {w.strip() for w in p.get("mots") or [] if w.strip()}
        trouve = False
        for n in sorted(noms, key=len, reverse=True):
            motif = re.compile(r"(?<![\w:])" + re.escape(n) + r"(?![\w])", re.I)
            if motif.search(pos) or motif.search(neg):
                pos, neg = motif.sub(ref, pos), motif.sub(ref, neg)
                trouve = True
                break
        if trouve:
            notes.append(f"Embedding « {tige} » remplacé par « {ref} » dans le prompt.")
        elif "neg" in (tige + p["nom"]).lower():
            neg = f"{ref}, {neg}" if neg else ref
            notes.append(f"Embedding négatif « {tige} » ajouté au début du prompt négatif.")
        else:
            notes.append(f"Embedding « {tige} » téléchargé : ajoute « {ref} » dans le prompt où il était utilisé.")

    nodes, links = [], []
    def node(i, t, pos_xy, size, inputs, outputs, widgets, mode=0, title=None):
        n = {"id": i, "type": t, "pos": pos_xy, "size": size, "flags": {}, "order": len(nodes), "mode": mode,
             "inputs": [{"name": a, "type": b, "link": None} for a, b in inputs],
             "outputs": [{"name": a, "type": b, "links": [], "slot_index": k} for k, (a, b) in enumerate(outputs)],
             "properties": {"Node name for S&R": t}, "widgets_values": widgets}
        if title:
            n["title"] = title
        nodes.append(n)
        return n
    def lier(a, sa, b, sb):
        lid = len(links) + 1
        na = next(n for n in nodes if n["id"] == a)
        nb = next(n for n in nodes if n["id"] == b)
        typ = na["outputs"][sa]["type"]
        na["outputs"][sa]["links"].append(lid)
        nb["inputs"][sb]["link"] = lid
        links.append([lid, a, sa, b, sb, typ])

    node(1, "CheckpointLoaderSimple", [40, 200], [330, 98], [], [("MODEL", "MODEL"), ("CLIP", "CLIP"), ("VAE", "VAE")], [ckpt])
    node(2, "CLIPSetLastLayer", [420, 330], [260, 58], [("clip", "CLIP")], [("CLIP", "CLIP")], [-abs(clip)],
         title=f"Clip skip {abs(clip)}")
    lier(1, 1, 2, 0)
    src_model, src_clip = (1, 0), (2, 0)
    x = 720
    for i, p in enumerate(loras):
        nid = 10 + i
        poids = p.get("poids")
        if poids is None:
            poids = 0.8
            notes.append(f"Poids inconnu pour « {p['nom']} » : 0.8 par défaut.")
        node(nid, "LoraLoader", [x, 200], [320, 126], [("model", "MODEL"), ("clip", "CLIP")],
             [("MODEL", "MODEL"), ("CLIP", "CLIP")], [rel(p, "loras"), float(poids), float(poids)], title=p["nom"][:60])
        lier(src_model[0], src_model[1], nid, 0)
        lier(src_clip[0], src_clip[1], nid, 1)
        src_model, src_clip = (nid, 0), (nid, 1)
        x += 360
    # LoRA introuvables sur Civitai : nœud prêt, DÉSACTIVÉ (contourné) tant que le fichier n'est pas choisi
    for j, m in enumerate([m for m in manquants if est_lora_manquante(m)]):
        nid = 50 + j
        poids = float(m["poids"]) if m.get("poids") is not None else 0.8
        titre = f"À REMPLIR : {m['nom']}"[:70]
        node(nid, "LoraLoader", [x, 200], [340, 126], [("model", "MODEL"), ("clip", "CLIP")],
             [("MODEL", "MODEL"), ("CLIP", "CLIP")], ["A_CHOISIR.safetensors", poids, poids], mode=4, title=titre)
        lier(src_model[0], src_model[1], nid, 0)
        lier(src_clip[0], src_clip[1], nid, 1)
        src_model, src_clip = (nid, 0), (nid, 1)
        x += 380
        notes.append(f"LoRA manquante « {m['nom']} » (poids {poids}) : nœud « À REMPLIR » ajouté, désactivé. "
                     "Une fois le fichier récupéré : choisis-le dans le nœud, puis Ctrl+B pour l'activer.")
    node(4, "CLIPTextEncode", [x, 120], [420, 180], [("clip", "CLIP")], [("CONDITIONING", "CONDITIONING")], [pos], title="Prompt positif")
    node(5, "CLIPTextEncode", [x, 340], [420, 140], [("clip", "CLIP")], [("CONDITIONING", "CONDITIONING")], [neg], title="Prompt négatif")
    node(6, "EmptyLatentImage", [x, 520], [320, 106], [], [("LATENT", "LATENT")], [larg, haut, 1])
    node(7, "KSampler", [x + 460, 200], [320, 262],
         [("model", "MODEL"), ("positive", "CONDITIONING"), ("negative", "CONDITIONING"), ("latent_image", "LATENT")],
         [("LATENT", "LATENT")], [seed if seed is not None else 0, "fixed" if seed is not None else "randomize",
                                  steps, cfg, sampler, sched, 1.0])
    node(8, "VAEDecode", [x + 820, 200], [210, 46], [("samples", "LATENT"), ("vae", "VAE")], [("IMAGE", "IMAGE")], [])
    node(9, "SaveImage", [x + 1060, 200], [420, 460], [("images", "IMAGE")], [], ["civitai_repro"])
    lier(src_clip[0], src_clip[1], 4, 0)
    lier(src_clip[0], src_clip[1], 5, 0)
    lier(src_model[0], src_model[1], 7, 0)
    lier(4, 0, 7, 1)
    lier(5, 0, 7, 2)
    lier(6, 0, 7, 3)
    lier(7, 0, 8, 0)
    lier(1, 2, 8, 1)
    lier(8, 0, 9, 0)
    wf = {"last_node_id": max(n["id"] for n in nodes), "last_link_id": len(links), "nodes": nodes, "links": links,
          "groups": [], "config": {}, "extra": {"ds": {"scale": 0.7, "offset": [0, 0]}}, "version": 0.4}
    return wf, notes


def est_flux2_klein(base):
    return "klein" in slug(base)


def chercher_installe(dossier, mots):
    """Premier fichier installé dans models/<dossier>/ dont le nom contient tous les mots donnés.
    Sur une B300, les fichiers int8 sont ignorés (comme s'ils n'étaient pas là : la bonne version est alors installée)."""
    racine = os.path.join(MODELS, dossier)
    for r, _, noms in os.walk(racine):
        for n in sorted(noms):
            if n.endswith(".safetensors") and all(m in n.lower() for m in mots) and not interdit_ici(n):
                return os.path.relpath(os.path.join(r, n), racine).replace(os.sep, "/")
    return None


ARCHIS_DIT = {
    "flux2": {"nom": "Flux.2 Klein", "mots_modele": ["klein"], "clip_type": "flux2",
              "te": ["qwen_3_8b"], "te_defaut": "flux2/qwen_3_8b_fp8mixed.safetensors",
              "vae": ["flux2"], "vae_defaut": "flux2/flux2-vae.safetensors",
              "latent": "EmptyFlux2LatentImage", "multiple": 16, "bouton": "Composants Flux.2 Klein",
              "rapide": ("distillée", 4, 1.0), "complet": ("base", 20, 4.0), "mot_complet": "base"},
    "krea2": {"nom": "Krea 2", "mots_modele": ["krea"], "clip_type": "krea2",
              "te": ["qwen3vl"], "te_defaut": "krea2/qwen3vl_4b_bf16.safetensors",
              "vae": ["qwen_image_vae"], "vae_defaut": "krea2/qwen_image_vae.safetensors",
              "latent": "EmptySD3LatentImage", "multiple": 16, "bouton": "Composants Krea 2",
              "rapide": ("Turbo", 8, 1.0), "complet": ("Raw", 28, 4.5), "mot_complet": "raw"},
}


def est_krea2(base):
    return "krea" in slug(base)


def generer_workflow_flux2(meta, plans, base, manquants=()):
    return generer_workflow_dit(meta, plans, base, manquants, "flux2")


def generer_workflow_krea2(meta, plans, base, manquants=()):
    return generer_workflow_dit(meta, plans, base, manquants, "krea2")


def generer_workflow_dit(meta, plans, base, manquants, archi):
    """Workflow ComfyUI natif « modèle + encodeur + VAE séparés » (Flux.2 Klein, Krea 2)."""
    A = ARCHIS_DIT[archi]
    notes = []
    def rel(p, dossier):
        return os.path.relpath(p["dest"], os.path.join(MODELS, dossier)).replace(os.sep, "/")
    modeles = [p for p in plans if p.get("dest") and f"{os.sep}diffusion_models{os.sep}" in p["dest"]]
    loras = [p for p in plans if p.get("dest") and f"{os.sep}loras{os.sep}" in p["dest"]]
    if modeles:
        unet = rel(modeles[0], "diffusion_models")
    else:
        unet = chercher_installe("diffusion_models", A["mots_modele"]) or "A_CHOISIR.safetensors"
        notes.append(f"Modèle {A['nom']} non téléchargé avec l'image : vérifie « Load Diffusion Model ».")
    est_complet = A["mot_complet"] in slug(base) or A["mot_complet"] in unet.lower()
    version, steps_def, cfg_def = A["complet"] if est_complet else A["rapide"]
    if archi == "flux2" and ("4b" in slug(base) or "4b" in unet.lower()):
        notes.append("Variante 4B détectée : elle demande l'encodeur Qwen3 4B (non fourni par « Composants Flux.2 »).")
    if "int8" in unet.lower():
        notes.append("Modèle int8 : rendu dégradé possible avec PyTorch cu128 ; préfère une version FP8.")
    te = chercher_installe("text_encoders", A["te"])
    vae = chercher_installe("vae", A["vae"])
    if not te or not vae:
        notes.append(f"Encodeur de texte et/ou VAE de {A['nom']} absents : bouton « {A['bouton']} », puis R dans ComfyUI.")
    te, vae = te or A["te_defaut"], vae or A["vae_defaut"]

    larg, haut = 1024, 1024
    m = re.match(r"^\s*(\d+)\s*x\s*(\d+)\s*$", str(meta.get("Size", "")))
    if m:
        larg, haut = int(m.group(1)), int(m.group(2))
    k = A["multiple"]
    if larg % k or haut % k:
        larg, haut = larg // k * k, haut // k * k
        notes.append(f"Taille arrondie à un multiple de {k} : {larg} x {haut}.")
    steps = _nombre(meta.get("steps"), int, steps_def)
    cfg = _nombre(meta.get("cfgScale"), float, cfg_def)
    seed = _nombre(meta.get("seed"), int, None)
    sampler, sched, connu = sampler_comfy(meta.get("sampler") or "euler", meta.get("scheduler") or "simple")
    if not connu:
        sampler = "euler"
        notes.append(f"Sampler « {meta.get('sampler')} » non reconnu : euler utilisé.")
    if not meta.get("scheduler"):
        sched = "simple"
    pos = re.sub(r"<lora:[^>]+>", "", str(meta.get("prompt", ""))).strip(" ,")
    neg = re.sub(r"<lora:[^>]+>", "", str(meta.get("negativePrompt", ""))).strip(" ,")
    if cfg <= 1.0 and neg:
        notes.append("CFG à 1 : le prompt négatif est ignoré par le modèle (normal en version rapide).")
    notes.append(f"Version {version} : {steps} étapes, CFG {cfg}.")

    nodes, links = [], []
    def node(i, t, pos_xy, size, inputs, outputs, widgets, mode=0, title=None):
        n = {"id": i, "type": t, "pos": pos_xy, "size": size, "flags": {}, "order": len(nodes), "mode": mode,
             "inputs": [{"name": a, "type": b, "link": None} for a, b in inputs],
             "outputs": [{"name": a, "type": b, "links": [], "slot_index": k} for k, (a, b) in enumerate(outputs)],
             "properties": {"Node name for S&R": t}, "widgets_values": widgets}
        if title:
            n["title"] = title
        nodes.append(n)
    def lier(a, sa, b, sb):
        lid = len(links) + 1
        na = next(n for n in nodes if n["id"] == a)
        nb = next(n for n in nodes if n["id"] == b)
        typ = na["outputs"][sa]["type"]
        na["outputs"][sa]["links"].append(lid)
        nb["inputs"][sb]["link"] = lid
        links.append([lid, a, sa, b, sb, typ])

    node(1, "UNETLoader", [40, 120], [340, 82], [], [("MODEL", "MODEL")], [unet, "default"], title="Load Diffusion Model")
    node(2, "CLIPLoader", [40, 260], [340, 106], [], [("CLIP", "CLIP")], [te, A["clip_type"], "default"],
         title=f"Load CLIP (type {A['clip_type']})")
    node(3, "VAELoader", [40, 420], [340, 58], [], [("VAE", "VAE")], [vae], title=f"Load VAE ({A['nom']})")
    src = (1, 0)
    x = 420
    for i, p in enumerate(loras):
        nid = 10 + i
        poids = p.get("poids")
        if poids is None:
            poids = 0.8
            notes.append(f"Poids inconnu pour « {p['nom']} » : 0.8 par défaut.")
        node(nid, "LoraLoaderModelOnly", [x, 120], [320, 82], [("model", "MODEL")], [("MODEL", "MODEL")],
             [rel(p, "loras"), float(poids)], title=p["nom"][:60])
        lier(src[0], src[1], nid, 0)
        src = (nid, 0)
        x += 360
    for j, m in enumerate([m for m in manquants if est_lora_manquante(m)]):
        nid = 50 + j
        poids = float(m["poids"]) if m.get("poids") is not None else 0.8
        node(nid, "LoraLoaderModelOnly", [x, 120], [340, 82], [("model", "MODEL")], [("MODEL", "MODEL")],
             ["A_CHOISIR.safetensors", poids], mode=4, title=f"À REMPLIR : {m['nom']}"[:70])
        lier(src[0], src[1], nid, 0)
        src = (nid, 0)
        x += 380
        notes.append(f"LoRA manquante « {m['nom']} » (poids {poids}) : nœud « À REMPLIR » ajouté, désactivé. "
                     "Choisis le fichier puis Ctrl+B pour l'activer.")
    node(4, "CLIPTextEncode", [x, 120], [420, 180], [("clip", "CLIP")], [("CONDITIONING", "CONDITIONING")], [pos], title="Prompt positif")
    node(5, "CLIPTextEncode", [x, 340], [420, 140], [("clip", "CLIP")], [("CONDITIONING", "CONDITIONING")], [neg], title="Prompt négatif")
    node(6, A["latent"], [x, 520], [320, 106], [], [("LATENT", "LATENT")], [larg, haut, 1])
    node(7, "KSampler", [x + 460, 120], [320, 262],
         [("model", "MODEL"), ("positive", "CONDITIONING"), ("negative", "CONDITIONING"), ("latent_image", "LATENT")],
         [("LATENT", "LATENT")], [seed if seed is not None else 0, "fixed" if seed is not None else "randomize",
                                  steps, cfg, sampler, sched, 1.0])
    node(8, "VAEDecode", [x + 820, 120], [210, 46], [("samples", "LATENT"), ("vae", "VAE")], [("IMAGE", "IMAGE")], [])
    node(9, "SaveImage", [x + 1060, 120], [420, 460], [("images", "IMAGE")], [], ["civitai_repro"])
    lier(2, 0, 4, 0)
    lier(2, 0, 5, 0)
    lier(src[0], src[1], 7, 0)
    lier(4, 0, 7, 1)
    lier(5, 0, 7, 2)
    lier(6, 0, 7, 3)
    lier(7, 0, 8, 0)
    lier(3, 0, 8, 1)
    lier(8, 0, 9, 0)
    wf = {"last_node_id": max(n["id"] for n in nodes), "last_link_id": len(links), "nodes": nodes, "links": links,
          "groups": [], "config": {}, "extra": {"ds": {"scale": 0.7, "offset": [0, 0]}}, "version": 0.4}
    return wf, notes

# ------------------------------------------------------- Hugging Face
HF_TOKEN_FILE = SECRETS + "/hf_token"  # /root/.cache/huggingface/token est un lien vers ce fichier
DOSSIERS_HF = [("loras", "LoRA"), (None, "Checkpoint ou modèle de diffusion (détection automatique)"),
               ("text_encoders", "Encodeur de texte"), ("vae", "VAE"), ("controlnet", "ControlNet"),
               ("embeddings", "Embedding"), ("upscale_models", "Modèle d'upscale")]


def token_hf():
    t = os.environ.get("HF_TOKEN", "").strip()
    if not t and os.path.isfile(HF_TOKEN_FILE):
        with open(HF_TOKEN_FILE) as f:
            t = f.read().strip()
    return t or None


def analyser_lien_hf(lien):
    p = urllib.parse.urlparse(lien.strip())
    if p.scheme != "https" or p.netloc.lower() not in ("huggingface.co", "www.huggingface.co"):
        raise Erreur("Lien refusé : seuls les liens https://huggingface.co/... sont acceptés.")
    m = re.match(r"^/([^/]+)/([^/]+)/(?:blob|resolve)/([^/]+)/(.+)$", p.path)
    if not m:
        raise Erreur("Lien Hugging Face non reconnu : ouvre la page du FICHIER (…/blob/main/…/fichier.safetensors) "
                     "et copie son adresse.")
    depot, rev, chemin = f"{m.group(1)}/{m.group(2)}", m.group(3), urllib.parse.unquote(m.group(4))
    if not chemin.lower().endswith(".safetensors"):
        raise Erreur("Seuls les fichiers .safetensors sont acceptés.")
    return depot, rev, chemin


def cmd_hf(lien, oui_auto):
    depot, rev, chemin = analyser_lien_hf(lien)
    tok = token_hf()
    try:
        info = api_get(f"https://huggingface.co/api/models/{depot}", tok)
    except Erreur as e:
        raise Erreur(f"Dépôt inaccessible ({e}). S'il est protégé : accepte ses conditions sur huggingface.co, "
                     "puis connecte le Pod avec « hf auth login » dans le Terminal Python.")
    dossier_parent = os.path.dirname(chemin)
    url_arbre = f"https://huggingface.co/api/models/{depot}/tree/{rev}" + (f"/{urllib.parse.quote(dossier_parent)}" if dossier_parent else "")
    entree = next((e for e in api_get(url_arbre, tok) if e.get("path") == chemin), None)
    if not entree:
        raise Erreur(f"Fichier introuvable dans le dépôt : {chemin}")
    sha = ((entree.get("lfs") or {}).get("oid") or "").lower()
    taille = (entree.get("lfs") or {}).get("size") or entree.get("size") or 0
    if len(sha) != 64:
        raise Erreur("Hugging Face ne publie pas d'empreinte SHA-256 pour ce fichier, vérification impossible.")

    carte = info.get("cardData") or {}
    print(f"\n== {depot} / {chemin}")
    print(f"   auteur : {info.get('author', '?')} | licence : {carte.get('license', '?')} | "
          f"accès protégé : {info.get('gated') or 'non'} | mis à jour : {(info.get('lastModified') or '')[:10]}")
    print(f"   taille : {taille / 1024 ** 3:.2f} Go | sha256 : {sha[:16]}…")
    if oui_auto:
        raise Erreur("Le téléchargement Hugging Face demande de choisir le dossier : lance-le sans -y.")

    print("   Type de fichier :")
    for i, (_, lib) in enumerate(DOSSIERS_HF, 1):
        print(f"     {i}. {lib}")
    rep = input("   Ton choix [1-7] : ").strip()
    if not rep.isdigit() or not 1 <= int(rep) <= len(DOSSIERS_HF):
        raise Erreur("Choix invalide, rien n'a été téléchargé.")
    dossier = DOSSIERS_HF[int(rep) - 1][0]
    attendu = input("   Empreinte attendue, si tu la connais (SHA256 complet ou AutoV2 de 10 caractères) "
                    "[Entrée = ne pas vérifier] : ").strip().lower()
    if attendu:
        if not re.fullmatch(r"[0-9a-f]{10,64}", attendu):
            raise Erreur("Empreinte attendue invalide (10 à 64 caractères hexadécimaux).")
        if not sha.startswith(attendu):
            raise Erreur(f"Ce fichier n'est PAS celui attendu : empreinte {sha[:len(attendu)]} au lieu de {attendu}. "
                         "Rien n'a été téléchargé.")
        print("   Empreinte attendue : correspond au fichier Hugging Face.")
    archi = slug(input("   Architecture, pour le sous-dossier (ex. krea-2, pony, sdxl) [Entrée = autre] : ").strip() or "autre")
    nom = nom_sur(os.path.basename(chemin))

    for racine, _, noms in os.walk(MODELS):
        if nom in noms and sha256(os.path.join(racine, nom)) == sha:
            print(f"   [déjà présent, vérifié] {os.path.relpath(os.path.join(racine, nom), MODELS)}")
            return 0
    if shutil.disk_usage("/workspace").free < taille * 1.05:
        raise Erreur("Espace disque insuffisant sur /workspace.")
    if not demander(f"   Télécharger {taille / 1024 ** 3:.2f} Go ?", False):
        print("Annulé, rien n'a été téléchargé.")
        return 1

    os.makedirs(TMP, exist_ok=True)
    os.makedirs(QUAR, exist_ok=True)
    tmp = os.path.join(TMP, nom + ".part")
    telecharger(f"https://huggingface.co/{depot}/resolve/{rev}/{urllib.parse.quote(chemin)}", tmp, tok)
    print("   -> vérification de l'empreinte SHA-256 ...")
    if sha256(tmp) != sha:
        q = os.path.join(QUAR, f"{nom}.{datetime.datetime.now():%Y%m%d-%H%M%S}")
        shutil.move(tmp, q)
        raise Erreur(f"Empreinte incorrecte, fichier isolé dans {q}")
    entete = entete_safetensors(tmp)
    if entete is None:
        q = os.path.join(QUAR, nom)
        shutil.move(tmp, q)
        raise Erreur(f"Ce n'est pas un .safetensors valide, isolé dans {q}")
    dossier = dossier or dossier_checkpoint(entete)
    dest = os.path.join(MODELS, dossier, archi, nom)
    if os.path.exists(dest):
        racine, ext = os.path.splitext(dest)
        dest = f"{racine}_{sha[:8]}{ext}"
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.move(tmp, dest)
    with open(JOURNAL, "a") as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M}\thf\thttps://huggingface.co/{depot}/blob/{rev}/{chemin}\t"
                f"{depot} — {os.path.basename(chemin)}\t{dest}\n")
    print(f"   [OK] {dest}\nDans ComfyUI, appuie sur R pour voir le nouveau fichier.")
    return 0


# ------------------------------------------------------- état du Pod
def _cmd(args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception:
        return ""


def _taille(octets):
    for unite in ("o", "Ko", "Mo", "Go", "To"):
        if octets < 1024 or unite == "To":
            return f"{octets:.1f} {unite}" if unite != "o" else f"{octets} o"
        octets /= 1024


def cmd_etat():
    print("=" * 70 + "\n ÉTAT DU POD\n" + "=" * 70)
    gpu = _cmd(["nvidia-smi", "--query-gpu=name,memory.used,memory.total,utilization.gpu,temperature.gpu",
                "--format=csv,noheader"])
    print(f"GPU            : {gpu or 'non détecté'}")
    print(f"Profil         : {profil_gpu()}")
    try:
        # âge du conteneur = temps depuis le démarrage du processus 1 (pas l'uptime de la machine hôte)
        with open("/proc/uptime") as f:
            hote = float(f.read().split()[0])
        with open("/proc/1/stat") as f:
            debut = int(f.read().rsplit(")", 1)[1].split()[19]) / os.sysconf("SC_CLK_TCK")
        sec = int(hote - debut)
        print(f"Allumé depuis  : {sec // 3600} h {sec % 3600 // 60:02d} min (temps facturé approximatif)")
    except Exception:
        pass
    try:
        lim = open("/sys/fs/cgroup/memory.max").read().strip()
        cur = int(open("/sys/fs/cgroup/memory.current").read())
        print(f"Mémoire vive   : {_taille(cur)} utilisés" + ("" if lim == "max" else f" / {_taille(int(lim))}"))
    except Exception:
        pass
    for chemin, lib in (("/", "Disque local "), ("/workspace", "Disque réseau")):
        try:
            u = shutil.disk_usage(chemin)
            print(f"{lib}  : {_taille(u.free)} libres ({chemin})")
        except Exception:
            pass

    print("-" * 70)
    version = _cmd(["git", "-C", "/workspace/ComfyUI", "describe", "--tags"]) or "non installé"
    actif = "OUI" if _cmd(["pgrep", "-f", "main.py --listen 127.0.0.1"]) else "non"
    torch = _cmd(["/root/venv-comfy/bin/python", "-c", "import torch;print(torch.__version__)"]) or "?"
    print(f"ComfyUI        : {version} | en marche : {actif} | PyTorch : {torch}")
    print(f"Clé Civitai    : {'enregistrée' if lire_token() else 'absente (civitai login)'}")
    print(f"Jeton HF       : {'enregistré' if token_hf() else 'absent (seulement pour les dépôts protégés)'}")
    sorties = [f for f in os.listdir(PRIVE + "/output")] if os.path.isdir(PRIVE + "/output") else []
    print(f"Images générées: {len([f for f in sorties if not f.startswith('.')])} dans {PRIVE}/output")
    try:
        u = shutil.disk_usage(ZONE_RAM)
        print(f"Zone privée RAM: {'ACTIVE' if zone_active() else 'NON ACTIVE'} | {_taille(u.used)} utilisés, "
              f"{_taille(u.free)} libres (/dev/shm)")
    except OSError:
        print("Zone privée RAM: NON ACTIVE")
    swap, txt = etat_swap()
    print(f"Mém. d'échange : {'ATTENTION, ' if swap else ''}{txt}")

    print("-" * 70 + "\n MODÈLES INSTALLÉS\n" + "-" * 70)
    total = 0
    groupes = {}
    for racine, _, noms in os.walk(MODELS):
        for n in noms:
            if n.endswith(".safetensors"):
                chemin = os.path.join(racine, n)
                taille = os.path.getsize(chemin)
                if taille < 1024 * 1024:
                    continue
                rel = os.path.relpath(chemin, MODELS)
                groupes.setdefault(rel.split(os.sep)[0], []).append((rel, taille))
                total += taille
    if not groupes:
        print("(aucun modèle)")
    for g in sorted(groupes):
        print(f"[{g}]")
        for rel, taille in sorted(groupes[g]):
            print(f"   {rel[len(g) + 1:]:<58} {_taille(taille):>10}")
    print(f"Total : {_taille(total)}")
    if os.path.isdir(QUAR) and os.listdir(QUAR):
        print("-" * 70 + f"\nQUARANTAINE ({QUAR}) : " + ", ".join(sorted(os.listdir(QUAR))))
    return 0


# ------------------------------------------------------- zone privée en mémoire vive
def type_fs(chemin):
    """Type du système de fichiers qui contient « chemin » (d'après /proc/mounts)."""
    reel, meilleur, typ = os.path.realpath(chemin), "", None
    try:
        with open("/proc/mounts") as f:
            for l in f:
                champs = l.split()
                if len(champs) >= 3:
                    pt = champs[1].replace("\\040", " ")
                    if (reel == pt or reel.startswith(pt.rstrip("/") + "/")) and len(pt) > len(meilleur):
                        meilleur, typ = pt, champs[2]
    except OSError:
        pass
    return typ


def zone_active():
    reel = os.path.realpath(PRIVE)
    return (os.path.islink(PRIVE) and reel == os.path.realpath(ZONE_RAM)
            and os.path.isdir(reel) and type_fs(reel) == "tmpfs")


def exiger_zone():
    if not zone_active():
        raise Erreur("Zone privée en mémoire vive non active : rien n'est écrit pour ne pas toucher le disque. "
                     "Lance d'abord le bouton 4 (installer_comfy.sh).")


def etat_swap():
    """(swap_possible, explication) — la mémoire vive pourrait-elle déborder sur un disque ?"""
    try:
        with open("/proc/swaps") as f:
            zones = [l for l in f.read().splitlines()[1:] if l.strip()]
    except OSError:
        zones = []
    if not zones:
        return False, "aucune mémoire d'échange"
    try:
        lim = open("/sys/fs/cgroup/memory.swap.max").read().strip()
    except OSError:
        lim = "?"
    if lim == "0":
        return False, "mémoire d'échange interdite au Pod"
    return True, f"mémoire d'échange présente sur la machine ({len(zones)}), limite du Pod : {lim}"


def cmd_effacer(oui_auto):
    exiger_zone()
    reel = os.path.realpath(PRIVE)
    if not reel.startswith("/dev/shm/"):
        raise Erreur("Sécurité : la zone n'est pas dans /dev/shm, effacement refusé.")
    contenu = []
    for r, ds, fs in os.walk(reel):
        contenu += [os.path.join(r, f) for f in fs]
    print(f"Zone privée : {len(contenu)} fichier(s) (images, entrées, workflows, clés, journal).")
    if not demander("EFFACER DÉFINITIVEMENT tout ce contenu ? (les images non récupérées seront perdues)", oui_auto):
        print("Annulé, rien n'a été effacé.")
        return 1
    for nom in os.listdir(reel):
        chemin = os.path.join(reel, nom)
        if os.path.isdir(chemin) and not os.path.islink(chemin):
            shutil.rmtree(chemin)
        else:
            os.remove(chemin)
    for d in SOUS_DOSSIERS:
        os.makedirs(os.path.join(reel, d), exist_ok=True)
    os.chmod(reel, 0o700)
    os.chmod(os.path.join(reel, ".secrets"), 0o700)
    open(os.path.join(reel, ".debut_session"), "w").close()
    print("Zone privée effacée et recréée vide (clés Civitai / Hugging Face comprises).")
    return 0


AUDIT_TECHNIQUE = ("/workspace/ComfyUI/models/", "/workspace/.telechargements/", "/workspace/quarantaine/",
                   "/workspace/ComfyUI/.git/", "/root/venv-comfy/", "/root/.cache/pip/", "/root/.triton/",
                   "/root/.nv/", "/root/.cache/torch/", "/root/.cache/huggingface/hub/", "/usr/", "/var/lib/apt/",
                   "/var/cache/", "/var/log/",
                   # caches publics (paquets Python, noyaux GPU compilés, modèles) et outils téléchargés
                   "/workspace/.cache/pip/", "/workspace/.cache/torch/", "/workspace/.cache/triton/",
                   "/workspace/.cache/huggingface/hub/", "/workspace/.triton/", "/workspace/outils/joycaption/",
                   "/workspace/outils/kcpp-tmp/_MEI", "/root/.cache/uv/",
                   # serveur SSH (paquet public openssh-server, installé seulement si tu actives l'accès SSH)
                   "/etc/ssh/", "/var/lib/dpkg/", "/var/lib/systemd/", "/var/lib/ucf/", "/etc/systemd/", "/etc/init.d/",
                   "/etc/default/", "/etc/pam.d/", "/etc/ufw/", "/etc/apparmor.d/", "/etc/alternatives/", "/etc/rc")
# comptes système créés par l'installation de paquets (ex. utilisateur « sshd »)
AUDIT_SYSTEME = ("/etc/passwd", "/etc/passwd-", "/etc/group", "/etc/group-", "/etc/shadow", "/etc/shadow-",
                 "/etc/gshadow", "/etc/gshadow-", "/etc/ld.so.cache")
AUDIT_FICHIERS = ("/root/installer_comfy.sh", "/root/lancer_comfy.sh", "/root/civitai.py", "/root/torch-verrou.txt",
                  "/root/comfy_prive.py", "/root/.rc_venv", "/root/.bashrc", "/root/.wget-hsts", "/root/.ssh/known_hosts",
                  # fichiers réseau écrits par Runpod au démarrage du conteneur
                  "/etc/hostname", "/etc/hosts", "/etc/resolv.conf") + AUDIT_SYSTEME


COMFY_DIR = "/workspace/ComfyUI"


def _code_comfy_intact():
    """Fichiers du code source ComfyUI suivis par git ET identiques à la version officielle.
    Les fichiers modifiés ou ajoutés (non suivis) ne sont PAS dans cet ensemble : ils restent « à examiner »."""
    def git(*a):
        r = subprocess.run(["git", "-c", "safe.directory=*", "-C", COMFY_DIR, *a],
                           capture_output=True, timeout=120)
        if r.returncode != 0:
            raise OSError(r.stderr.decode("utf-8", "replace").strip())
        return [x.decode("utf-8", "surrogateescape") for x in r.stdout.split(b"\0") if x]
    try:
        suivis = set(git("ls-files", "-z"))
        modifies = set(git("diff", "--name-only", "-z", "HEAD"))
    except (OSError, subprocess.SubprocessError):
        return set()
    return {os.path.join(COMFY_DIR, f) for f in suivis - modifies}


EXT_LIVRE = "/root/extensions"


def _extensions_verifiees():
    """Fichiers des extensions ComfyUI livrées avec Studio (copie dans /root/extensions et installation dans
    custom_nodes) dont l'empreinte est celle du manifeste du paquet. Les autres restent « à examiner »."""
    try:
        with open(os.path.join(EXT_LIVRE, "SHA256SUMS"), encoding="utf-8") as f:
            attendu = dict(reversed(l.split(None, 1)) for l in f.read().splitlines() if l.strip())
    except (OSError, ValueError):
        return set()
    attendu = {k.strip(): v for k, v in attendu.items()}
    ok = {os.path.join(EXT_LIVRE, "SHA256SUMS"), os.path.join(EXT_LIVRE, "SOURCES.txt")}
    for rel, sha in attendu.items():
        for c in (os.path.join(EXT_LIVRE, rel), os.path.join(COMFY_DIR, "custom_nodes", rel)):
            try:
                if os.path.isfile(c) and sha256(c) == sha:
                    ok.add(c)
            except OSError:
                pass
    return ok


def cmd_audit():
    """Liste les fichiers écrits sur le disque depuis le début de la session, hors zone privée."""
    marque = os.path.join(ZONE_RAM, ".debut_session")
    if not os.path.isfile(marque):
        raise Erreur("Repère de début de session absent : lance d'abord le bouton 4.")
    debut = os.path.getmtime(marque)
    code_comfy = _code_comfy_intact() | _extensions_verifiees()
    a_examiner, techniques, nb_code = [], 0, 0
    for racine in ("/", "/workspace"):
        try:
            dev = os.stat(racine).st_dev
        except OSError:
            continue
        for r, ds, fs in os.walk(racine):
            garde = []
            for d in ds:
                c = os.path.join(r, d)
                try:
                    if not os.path.islink(c) and os.stat(c).st_dev == dev and c not in ("/proc", "/sys", "/dev", "/run"):
                        garde.append(d)
                except OSError:
                    pass
            ds[:] = garde
            for f in fs:
                c = os.path.join(r, f)
                try:
                    st = os.lstat(c)
                except OSError:
                    continue
                if max(st.st_mtime, st.st_ctime) < debut or os.path.islink(c):
                    continue
                if c in code_comfy:
                    nb_code += 1
                elif c.startswith(AUDIT_TECHNIQUE) or c in AUDIT_FICHIERS or "/__pycache__/" in c or c.endswith(".pyc"):
                    techniques += 1
                else:
                    a_examiner.append((c, st.st_size))
    print("=" * 70 + "\n CONTRÔLE DU DISQUE (fichiers écrits depuis le début de la session)\n" + "=" * 70)
    print(f"Zone privée en mémoire vive : {'ACTIVE' if zone_active() else 'NON ACTIVE'}")
    swap, txt = etat_swap()
    print(f"Mémoire d'échange          : {'ATTENTION, ' if swap else ''}{txt}")
    print(f"Code source ComfyUI officiel et extensions livrées (empreintes vérifiées) : {nb_code}")
    print(f"Fichiers techniques (modèles publics, logiciels, caches) : {techniques}")
    if not a_examiner:
        print("Aucun autre fichier écrit sur le disque. Aucune donnée privée détectée hors mémoire vive.")
        return 0
    print(f"\nÀ EXAMINER ({len(a_examiner)}) : fichiers écrits sur le disque hors des catégories connues")
    dossiers = {}
    for c, t in a_examiner:
        d = "/".join(c.split("/")[:4]) + "/"
        dossiers.setdefault(d, [0, 0])
        dossiers[d][0] += 1
        dossiers[d][1] += t
    print("Par dossier :")
    for d, (nb, t) in sorted(dossiers.items(), key=lambda x: -x[1][0])[:20]:
        print(f"   {nb:>5} fichier(s)  {_taille(t):>10}  {d}")
    print("Exemples :")
    vus = set()
    for c, t in sorted(a_examiner):
        d = "/".join(c.split("/")[:4]) + "/"
        if sum(1 for x in vus if x[0] == d) < 3:
            vus.add((d, c))
            print(f"   {c}  ({_taille(t)})")
    print("\nCe contrôle n'ouvre aucun fichier. Envoie-moi la liste si un chemin te semble suspect.")
    return 2


def main(argv):
    profil, oui_auto, args = None, False, []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--profil" and i + 1 < len(argv):
            profil = argv[i + 1]
            i += 2
            continue
        if a in ("-y", "--oui"):
            oui_auto = True
        else:
            args.append(a)
        i += 1
    if profil not in (None, "4090", "6000"):
        raise Erreur("Profil inconnu : utilise --profil 4090 ou --profil 6000.")
    if not args or args[0] in ("-h", "--help", "aide"):
        print(AIDE)
        return 0

    cmd = args[0]
    if cmd == "audit":
        return cmd_audit()
    if cmd != "etat":
        exiger_zone()
    if cmd == "effacer":
        return cmd_effacer(oui_auto)
    if cmd == "login":
        t = getpass.getpass("Clé API Civitai (ne s'affiche pas) : ").strip()
        if not t:
            raise Erreur("Clé vide, rien n'a été enregistré.")
        os.makedirs(SECRETS, mode=0o700, exist_ok=True)
        fd = os.open(TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(t)
        print("Clé enregistrée en mémoire vive uniquement (zone privée, droits 600).")
        return 0
    if cmd == "hf-login":
        t = getpass.getpass("Jeton Hugging Face, en lecture seule (ne s'affiche pas) : ").strip()
        if not re.fullmatch(r"[A-Za-z0-9_\-]{20,200}", t):
            raise Erreur("Ce texte ne ressemble pas à un jeton (20 caractères ou plus, sans espace). "
                         "Vérifie que tu as copié la VALEUR du jeton et non son nom. Rien n'a été enregistré.")
        if not t.startswith("hf_"):
            print("Note : les jetons Hugging Face commencent habituellement par « hf_ ».")
            if re.fullmatch(r"[0-9a-f]{32}", t):
                print("Ce texte a le format d'une clé API Civitai (32 caractères hexadécimaux).")
            if not demander("Enregistrer quand même ce texte comme jeton Hugging Face ?"):
                print("Annulé, rien n'a été enregistré.")
                return 1
        os.makedirs(os.path.dirname(HF_TOKEN_FILE), exist_ok=True)
        fd = os.open(HF_TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(t)
        print("Jeton enregistré en mémoire vive uniquement (zone privée, droits 600).")
        print("Il sert aussi à la commande « hf » du Terminal Python. Pense à accepter les conditions des dépôts protégés sur huggingface.co.")
        return 0
    if cmd == "hf-logout":
        if os.path.isfile(HF_TOKEN_FILE):
            os.remove(HF_TOKEN_FILE)
        print("Jeton Hugging Face retiré du Pod.")
        return 0
    if cmd == "logout":
        if os.path.isfile(TOKEN_FILE):
            os.remove(TOKEN_FILE)
        print("Clé API retirée du Pod.")
        return 0
    if cmd == "journal":
        if os.path.isfile(JOURNAL):
            with open(JOURNAL) as f:
                for l in f:
                    print(l.rstrip("\n"))
        return 0
    if cmd == "krea2-composants":
        return cmd_krea2()
    if cmd == "flux2-composants":
        return cmd_flux2()
    if cmd == "etat":
        return cmd_etat()
    if cmd == "hf" and len(args) > 1:
        return cmd_hf(args[1], oui_auto)

    token = lire_token()
    if not token:
        print("Attention : aucune clé API. Civitai exige une clé pour tout téléchargement de fichier : "
              "lance d'abord « civitai login ».")
    prof = profil_gpu(profil)
    print(f"Profil GPU : {prof} (fichiers jusqu'à {LIMITE_GO[prof]} Go privilégiés)")
    if cmd == "image" and len(args) > 1:
        return cmd_image(args[1], prof, token, oui_auto)
    if cmd == "liste" and len(args) > 1:
        return cmd_liste(args[1], prof, token, oui_auto)
    return cmd_lien(cmd, prof, token, oui_auto)


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Erreur as e:
        print(f"Erreur : {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nInterrompu.")
        sys.exit(130)
